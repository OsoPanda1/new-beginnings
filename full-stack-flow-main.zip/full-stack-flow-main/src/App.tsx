import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/hooks/useAuth";
import Index from "./pages/Index";
import Auth from "./pages/Auth";
import Dashboard from "./pages/Dashboard";
import Isabella from "./pages/Isabella";
import Quantum from "./pages/Quantum";
import Wallet from "./pages/Wallet";
import Cells from "./pages/Cells";
import Sentinel from "./pages/Sentinel";
import WhitePaper from "./pages/WhitePaper";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/auth" element={<Auth />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/isabella" element={<Isabella />} />
            <Route path="/quantum" element={<Quantum />} />
            <Route path="/wallet" element={<Wallet />} />
            <Route path="/cells" element={<Cells />} />
            <Route path="/sentinel" element={<Sentinel />} />
            <Route path="/whitepaper" element={<WhitePaper />} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;