// TAMV ONLINE Video Tutorials Hub
// Centro de tutoriales en video

export type TutorialCategory =
  | "inicio"
  | "creacionContenido"
  | "experiencias"
  | "puentesOniricos"
  | "monetizacion"
  | "concursos"
  | "seguridad";

export interface VideoTutorial {
  id: string;
  title: string;
  description: string;
  category: TutorialCategory;
  videoUrl: string;
  thumbnailUrl?: string;
  durationSeconds: number;
  level: "basico" | "intermedio" | "avanzado";
}

export const TUTORIAL_CATEGORIES: Record<TutorialCategory, { label: string; description: string }> = {
  inicio: {
    label: "Primeros Pasos",
    description: "Aprende los conceptos básicos de TAMV ONLINE"
  },
  creacionContenido: {
    label: "Creación de Contenido",
    description: "Cómo crear y publicar contenido inmersivo"
  },
  experiencias: {
    label: "Experiencias Inmersivas",
    description: "Dream Spaces, conciertos sensoriales y más"
  },
  puentesOniricos: {
    label: "Puentes Oníricos",
    description: "Conecta con colaboradores creativos"
  },
  monetizacion: {
    label: "Monetización",
    description: "Genera ingresos con tu creatividad"
  },
  concursos: {
    label: "Retos y Concursos",
    description: "Participa y gana recompensas"
  },
  seguridad: {
    label: "Seguridad",
    description: "Protege tu cuenta y contenido"
  }
};

export const LEVEL_LABELS: Record<VideoTutorial['level'], string> = {
  basico: "Básico",
  intermedio: "Intermedio",
  avanzado: "Avanzado"
};

// Videos de tutoriales iniciales (URLs placeholder - se reemplazan con videos reales)
export const TUTORIALS: VideoTutorial[] = [
  {
    id: "tut-001",
    title: "Primeros pasos en TAMV ONLINE",
    description: "Descubre cómo navegar por el ecosistema, crear tu perfil y comenzar tu viaje en la plataforma de soberanía digital.",
    category: "inicio",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    durationSeconds: 480,
    level: "basico"
  },
  {
    id: "tut-002",
    title: "Cómo crear tu primer Dream Space",
    description: "Guía paso a paso para diseñar y publicar espacios inmersivos 3D que cautiven a tu audiencia.",
    category: "experiencias",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    durationSeconds: 720,
    level: "basico"
  },
  {
    id: "tut-003",
    title: "Organiza un concierto sensorial",
    description: "Aprende a crear experiencias musicales multisensoriales con efectos visuales 3D sincronizados.",
    category: "experiencias",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    durationSeconds: 900,
    level: "intermedio"
  },
  {
    id: "tut-004",
    title: "Puentes Oníricos: encuentra tu equipo ideal",
    description: "Cómo funciona el matching colaborativo y cómo conectar con creadores que complementan tu proyecto.",
    category: "puentesOniricos",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    durationSeconds: 540,
    level: "basico"
  },
  {
    id: "tut-005",
    title: "Monetiza tu contenido con Banco TAMV",
    description: "Guía completa para configurar tu wallet, recibir pagos y gestionar tu economía creativa.",
    category: "monetizacion",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    durationSeconds: 660,
    level: "intermedio"
  },
  {
    id: "tut-006",
    title: "Participa en retos y gana TAM",
    description: "Todo sobre los concursos, misiones y desafíos que impulsan tu visibilidad y recompensas.",
    category: "concursos",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    durationSeconds: 420,
    level: "basico"
  },
  {
    id: "tut-007",
    title: "Seguridad Dekateotl: protege tu identidad",
    description: "Las 11 capas de seguridad explicadas y mejores prácticas para proteger tu cuenta y contenido.",
    category: "seguridad",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    durationSeconds: 600,
    level: "intermedio"
  },
  {
    id: "tut-008",
    title: "Crea contenido con Isabella IA",
    description: "Usa la inteligencia artificial de TAMV para mejorar tu contenido y experiencias.",
    category: "creacionContenido",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    durationSeconds: 540,
    level: "basico"
  },
  {
    id: "tut-009",
    title: "API avanzada para desarrolladores",
    description: "Integra TAMV en tus aplicaciones con nuestra API REST y webhooks.",
    category: "creacionContenido",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    durationSeconds: 1200,
    level: "avanzado"
  },
  {
    id: "tut-010",
    title: "Operaciones Cuánticas explicadas",
    description: "Entiende cómo funcionan las operaciones cuántico-inspiradas y cómo usarlas.",
    category: "inicio",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    durationSeconds: 780,
    level: "avanzado"
  }
];

// Utilidad para formatear duración
export function formatDuration(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

// Filtrar tutoriales
export function filterTutorials(
  tutorials: VideoTutorial[],
  category?: TutorialCategory,
  level?: VideoTutorial['level']
): VideoTutorial[] {
  return tutorials.filter(t => {
    if (category && t.category !== category) return false;
    if (level && t.level !== level) return false;
    return true;
  });
}
