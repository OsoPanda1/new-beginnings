// TAMV ONLINE Product Tour System
// Tour automático de onboarding para nuevos usuarios

export type TourStepId =
  | "hero"
  | "features"
  | "cells"
  | "isabella"
  | "cta";

export interface ProductTourStep {
  id: TourStepId;
  targetSelector: string;
  title: string;
  description: string;
  position: "top" | "bottom" | "left" | "right" | "center";
}

export const TAMV_TOUR_STEPS: ProductTourStep[] = [
  {
    id: "hero",
    targetSelector: "#tamv-hero",
    title: "Bienvenido a TAMV ONLINE",
    description: "La primera infraestructura digital civilizatoria de Latinoamérica. Explora el ecosistema de soberanía digital.",
    position: "bottom"
  },
  {
    id: "features",
    targetSelector: "#tamv-features",
    title: "Ecosistema Completo",
    description: "Descubre nuestros 9 pilares: Cells Federadas, Isabella IA, Seguridad Dekateotl, BookPI y más.",
    position: "top"
  },
  {
    id: "cells",
    targetSelector: "#tamv-cells-viz",
    title: "Red Federada 3D",
    description: "Visualiza en tiempo real las Cells Federadas conectadas al BookPI Ledger central.",
    position: "top"
  },
  {
    id: "isabella",
    targetSelector: "#tamv-isabella",
    title: "Isabella IA™",
    description: "Tu guía con inteligencia emocional. Pregunta lo que quieras sobre el ecosistema.",
    position: "top"
  },
  {
    id: "cta",
    targetSelector: "#tamv-cta",
    title: "¡Únete Ahora!",
    description: "Regístrate gratis y comienza a explorar el futuro de la soberanía digital.",
    position: "top"
  }
];

// Estado del tour por usuario
export interface UserOnboardingStatus {
  userId?: string;
  hasCompletedMainTour: boolean;
  completedAt?: string;
  lastStepSeen?: TourStepId;
}

export interface ProductTourState {
  isActive: boolean;
  currentStepIndex: number;
}

const STORAGE_KEY = 'tamv_onboarding_status';

export function getOnboardingStatus(): UserOnboardingStatus {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      return JSON.parse(stored);
    }
  } catch {
    // Si falla, devolver estado por defecto
  }
  return { hasCompletedMainTour: false };
}

export function saveOnboardingStatus(status: UserOnboardingStatus): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(status));
  } catch {
    console.warn('No se pudo guardar el estado del onboarding');
  }
}

export function shouldShowTour(): boolean {
  const status = getOnboardingStatus();
  return !status.hasCompletedMainTour;
}

export function startTour(): ProductTourState {
  return { isActive: true, currentStepIndex: 0 };
}

export function nextStep(state: ProductTourState): ProductTourState {
  const nextIndex = state.currentStepIndex + 1;
  if (nextIndex >= TAMV_TOUR_STEPS.length) {
    return { isActive: false, currentStepIndex: 0 };
  }
  return { isActive: true, currentStepIndex: nextIndex };
}

export function completeTour(): void {
  const status: UserOnboardingStatus = {
    hasCompletedMainTour: true,
    completedAt: new Date().toISOString(),
    lastStepSeen: TAMV_TOUR_STEPS[TAMV_TOUR_STEPS.length - 1].id
  };
  saveOnboardingStatus(status);
}

export function resetTour(): void {
  localStorage.removeItem(STORAGE_KEY);
}
