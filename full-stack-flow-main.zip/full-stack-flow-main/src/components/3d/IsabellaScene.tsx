import { Suspense, useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float, Sparkles, MeshDistortMaterial } from '@react-three/drei';
import { useDevicePerformance } from '@/hooks/use-device-performance';
import * as THREE from 'three';

function BrainCore() {
  const coreRef = useRef<THREE.Mesh>(null);
  const shellRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (coreRef.current) {
      coreRef.current.rotation.y = state.clock.elapsedTime * 0.3;
      const pulse = 1 + Math.sin(state.clock.elapsedTime * 2) * 0.05;
      coreRef.current.scale.setScalar(pulse);
    }
    if (shellRef.current) {
      shellRef.current.rotation.x = state.clock.elapsedTime * 0.1;
      shellRef.current.rotation.z = state.clock.elapsedTime * 0.15;
    }
  });

  return (
    <group>
      {/* Inner core - brain */}
      <mesh ref={coreRef}>
        <sphereGeometry args={[0.8, 32, 32]} />
        <MeshDistortMaterial
          color="#ec4899"
          emissive="#ec4899"
          emissiveIntensity={0.4}
          distort={0.4}
          speed={2}
        />
      </mesh>

      {/* Outer shell */}
      <mesh ref={shellRef}>
        <icosahedronGeometry args={[1.2, 1]} />
        <meshStandardMaterial
          color="#8b5cf6"
          emissive="#8b5cf6"
          emissiveIntensity={0.2}
          wireframe
          transparent
          opacity={0.5}
        />
      </mesh>
    </group>
  );
}

function DNAHelix() {
  const helixRef = useRef<THREE.Group>(null);
  const pointCount = 40;

  useFrame((state) => {
    if (helixRef.current) {
      helixRef.current.rotation.y = state.clock.elapsedTime * 0.3;
    }
  });

  const helixPoints = useMemo(() => {
    const points = [];
    for (let i = 0; i < pointCount; i++) {
      const t = (i / pointCount) * Math.PI * 4;
      const y = (i / pointCount - 0.5) * 5;
      points.push({
        pos1: [Math.cos(t) * 1.5, y, Math.sin(t) * 1.5] as [number, number, number],
        pos2: [Math.cos(t + Math.PI) * 1.5, y, Math.sin(t + Math.PI) * 1.5] as [number, number, number],
      });
    }
    return points;
  }, []);

  return (
    <group ref={helixRef}>
      {helixPoints.map((point, i) => (
        <group key={i}>
          <mesh position={point.pos1}>
            <sphereGeometry args={[0.05]} />
            <meshStandardMaterial color="#ec4899" emissive="#ec4899" emissiveIntensity={0.5} />
          </mesh>
          <mesh position={point.pos2}>
            <sphereGeometry args={[0.05]} />
            <meshStandardMaterial color="#8b5cf6" emissive="#8b5cf6" emissiveIntensity={0.5} />
          </mesh>
        </group>
      ))}
    </group>
  );
}

function NeuralConnections() {
  const linesRef = useRef<THREE.LineSegments>(null);
  const nodeCount = 20;

  const geometry = useMemo(() => {
    const positions: number[] = [];
    const nodes: THREE.Vector3[] = [];

    for (let i = 0; i < nodeCount; i++) {
      nodes.push(
        new THREE.Vector3(
          (Math.random() - 0.5) * 6,
          (Math.random() - 0.5) * 6,
          (Math.random() - 0.5) * 6
        )
      );
    }

    for (let i = 0; i < nodeCount; i++) {
      for (let j = i + 1; j < nodeCount; j++) {
        if (nodes[i].distanceTo(nodes[j]) < 3) {
          positions.push(nodes[i].x, nodes[i].y, nodes[i].z);
          positions.push(nodes[j].x, nodes[j].y, nodes[j].z);
        }
      }
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    return geo;
  }, []);

  useFrame((state) => {
    if (linesRef.current) {
      linesRef.current.rotation.y = state.clock.elapsedTime * 0.05;
    }
  });

  return (
    <lineSegments ref={linesRef} geometry={geometry}>
      <lineBasicMaterial color="#ec4899" transparent opacity={0.3} />
    </lineSegments>
  );
}

function SceneContent() {
  const { level } = useDevicePerformance();

  return (
    <>
      <ambientLight intensity={0.15} />
      <pointLight position={[5, 5, 5]} intensity={0.5} color="#ec4899" />
      <pointLight position={[-5, -5, 5]} intensity={0.3} color="#8b5cf6" />

      <Float speed={1} rotationIntensity={0.2} floatIntensity={0.3}>
        <BrainCore />
      </Float>

      {level !== 'low' && <DNAHelix />}
      {level === 'high' && <NeuralConnections />}

      <Sparkles count={level === 'low' ? 30 : 80} scale={6} size={1.5} speed={0.3} color="#ec4899" />

      <fog attach="fog" args={['#030712', 5, 20]} />
    </>
  );
}

export function IsabellaScene() {
  const { dpr, isMobile } = useDevicePerformance();

  return (
    <div className="absolute inset-0 z-0 opacity-40">
      <Canvas
        camera={{ position: [0, 0, 7], fov: 50 }}
        gl={{ antialias: !isMobile, alpha: true, powerPreference: 'high-performance' }}
        dpr={dpr}
      >
        <Suspense fallback={null}>
          <SceneContent />
        </Suspense>
      </Canvas>
    </div>
  );
}
