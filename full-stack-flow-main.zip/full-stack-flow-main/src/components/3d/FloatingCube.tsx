import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Box, Edges } from '@react-three/drei';
import * as THREE from 'three';

interface FloatingCubeProps {
  position?: [number, number, number];
  size?: number;
  color?: string;
  wireframe?: boolean;
}

export function FloatingCube({ 
  position = [0, 0, 0], 
  size = 1,
  color = '#00d4ff',
  wireframe = false
}: FloatingCubeProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const innerRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.x = state.clock.elapsedTime * 0.3;
      meshRef.current.rotation.y = state.clock.elapsedTime * 0.4;
      meshRef.current.position.y = position[1] + Math.sin(state.clock.elapsedTime * 0.8) * 0.3;
    }
    if (innerRef.current) {
      innerRef.current.rotation.x = -state.clock.elapsedTime * 0.5;
      innerRef.current.rotation.y = -state.clock.elapsedTime * 0.3;
    }
  });

  return (
    <group position={position}>
      {/* Outer wireframe cube */}
      <Box ref={meshRef} args={[size, size, size]}>
        {wireframe ? (
          <>
            <meshBasicMaterial transparent opacity={0} />
            <Edges color={color} threshold={15} />
          </>
        ) : (
          <meshStandardMaterial
            color={color}
            transparent
            opacity={0.2}
            metalness={0.9}
            roughness={0.1}
            emissive={color}
            emissiveIntensity={0.3}
          />
        )}
      </Box>
      
      {/* Inner rotating cube */}
      <Box ref={innerRef} args={[size * 0.5, size * 0.5, size * 0.5]}>
        <meshStandardMaterial
          color={color}
          metalness={0.9}
          roughness={0.1}
          emissive={color}
          emissiveIntensity={0.5}
        />
      </Box>
    </group>
  );
}
