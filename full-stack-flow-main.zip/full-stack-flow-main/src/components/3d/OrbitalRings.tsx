import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Ring } from '@react-three/drei';
import * as THREE from 'three';

interface OrbitalRingsProps {
  count?: number;
  radius?: number;
  color?: string;
}

export function OrbitalRings({ 
  count = 5, 
  radius = 3,
  color = '#00d4ff'
}: OrbitalRingsProps) {
  const groupRef = useRef<THREE.Group>(null);
  const ringsRef = useRef<THREE.Mesh[]>([]);

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = state.clock.elapsedTime * 0.1;
    }
    
    ringsRef.current.forEach((ring, i) => {
      if (ring) {
        const speed = (i + 1) * 0.15;
        ring.rotation.z = state.clock.elapsedTime * speed;
        ring.rotation.x = Math.sin(state.clock.elapsedTime * 0.3 + i) * 0.2;
      }
    });
  });

  return (
    <group ref={groupRef}>
      {Array.from({ length: count }).map((_, i) => {
        const ringRadius = radius + i * 0.6;
        const opacity = 0.3 - i * 0.04;
        const rotation: [number, number, number] = [
          Math.PI / 2 + (i * 0.3),
          i * 0.5,
          0
        ];
        
        return (
          <Ring
            key={i}
            ref={(el) => { if (el) ringsRef.current[i] = el; }}
            args={[ringRadius, ringRadius + 0.02, 128]}
            rotation={rotation}
          >
            <meshBasicMaterial
              color={i % 2 === 0 ? color : '#d4af37'}
              transparent
              opacity={opacity}
              side={THREE.DoubleSide}
            />
          </Ring>
        );
      })}
    </group>
  );
}
