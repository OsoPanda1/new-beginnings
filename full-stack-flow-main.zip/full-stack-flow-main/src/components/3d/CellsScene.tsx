import { Suspense, useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float, Sparkles, Html } from '@react-three/drei';
import { useDevicePerformance } from '@/hooks/use-device-performance';
import * as THREE from 'three';

interface CellNodeProps {
  position: [number, number, number];
  status: 'healthy' | 'degraded' | 'failover';
  name: string;
}

function CellNode({ position, status, name }: CellNodeProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const glowRef = useRef<THREE.Mesh>(null);

  const color = status === 'healthy' ? '#22c55e' : status === 'degraded' ? '#f59e0b' : '#ef4444';

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y = state.clock.elapsedTime * 0.5;
    }
    if (glowRef.current) {
      const pulse = 1 + Math.sin(state.clock.elapsedTime * 3) * 0.2;
      glowRef.current.scale.setScalar(pulse);
    }
  });

  return (
    <group position={position}>
      <Float speed={2} floatIntensity={0.2}>
        {/* Main cell */}
        <mesh ref={meshRef}>
          <dodecahedronGeometry args={[0.4]} />
          <meshStandardMaterial
            color={color}
            emissive={color}
            emissiveIntensity={0.3}
            metalness={0.5}
            roughness={0.3}
          />
        </mesh>

        {/* Glow effect */}
        <mesh ref={glowRef}>
          <sphereGeometry args={[0.6, 16, 16]} />
          <meshBasicMaterial color={color} transparent opacity={0.15} />
        </mesh>
      </Float>
    </group>
  );
}

function CentralBookPI() {
  const coreRef = useRef<THREE.Mesh>(null);
  const ringsRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (coreRef.current) {
      coreRef.current.rotation.y = state.clock.elapsedTime * 0.2;
    }
    if (ringsRef.current) {
      ringsRef.current.rotation.z = state.clock.elapsedTime * 0.1;
    }
  });

  return (
    <group>
      <mesh ref={coreRef}>
        <octahedronGeometry args={[0.8]} />
        <meshStandardMaterial
          color="#00d4ff"
          emissive="#00d4ff"
          emissiveIntensity={0.5}
          metalness={0.8}
          roughness={0.2}
        />
      </mesh>

      <group ref={ringsRef}>
        <mesh rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[1.2, 0.03, 16, 50]} />
          <meshStandardMaterial color="#d4af37" emissive="#d4af37" emissiveIntensity={0.5} />
        </mesh>
        <mesh rotation={[Math.PI / 3, 0, 0]}>
          <torusGeometry args={[1.5, 0.02, 16, 50]} />
          <meshStandardMaterial color="#00d4ff" emissive="#00d4ff" emissiveIntensity={0.3} />
        </mesh>
      </group>
    </group>
  );
}

function ConnectionLines({ cells }: { cells: { position: [number, number, number] }[] }) {
  const linesRef = useRef<THREE.LineSegments>(null);

  const geometry = useMemo(() => {
    const positions: number[] = [];
    
    // Connect all cells to center
    cells.forEach(cell => {
      positions.push(0, 0, 0);
      positions.push(cell.position[0], cell.position[1], cell.position[2]);
    });

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    return geo;
  }, [cells]);

  useFrame((state) => {
    if (linesRef.current && linesRef.current.material instanceof THREE.LineBasicMaterial) {
      linesRef.current.material.opacity = 0.3 + Math.sin(state.clock.elapsedTime * 2) * 0.1;
    }
  });

  return (
    <lineSegments ref={linesRef} geometry={geometry}>
      <lineBasicMaterial color="#00d4ff" transparent opacity={0.4} />
    </lineSegments>
  );
}

function SceneContent() {
  const { level } = useDevicePerformance();

  const cells = useMemo(() => [
    { position: [3, 1, 0] as [number, number, number], status: 'healthy' as const, name: 'Educación' },
    { position: [-3, 1, 0] as [number, number, number], status: 'healthy' as const, name: 'Salud' },
    { position: [2, -2, 1] as [number, number, number], status: 'degraded' as const, name: 'Fintech' },
    { position: [-2, -2, 1] as [number, number, number], status: 'healthy' as const, name: 'Cultura' },
    { position: [0, 3, -1] as [number, number, number], status: 'healthy' as const, name: 'Defensa' },
    { position: [0, -3, -1] as [number, number, number], status: 'failover' as const, name: 'Ciencia' },
    { position: [2.5, 0, 2] as [number, number, number], status: 'healthy' as const, name: 'Ambiente' },
    { position: [-2.5, 0, 2] as [number, number, number], status: 'healthy' as const, name: 'Gobierno' },
  ], []);

  const displayCells = level === 'low' ? cells.slice(0, 4) : cells;

  return (
    <>
      <ambientLight intensity={0.2} />
      <pointLight position={[5, 5, 5]} intensity={0.5} color="#00d4ff" />
      <pointLight position={[-5, -5, 5]} intensity={0.3} color="#22c55e" />

      <CentralBookPI />
      <ConnectionLines cells={displayCells} />

      {displayCells.map((cell, i) => (
        <CellNode key={i} {...cell} />
      ))}

      <Sparkles count={level === 'low' ? 30 : 80} scale={10} size={1} speed={0.2} color="#00d4ff" />

      <fog attach="fog" args={['#030712', 5, 20]} />
    </>
  );
}

export function CellsScene() {
  const { dpr, isMobile } = useDevicePerformance();

  return (
    <div className="absolute inset-0 z-0 opacity-50">
      <Canvas
        camera={{ position: [0, 0, 10], fov: 50 }}
        gl={{ antialias: !isMobile, alpha: true, powerPreference: 'high-performance' }}
        dpr={dpr}
      >
        <Suspense fallback={null}>
          <SceneContent />
        </Suspense>
      </Canvas>
    </div>
  );
}
