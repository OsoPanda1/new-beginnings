import { Suspense, useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float, Sparkles, MeshDistortMaterial, Torus } from '@react-three/drei';
import { useDevicePerformance } from '@/hooks/use-device-performance';
import * as THREE from 'three';

function Qubit({ position, color }: { position: [number, number, number]; color: string }) {
  const meshRef = useRef<THREE.Mesh>(null);
  const orbitRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.x = state.clock.elapsedTime * 2;
      meshRef.current.rotation.y = state.clock.elapsedTime * 1.5;
    }
    if (orbitRef.current) {
      orbitRef.current.rotation.z = state.clock.elapsedTime * 3;
    }
  });

  return (
    <group position={position}>
      <Float speed={2} floatIntensity={0.3}>
        <mesh ref={meshRef}>
          <octahedronGeometry args={[0.3]} />
          <MeshDistortMaterial
            color={color}
            emissive={color}
            emissiveIntensity={0.5}
            distort={0.4}
            speed={5}
          />
        </mesh>
        <mesh ref={orbitRef}>
          <torusGeometry args={[0.5, 0.02, 16, 50]} />
          <meshStandardMaterial
            color={color}
            emissive={color}
            emissiveIntensity={0.8}
            transparent
            opacity={0.6}
          />
        </mesh>
      </Float>
    </group>
  );
}

function QuantumCore() {
  const coreRef = useRef<THREE.Mesh>(null);
  const ringsRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (coreRef.current) {
      coreRef.current.rotation.y = state.clock.elapsedTime * 0.5;
      coreRef.current.scale.setScalar(1 + Math.sin(state.clock.elapsedTime * 2) * 0.1);
    }
    if (ringsRef.current) {
      ringsRef.current.rotation.x = state.clock.elapsedTime * 0.3;
      ringsRef.current.rotation.z = state.clock.elapsedTime * 0.2;
    }
  });

  return (
    <group>
      {/* Central core */}
      <mesh ref={coreRef}>
        <icosahedronGeometry args={[0.8, 2]} />
        <MeshDistortMaterial
          color="#00d4ff"
          emissive="#00d4ff"
          emissiveIntensity={0.4}
          distort={0.3}
          speed={3}
          wireframe
        />
      </mesh>

      {/* Energy rings */}
      <group ref={ringsRef}>
        <Torus args={[1.5, 0.03, 16, 100]} rotation={[Math.PI / 2, 0, 0]}>
          <meshStandardMaterial color="#8b5cf6" emissive="#8b5cf6" emissiveIntensity={0.5} />
        </Torus>
        <Torus args={[2, 0.02, 16, 100]} rotation={[Math.PI / 3, Math.PI / 4, 0]}>
          <meshStandardMaterial color="#00d4ff" emissive="#00d4ff" emissiveIntensity={0.5} />
        </Torus>
        <Torus args={[2.5, 0.02, 16, 100]} rotation={[-Math.PI / 4, Math.PI / 6, 0]}>
          <meshStandardMaterial color="#d4af37" emissive="#d4af37" emissiveIntensity={0.5} />
        </Torus>
      </group>
    </group>
  );
}

function DataStreams() {
  const points = useRef<THREE.Points>(null);
  const count = 150;

  const positions = useMemo(() => {
    const pos = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      const theta = Math.random() * Math.PI * 2;
      const radius = 2 + Math.random() * 2;
      pos[i * 3] = Math.cos(theta) * radius;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 6;
      pos[i * 3 + 2] = Math.sin(theta) * radius;
    }
    return pos;
  }, []);

  useFrame((state) => {
    if (points.current) {
      const posArray = points.current.geometry.attributes.position.array as Float32Array;
      for (let i = 0; i < count; i++) {
        posArray[i * 3 + 1] -= 0.03;
        if (posArray[i * 3 + 1] < -3) {
          posArray[i * 3 + 1] = 3;
        }
      }
      points.current.geometry.attributes.position.needsUpdate = true;
      points.current.rotation.y = state.clock.elapsedTime * 0.1;
    }
  });

  return (
    <points ref={points}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" count={count} array={positions} itemSize={3} />
      </bufferGeometry>
      <pointsMaterial size={0.08} color="#00d4ff" transparent opacity={0.6} />
    </points>
  );
}

function SceneContent() {
  const { level } = useDevicePerformance();

  return (
    <>
      <ambientLight intensity={0.15} />
      <pointLight position={[5, 5, 5]} intensity={0.6} color="#00d4ff" />
      <pointLight position={[-5, -5, 5]} intensity={0.4} color="#8b5cf6" />

      <QuantumCore />

      {/* Qubits */}
      <Qubit position={[3, 1, 0]} color="#d4af37" />
      <Qubit position={[-3, -1, 1]} color="#8b5cf6" />
      {level !== 'low' && (
        <>
          <Qubit position={[0, 3, -2]} color="#00d4ff" />
          <Qubit position={[-2, -2, 2]} color="#22c55e" />
        </>
      )}

      {level !== 'low' && <DataStreams />}

      <Sparkles count={level === 'low' ? 30 : 100} scale={8} size={1.5} speed={0.4} color="#8b5cf6" />

      <fog attach="fog" args={['#030712', 5, 20]} />
    </>
  );
}

export function QuantumScene() {
  const { dpr, isMobile } = useDevicePerformance();

  return (
    <div className="absolute inset-0 z-0 opacity-50">
      <Canvas
        camera={{ position: [0, 0, 8], fov: 50 }}
        gl={{ antialias: !isMobile, alpha: true, powerPreference: 'high-performance' }}
        dpr={dpr}
      >
        <Suspense fallback={null}>
          <SceneContent />
        </Suspense>
      </Canvas>
    </div>
  );
}
