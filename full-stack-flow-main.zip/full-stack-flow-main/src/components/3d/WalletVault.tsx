import { Suspense, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { 
  Box, 
  Edges, 
  Float, 
  Sparkles,
  Environment,
  MeshTransmissionMaterial
} from '@react-three/drei';
import * as THREE from 'three';

function VaultStructure() {
  const vaultRef = useRef<THREE.Group>(null);
  const innerRef = useRef<THREE.Mesh>(null);
  const shieldRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    const time = state.clock.elapsedTime;
    
    if (vaultRef.current) {
      vaultRef.current.rotation.y = time * 0.1;
    }
    
    if (innerRef.current) {
      innerRef.current.rotation.y = -time * 0.3;
      innerRef.current.rotation.x = Math.sin(time * 0.5) * 0.2;
    }
    
    if (shieldRef.current) {
      shieldRef.current.rotation.y = time * 0.2;
      const scale = 1 + Math.sin(time * 2) * 0.05;
      shieldRef.current.scale.set(scale, scale, scale);
    }
  });

  return (
    <group ref={vaultRef}>
      {/* Central vault core - gold */}
      <Float speed={1.5} rotationIntensity={0.2} floatIntensity={0.3}>
        <Box args={[1.5, 1.5, 1.5]}>
          <meshStandardMaterial
            color="#d4af37"
            metalness={0.9}
            roughness={0.1}
            emissive="#d4af37"
            emissiveIntensity={0.3}
          />
        </Box>
      </Float>

      {/* Inner rotating core */}
      <Box ref={innerRef} args={[0.8, 0.8, 0.8]}>
        <meshStandardMaterial
          color="#ffffff"
          metalness={1}
          roughness={0}
          emissive="#d4af37"
          emissiveIntensity={0.5}
        />
      </Box>

      {/* Protective shield layers */}
      <Box ref={shieldRef} args={[2.2, 2.2, 2.2]}>
        <meshBasicMaterial
          color="#d4af37"
          transparent
          opacity={0.1}
          wireframe
        />
        <Edges color="#d4af37" threshold={15} />
      </Box>

      {/* Outer defense grid */}
      <Box args={[3, 3, 3]}>
        <meshBasicMaterial
          color="#00d4ff"
          transparent
          opacity={0.05}
          wireframe
        />
      </Box>

      {/* Floating security nodes */}
      {[
        [2.5, 0, 0],
        [-2.5, 0, 0],
        [0, 2.5, 0],
        [0, -2.5, 0],
        [0, 0, 2.5],
        [0, 0, -2.5]
      ].map((pos, i) => (
        <Float key={i} speed={2} rotationIntensity={0.5} floatIntensity={0.5}>
          <mesh position={pos as [number, number, number]}>
            <octahedronGeometry args={[0.2]} />
            <meshStandardMaterial
              color="#00d4ff"
              emissive="#00d4ff"
              emissiveIntensity={0.5}
              metalness={0.8}
              roughness={0.2}
            />
          </mesh>
        </Float>
      ))}
    </group>
  );
}

function VaultScene() {
  return (
    <>
      <ambientLight intensity={0.2} />
      <pointLight position={[10, 10, 10]} intensity={1} color="#d4af37" />
      <pointLight position={[-10, -10, -10]} intensity={0.5} color="#00d4ff" />
      <spotLight
        position={[0, 10, 0]}
        angle={0.3}
        penumbra={1}
        intensity={0.5}
        color="#ffffff"
      />

      <Sparkles count={100} scale={10} size={1.5} speed={0.3} color="#d4af37" />

      <VaultStructure />

      <Environment preset="night" />
      <fog attach="fog" args={['#030712', 10, 30]} />
    </>
  );
}

export function WalletVault() {
  return (
    <div className="relative w-full h-[350px]">
      <Canvas
        camera={{ position: [0, 0, 8], fov: 45 }}
        gl={{ antialias: true, alpha: true }}
        dpr={[1, 2]}
      >
        <Suspense fallback={null}>
          <VaultScene />
        </Suspense>
      </Canvas>

      {/* Security status overlay */}
      <div className="absolute top-4 right-4 glass-card px-3 py-2 rounded-lg">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-success animate-pulse" />
          <span className="text-xs font-display text-success">Ojo de Ra Activo</span>
        </div>
      </div>
    </div>
  );
}
