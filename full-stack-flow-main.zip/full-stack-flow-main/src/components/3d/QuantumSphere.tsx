import { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { Sphere, MeshDistortMaterial } from '@react-three/drei';
import * as THREE from 'three';

interface QuantumSphereProps {
  position?: [number, number, number];
  color?: string;
  scale?: number;
  distort?: number;
  speed?: number;
}

export function QuantumSphere({ 
  position = [0, 0, 0], 
  color = '#00d4ff',
  scale = 1,
  distort = 0.4,
  speed = 2
}: QuantumSphereProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const glowRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.x = state.clock.elapsedTime * 0.2;
      meshRef.current.rotation.y = state.clock.elapsedTime * 0.3;
    }
    if (glowRef.current) {
      glowRef.current.rotation.x = -state.clock.elapsedTime * 0.1;
      glowRef.current.rotation.z = state.clock.elapsedTime * 0.15;
    }
  });

  return (
    <group position={position}>
      {/* Inner core */}
      <Sphere ref={meshRef} args={[1, 64, 64]} scale={scale * 0.8}>
        <MeshDistortMaterial
          color={color}
          attach="material"
          distort={distort}
          speed={speed}
          roughness={0.1}
          metalness={0.8}
          emissive={color}
          emissiveIntensity={0.5}
        />
      </Sphere>
      
      {/* Outer glow */}
      <Sphere ref={glowRef} args={[1, 32, 32]} scale={scale * 1.2}>
        <meshBasicMaterial
          color={color}
          transparent
          opacity={0.15}
          wireframe
        />
      </Sphere>
    </group>
  );
}
