import { Suspense, useRef, useState, useMemo } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { 
  Sphere, 
  Line, 
  Text, 
  Float,
  Html,
  OrbitControls,
  Stars,
  Sparkles
} from '@react-three/drei';
import * as THREE from 'three';

interface CellData {
  id: string;
  name: string;
  status: 'healthy' | 'degraded' | 'failover' | 'isolated';
  metrics: { cpu: number; mem: number; latency: number };
  position: [number, number, number];
}

const cellsData: CellData[] = [
  { id: "edu", name: "Educación", status: "healthy", metrics: { cpu: 23, mem: 45, latency: 12 }, position: [-4, 2, 0] },
  { id: "salud", name: "Salud", status: "healthy", metrics: { cpu: 34, mem: 52, latency: 18 }, position: [4, 2, 0] },
  { id: "fintech", name: "Fintech", status: "degraded", metrics: { cpu: 78, mem: 85, latency: 45 }, position: [-3, -2, 2] },
  { id: "cultura", name: "Cultura", status: "healthy", metrics: { cpu: 15, mem: 32, latency: 8 }, position: [3, -2, 2] },
  { id: "defensa", name: "Defensa", status: "healthy", metrics: { cpu: 45, mem: 60, latency: 15 }, position: [0, 3, -2] },
  { id: "ciencia", name: "Ciencia", status: "failover", metrics: { cpu: 92, mem: 95, latency: 120 }, position: [-2, 0, 3] },
  { id: "gobierno", name: "Gobierno", status: "healthy", metrics: { cpu: 38, mem: 55, latency: 20 }, position: [2, 0, 3] },
  { id: "ambiente", name: "Ambiente", status: "healthy", metrics: { cpu: 28, mem: 40, latency: 10 }, position: [0, -3, -1] },
];

const statusColors: Record<string, string> = {
  healthy: '#22c55e',
  degraded: '#eab308',
  failover: '#ef4444',
  isolated: '#6b7280'
};

function CellNode({ cell, onHover }: { cell: CellData; onHover: (cell: CellData | null) => void }) {
  const meshRef = useRef<THREE.Mesh>(null);
  const glowRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);
  const color = statusColors[cell.status];

  useFrame((state) => {
    if (meshRef.current) {
      const scale = hovered ? 1.3 : 1;
      meshRef.current.scale.lerp(new THREE.Vector3(scale, scale, scale), 0.1);
    }
    if (glowRef.current) {
      glowRef.current.rotation.y = state.clock.elapsedTime * 0.5;
      glowRef.current.rotation.x = state.clock.elapsedTime * 0.3;
    }
  });

  return (
    <Float speed={2} rotationIntensity={0.2} floatIntensity={0.5}>
      <group position={cell.position}>
        {/* Glow effect */}
        <Sphere ref={glowRef} args={[0.6, 32, 32]}>
          <meshBasicMaterial
            color={color}
            transparent
            opacity={0.15}
            wireframe
          />
        </Sphere>

        {/* Main sphere */}
        <Sphere
          ref={meshRef}
          args={[0.4, 32, 32]}
          onPointerOver={() => { setHovered(true); onHover(cell); }}
          onPointerOut={() => { setHovered(false); onHover(null); }}
        >
          <meshStandardMaterial
            color={color}
            emissive={color}
            emissiveIntensity={hovered ? 0.8 : 0.4}
            metalness={0.8}
            roughness={0.2}
          />
        </Sphere>

        {/* Cell label */}
        <Html position={[0, 0.8, 0]} center distanceFactor={8}>
          <div className={`px-2 py-1 rounded-md text-xs font-display whitespace-nowrap transition-all ${
            hovered ? 'bg-card/95 scale-110' : 'bg-card/70'
          }`} style={{ color }}>
            {cell.name}
          </div>
        </Html>
      </group>
    </Float>
  );
}

function CentralCore() {
  const coreRef = useRef<THREE.Mesh>(null);
  const ringsRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (coreRef.current) {
      coreRef.current.rotation.y = state.clock.elapsedTime * 0.2;
    }
    if (ringsRef.current) {
      ringsRef.current.rotation.z = state.clock.elapsedTime * 0.1;
      ringsRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.3) * 0.2;
    }
  });

  return (
    <group>
      {/* Central BookPI Core */}
      <Sphere ref={coreRef} args={[0.8, 64, 64]}>
        <meshStandardMaterial
          color="#00d4ff"
          emissive="#00d4ff"
          emissiveIntensity={0.6}
          metalness={0.9}
          roughness={0.1}
        />
      </Sphere>

      {/* Orbital rings */}
      <group ref={ringsRef}>
        {[1.2, 1.5, 1.8].map((radius, i) => (
          <mesh key={i} rotation={[Math.PI / 2 + i * 0.3, i * 0.5, 0]}>
            <ringGeometry args={[radius, radius + 0.02, 64]} />
            <meshBasicMaterial
              color={i % 2 === 0 ? '#00d4ff' : '#d4af37'}
              transparent
              opacity={0.4 - i * 0.1}
              side={THREE.DoubleSide}
            />
          </mesh>
        ))}
      </group>

      {/* Core label */}
      <Html position={[0, 1.3, 0]} center>
        <div className="px-3 py-1.5 bg-primary/20 backdrop-blur-sm rounded-lg border border-primary/30">
          <span className="font-display text-sm text-primary font-bold">BookPI</span>
        </div>
      </Html>
    </group>
  );
}

function ConnectionLines() {
  const lines = useMemo(() => {
    return cellsData.map(cell => ({
      points: [new THREE.Vector3(0, 0, 0), new THREE.Vector3(...cell.position)],
      color: statusColors[cell.status]
    }));
  }, []);

  return (
    <group>
      {lines.map((line, i) => (
        <Line
          key={i}
          points={line.points}
          color={line.color}
          lineWidth={1}
          transparent
          opacity={0.3}
          dashed
          dashSize={0.2}
          gapSize={0.1}
        />
      ))}
    </group>
  );
}

function NetworkScene({ onHover }: { onHover: (cell: CellData | null) => void }) {
  return (
    <>
      <ambientLight intensity={0.3} />
      <pointLight position={[10, 10, 10]} intensity={1} color="#ffffff" />
      <pointLight position={[-10, -10, -10]} intensity={0.5} color="#00d4ff" />

      <Stars radius={30} depth={30} count={2000} factor={3} fade speed={0.3} />
      <Sparkles count={100} scale={12} size={1.5} speed={0.2} color="#00d4ff" />

      <CentralCore />
      <ConnectionLines />

      {cellsData.map(cell => (
        <CellNode key={cell.id} cell={cell} onHover={onHover} />
      ))}

      <OrbitControls
        enablePan={false}
        enableZoom={true}
        minDistance={6}
        maxDistance={20}
        autoRotate
        autoRotateSpeed={0.5}
      />

      <fog attach="fog" args={['#030712', 15, 40]} />
    </>
  );
}

export function CellsNetwork() {
  const [hoveredCell, setHoveredCell] = useState<CellData | null>(null);

  return (
    <div className="relative w-full h-[600px] rounded-2xl overflow-hidden border border-border/50">
      <Canvas
        camera={{ position: [0, 2, 12], fov: 50 }}
        gl={{ antialias: true, alpha: true }}
        dpr={[1, 2]}
      >
        <Suspense fallback={null}>
          <NetworkScene onHover={setHoveredCell} />
        </Suspense>
      </Canvas>

      {/* HUD Overlay */}
      <div className="absolute bottom-4 left-4 right-4 flex justify-between items-end pointer-events-none">
        {/* Legend */}
        <div className="glass-card p-3 rounded-lg space-y-2">
          <span className="text-xs font-display text-muted-foreground">ESTADO DE CELLS</span>
          <div className="flex gap-4">
            {Object.entries(statusColors).map(([status, color]) => (
              <div key={status} className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: color }} />
                <span className="text-xs capitalize">{status}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Hovered cell info */}
        {hoveredCell && (
          <div className="glass-card p-4 rounded-lg animate-fade-in">
            <h4 className="font-display font-bold mb-2" style={{ color: statusColors[hoveredCell.status] }}>
              Cell {hoveredCell.name}
            </h4>
            <div className="grid grid-cols-3 gap-4 text-xs">
              <div>
                <span className="text-muted-foreground">CPU</span>
                <div className="font-mono text-lg">{hoveredCell.metrics.cpu}%</div>
              </div>
              <div>
                <span className="text-muted-foreground">MEM</span>
                <div className="font-mono text-lg">{hoveredCell.metrics.mem}%</div>
              </div>
              <div>
                <span className="text-muted-foreground">LAT</span>
                <div className="font-mono text-lg">{hoveredCell.metrics.latency}ms</div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Scan line effect */}
      <div className="absolute inset-0 pointer-events-none bg-gradient-to-b from-transparent via-primary/5 to-transparent opacity-50" 
        style={{ animation: 'scan 4s linear infinite' }} 
      />
    </div>
  );
}
