import { Suspense, useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { 
  Box, 
  Sphere,
  Torus,
  Float, 
  Sparkles,
  Environment,
  Line
} from '@react-three/drei';
import * as THREE from 'three';

function QuantumBit({ position, delay = 0 }: { position: [number, number, number]; delay?: number }) {
  const meshRef = useRef<THREE.Mesh>(null);
  const trailRef = useRef<THREE.Points>(null);

  useFrame((state) => {
    const time = state.clock.elapsedTime + delay;
    
    if (meshRef.current) {
      // Quantum superposition visualization
      meshRef.current.position.x = position[0] + Math.sin(time * 3) * 0.3;
      meshRef.current.position.y = position[1] + Math.cos(time * 2) * 0.3;
      meshRef.current.position.z = position[2] + Math.sin(time * 4) * 0.2;
      
      const scale = 0.15 + Math.sin(time * 5) * 0.05;
      meshRef.current.scale.set(scale, scale, scale);
    }
  });

  return (
    <group>
      <Sphere ref={meshRef} args={[1, 16, 16]} position={position}>
        <meshStandardMaterial
          color="#00d4ff"
          emissive="#00d4ff"
          emissiveIntensity={0.8}
          metalness={0.9}
          roughness={0.1}
        />
      </Sphere>
    </group>
  );
}

function ProcessorCore() {
  const coreRef = useRef<THREE.Group>(null);
  const torusRef = useRef<THREE.Mesh>(null);
  const gridRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    const time = state.clock.elapsedTime;
    
    if (coreRef.current) {
      coreRef.current.rotation.y = time * 0.1;
    }
    
    if (torusRef.current) {
      torusRef.current.rotation.x = time * 0.5;
      torusRef.current.rotation.z = time * 0.3;
    }
    
    if (gridRef.current) {
      gridRef.current.rotation.y = -time * 0.05;
    }
  });

  // Qubit positions in a 3D grid
  const qubits = useMemo(() => {
    const positions: [number, number, number][] = [];
    for (let x = -1; x <= 1; x++) {
      for (let y = -1; y <= 1; y++) {
        for (let z = -1; z <= 1; z++) {
          if (x === 0 && y === 0 && z === 0) continue;
          positions.push([x * 1.5, y * 1.5, z * 1.5]);
        }
      }
    }
    return positions;
  }, []);

  return (
    <group ref={coreRef}>
      {/* Central processor */}
      <Box args={[1, 1, 1]}>
        <meshStandardMaterial
          color="#8b5cf6"
          metalness={0.9}
          roughness={0.1}
          emissive="#8b5cf6"
          emissiveIntensity={0.4}
        />
      </Box>

      {/* Energy torus */}
      <Torus ref={torusRef} args={[2, 0.05, 16, 100]}>
        <meshStandardMaterial
          color="#00d4ff"
          emissive="#00d4ff"
          emissiveIntensity={0.6}
          metalness={0.8}
          roughness={0.2}
        />
      </Torus>

      {/* Second torus perpendicular */}
      <Torus args={[2.5, 0.03, 16, 100]} rotation={[Math.PI / 2, 0, 0]}>
        <meshStandardMaterial
          color="#d4af37"
          emissive="#d4af37"
          emissiveIntensity={0.4}
          metalness={0.8}
          roughness={0.2}
        />
      </Torus>

      {/* Quantum bits */}
      <group ref={gridRef}>
        {qubits.map((pos, i) => (
          <QuantumBit key={i} position={pos} delay={i * 0.2} />
        ))}
      </group>

      {/* Connection lines */}
      {qubits.map((pos, i) => (
        <Line
          key={`line-${i}`}
          points={[[0, 0, 0], pos]}
          color="#00d4ff"
          lineWidth={0.5}
          transparent
          opacity={0.2}
        />
      ))}
    </group>
  );
}

function ProcessorScene() {
  return (
    <>
      <ambientLight intensity={0.2} />
      <pointLight position={[10, 10, 10]} intensity={1} color="#8b5cf6" />
      <pointLight position={[-10, -10, -10]} intensity={0.5} color="#00d4ff" />

      <Sparkles count={150} scale={12} size={1.5} speed={0.5} color="#00d4ff" />

      <Float speed={0.5} rotationIntensity={0.1} floatIntensity={0.2}>
        <ProcessorCore />
      </Float>

      <Environment preset="night" />
      <fog attach="fog" args={['#030712', 10, 30]} />
    </>
  );
}

interface QuantumProcessorProps {
  processing?: boolean;
}

export function QuantumProcessor({ processing = false }: QuantumProcessorProps) {
  return (
    <div className="relative w-full h-[400px]">
      <Canvas
        camera={{ position: [0, 2, 8], fov: 50 }}
        gl={{ antialias: true, alpha: true }}
        dpr={[1, 2]}
      >
        <Suspense fallback={null}>
          <ProcessorScene />
        </Suspense>
      </Canvas>

      {/* Processing status */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 glass-card px-4 py-2 rounded-full">
        <div className="flex items-center gap-3">
          <div className={`w-2 h-2 rounded-full ${processing ? 'bg-primary animate-pulse' : 'bg-success'}`} />
          <span className="text-sm font-display">
            {processing ? 'Procesando Quantum Job...' : 'Quantum Mesh Activo'}
          </span>
          {processing && (
            <div className="flex gap-1">
              {[0, 1, 2].map(i => (
                <div
                  key={i}
                  className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce"
                  style={{ animationDelay: `${i * 0.15}s` }}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
