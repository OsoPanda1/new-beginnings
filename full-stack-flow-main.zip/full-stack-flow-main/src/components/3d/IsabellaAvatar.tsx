import { Suspense, useRef, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { 
  Sphere, 
  Float, 
  Sparkles,
  MeshDistortMaterial,
  Environment
} from '@react-three/drei';
import * as THREE from 'three';

function AvatarCore() {
  const coreRef = useRef<THREE.Mesh>(null);
  const innerRef = useRef<THREE.Mesh>(null);
  const particlesRef = useRef<THREE.Points>(null);

  useFrame((state) => {
    const time = state.clock.elapsedTime;
    
    if (coreRef.current) {
      coreRef.current.rotation.y = time * 0.3;
      coreRef.current.rotation.z = Math.sin(time * 0.5) * 0.1;
    }
    
    if (innerRef.current) {
      innerRef.current.rotation.y = -time * 0.5;
      innerRef.current.rotation.x = Math.sin(time * 0.3) * 0.2;
    }
    
    if (particlesRef.current) {
      particlesRef.current.rotation.y = time * 0.1;
    }
  });

  // Create DNA helix particles
  const helixParticles = new Float32Array(300 * 3);
  for (let i = 0; i < 300; i++) {
    const t = (i / 300) * Math.PI * 8;
    const radius = 2 + Math.sin(t * 2) * 0.5;
    helixParticles[i * 3] = Math.cos(t) * radius;
    helixParticles[i * 3 + 1] = (i / 300 - 0.5) * 6;
    helixParticles[i * 3 + 2] = Math.sin(t) * radius;
  }

  return (
    <group>
      {/* Central consciousness core */}
      <Float speed={2} rotationIntensity={0.3} floatIntensity={0.5}>
        <Sphere ref={coreRef} args={[1.2, 64, 64]}>
          <MeshDistortMaterial
            color="#ec4899"
            attach="material"
            distort={0.3}
            speed={2}
            roughness={0.1}
            metalness={0.8}
            emissive="#ec4899"
            emissiveIntensity={0.5}
          />
        </Sphere>
      </Float>

      {/* Inner rotating sphere */}
      <Sphere ref={innerRef} args={[0.6, 32, 32]}>
        <meshStandardMaterial
          color="#ffffff"
          emissive="#ec4899"
          emissiveIntensity={0.8}
          metalness={1}
          roughness={0}
        />
      </Sphere>

      {/* Outer transparent shell */}
      <Sphere args={[1.8, 32, 32]}>
        <meshBasicMaterial
          color="#ec4899"
          transparent
          opacity={0.08}
          wireframe
        />
      </Sphere>

      {/* DNA helix particles */}
      <points ref={particlesRef}>
        <bufferGeometry>
          <bufferAttribute
            attach="attributes-position"
            count={300}
            array={helixParticles}
            itemSize={3}
          />
        </bufferGeometry>
        <pointsMaterial
          size={0.05}
          color="#ec4899"
          transparent
          opacity={0.6}
          sizeAttenuation
          blending={THREE.AdditiveBlending}
        />
      </points>

      {/* Orbital rings */}
      {[0, 1, 2].map((i) => (
        <mesh key={i} rotation={[Math.PI / 2 + i * 0.4, i * 0.6, 0]}>
          <ringGeometry args={[2 + i * 0.3, 2.02 + i * 0.3, 128]} />
          <meshBasicMaterial
            color="#ec4899"
            transparent
            opacity={0.2 - i * 0.05}
            side={THREE.DoubleSide}
          />
        </mesh>
      ))}
    </group>
  );
}

function IsabellaScene() {
  return (
    <>
      <ambientLight intensity={0.2} />
      <pointLight position={[5, 5, 5]} intensity={1} color="#ec4899" />
      <pointLight position={[-5, -5, -5]} intensity={0.5} color="#8b5cf6" />

      <Sparkles count={150} scale={8} size={2} speed={0.4} color="#ec4899" />

      <AvatarCore />

      <Environment preset="night" />
      <fog attach="fog" args={['#030712', 8, 25]} />
    </>
  );
}

interface IsabellaAvatarProps {
  isListening?: boolean;
  isSpeaking?: boolean;
}

export function IsabellaAvatar({ isListening = false, isSpeaking = false }: IsabellaAvatarProps) {
  return (
    <div className="relative w-full h-[400px]">
      <Canvas
        camera={{ position: [0, 0, 6], fov: 50 }}
        gl={{ antialias: true, alpha: true }}
        dpr={[1, 2]}
      >
        <Suspense fallback={null}>
          <IsabellaScene />
        </Suspense>
      </Canvas>

      {/* Status indicator */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2">
        <div className={`px-4 py-2 rounded-full glass-card border transition-all ${
          isSpeaking 
            ? 'border-isabella-pink/50 bg-isabella-pink/10' 
            : isListening 
              ? 'border-primary/50 bg-primary/10' 
              : 'border-border/50'
        }`}>
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${
              isSpeaking 
                ? 'bg-isabella-pink animate-pulse' 
                : isListening 
                  ? 'bg-primary animate-pulse' 
                  : 'bg-muted-foreground'
            }`} />
            <span className="text-sm font-display">
              {isSpeaking ? 'Isabella habla...' : isListening ? 'Escuchando...' : 'Lista'}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
