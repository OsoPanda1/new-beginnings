import { Suspense, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { 
  Environment, 
  Float, 
  Stars,
  Sparkles,
  MeshTransmissionMaterial,
  Text3D,
  Center
} from '@react-three/drei';
import { QuantumSphere } from './QuantumSphere';
import { ParticleField } from './ParticleField';
import { OrbitalRings } from './OrbitalRings';
import { FloatingCube } from './FloatingCube';
import * as THREE from 'three';

function CoreStructure() {
  const groupRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = state.clock.elapsedTime * 0.05;
    }
  });

  return (
    <group ref={groupRef}>
      {/* Central quantum core */}
      <Float speed={1.5} rotationIntensity={0.5} floatIntensity={0.5}>
        <QuantumSphere 
          position={[0, 0, 0]} 
          color="#00d4ff" 
          scale={1.5}
          distort={0.3}
          speed={1.5}
        />
      </Float>

      {/* Orbital rings around core */}
      <OrbitalRings count={4} radius={2.5} color="#00d4ff" />

      {/* Floating data cubes */}
      <FloatingCube position={[-4, 2, -2]} size={0.8} color="#d4af37" wireframe />
      <FloatingCube position={[4, -1, -3]} size={0.6} color="#8b5cf6" wireframe />
      <FloatingCube position={[-3, -2, 1]} size={0.7} color="#00d4ff" wireframe />
      <FloatingCube position={[3.5, 1.5, 2]} size={0.5} color="#d4af37" wireframe />

      {/* Satellite spheres */}
      <Float speed={2} rotationIntensity={1} floatIntensity={1}>
        <QuantumSphere position={[5, 0, 0]} color="#d4af37" scale={0.4} distort={0.5} />
      </Float>
      <Float speed={2.5} rotationIntensity={1.2} floatIntensity={1.2}>
        <QuantumSphere position={[-5, 1, 2]} color="#8b5cf6" scale={0.3} distort={0.6} />
      </Float>
      <Float speed={1.8} rotationIntensity={0.8} floatIntensity={0.8}>
        <QuantumSphere position={[0, -4, 0]} color="#22c55e" scale={0.35} distort={0.4} />
      </Float>
    </group>
  );
}

function SceneContent() {
  return (
    <>
      {/* Ambient lighting */}
      <ambientLight intensity={0.2} />
      <pointLight position={[10, 10, 10]} intensity={1} color="#00d4ff" />
      <pointLight position={[-10, -10, -10]} intensity={0.5} color="#d4af37" />
      <spotLight
        position={[0, 15, 0]}
        angle={0.3}
        penumbra={1}
        intensity={1}
        color="#ffffff"
        castShadow
      />

      {/* Background elements */}
      <Stars radius={50} depth={50} count={3000} factor={4} saturation={0} fade speed={0.5} />
      <Sparkles count={200} scale={15} size={2} speed={0.3} color="#00d4ff" />
      
      {/* Particle field */}
      <ParticleField count={1500} spread={20} size={0.02} />

      {/* Main 3D structure */}
      <CoreStructure />

      {/* Environment for reflections */}
      <Environment preset="night" />

      {/* Fog for depth */}
      <fog attach="fog" args={['#030712', 10, 50]} />
    </>
  );
}

export function HeroScene() {
  return (
    <div className="absolute inset-0 z-0">
      <Canvas
        camera={{ position: [0, 0, 12], fov: 60 }}
        gl={{ 
          antialias: true, 
          alpha: true,
          powerPreference: 'high-performance'
        }}
        dpr={[1, 2]}
      >
        <Suspense fallback={null}>
          <SceneContent />
        </Suspense>
      </Canvas>
    </div>
  );
}
