import { Suspense, useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float, Sparkles, MeshDistortMaterial } from '@react-three/drei';
import { useDevicePerformance } from '@/hooks/use-device-performance';
import * as THREE from 'three';

function EyeOfRa() {
  const eyeRef = useRef<THREE.Group>(null);
  const irisRef = useRef<THREE.Mesh>(null);
  const pupilRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (eyeRef.current) {
      eyeRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.3) * 0.2;
    }
    if (irisRef.current) {
      irisRef.current.rotation.z = state.clock.elapsedTime * 0.5;
    }
    if (pupilRef.current) {
      const pulse = 0.3 + Math.sin(state.clock.elapsedTime * 3) * 0.05;
      pupilRef.current.scale.setScalar(pulse);
    }
  });

  return (
    <group ref={eyeRef}>
      {/* Outer eye shape */}
      <mesh>
        <torusGeometry args={[1, 0.15, 16, 50]} />
        <meshStandardMaterial
          color="#d4af37"
          emissive="#d4af37"
          emissiveIntensity={0.3}
          metalness={0.8}
          roughness={0.2}
        />
      </mesh>

      {/* Iris */}
      <mesh ref={irisRef}>
        <ringGeometry args={[0.4, 0.8, 32]} />
        <meshStandardMaterial
          color="#00d4ff"
          emissive="#00d4ff"
          emissiveIntensity={0.5}
          side={THREE.DoubleSide}
        />
      </mesh>

      {/* Pupil */}
      <mesh ref={pupilRef} position={[0, 0, 0.1]}>
        <sphereGeometry args={[0.3, 32, 32]} />
        <MeshDistortMaterial
          color="#030712"
          emissive="#ef4444"
          emissiveIntensity={0.3}
          distort={0.2}
          speed={3}
        />
      </mesh>

      {/* Inner glow */}
      <mesh position={[0, 0, -0.1]}>
        <circleGeometry args={[0.9, 32]} />
        <meshBasicMaterial color="#d4af37" transparent opacity={0.1} side={THREE.DoubleSide} />
      </mesh>
    </group>
  );
}

function ShieldLayers() {
  const shieldsRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (shieldsRef.current) {
      shieldsRef.current.rotation.y = state.clock.elapsedTime * 0.1;
    }
  });

  const layers = [
    { radius: 1.8, color: '#22c55e', opacity: 0.15 },
    { radius: 2.2, color: '#00d4ff', opacity: 0.12 },
    { radius: 2.6, color: '#8b5cf6', opacity: 0.1 },
    { radius: 3.0, color: '#d4af37', opacity: 0.08 },
  ];

  return (
    <group ref={shieldsRef}>
      {layers.map((layer, i) => (
        <mesh key={i} rotation={[Math.PI / 4 + i * 0.2, i * 0.3, 0]}>
          <torusGeometry args={[layer.radius, 0.02, 8, 50]} />
          <meshStandardMaterial
            color={layer.color}
            emissive={layer.color}
            emissiveIntensity={0.5}
            transparent
            opacity={0.5}
          />
        </mesh>
      ))}
    </group>
  );
}

function AlertParticles() {
  const points = useRef<THREE.Points>(null);
  const count = 50;

  const positions = useMemo(() => {
    const pos = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.random() * Math.PI;
      const radius = 2 + Math.random() * 1.5;
      pos[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
      pos[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
      pos[i * 3 + 2] = radius * Math.cos(phi);
    }
    return pos;
  }, []);

  useFrame((state) => {
    if (points.current) {
      points.current.rotation.y = state.clock.elapsedTime * 0.2;
      points.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.3) * 0.1;
    }
  });

  return (
    <points ref={points}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" count={count} array={positions} itemSize={3} />
      </bufferGeometry>
      <pointsMaterial size={0.1} color="#ef4444" transparent opacity={0.8} />
    </points>
  );
}

function SceneContent() {
  const { level } = useDevicePerformance();

  return (
    <>
      <ambientLight intensity={0.15} />
      <pointLight position={[5, 5, 5]} intensity={0.5} color="#d4af37" />
      <pointLight position={[-5, -5, 5]} intensity={0.3} color="#ef4444" />

      <Float speed={1} rotationIntensity={0.2} floatIntensity={0.2}>
        <EyeOfRa />
      </Float>

      <ShieldLayers />
      
      {level !== 'low' && <AlertParticles />}

      <Sparkles count={level === 'low' ? 20 : 60} scale={6} size={2} speed={0.3} color="#d4af37" />

      <fog attach="fog" args={['#030712', 5, 20]} />
    </>
  );
}

export function SentinelScene() {
  const { dpr, isMobile } = useDevicePerformance();

  return (
    <div className="absolute inset-0 z-0 opacity-40">
      <Canvas
        camera={{ position: [0, 0, 6], fov: 50 }}
        gl={{ antialias: !isMobile, alpha: true, powerPreference: 'high-performance' }}
        dpr={dpr}
      >
        <Suspense fallback={null}>
          <SceneContent />
        </Suspense>
      </Canvas>
    </div>
  );
}
