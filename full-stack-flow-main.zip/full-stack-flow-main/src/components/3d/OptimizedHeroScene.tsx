import { Suspense, useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { 
  Environment, 
  Float, 
  Stars,
  Sparkles,
  useDetectGPU,
  AdaptiveDpr,
  AdaptiveEvents,
  BakeShadows,
  Preload
} from '@react-three/drei';
import { QuantumSphere } from './QuantumSphere';
import { ParticleField } from './ParticleField';
import { OrbitalRings } from './OrbitalRings';
import { FloatingCube } from './FloatingCube';
import { useDevicePerformance } from '@/hooks/use-device-performance';
import * as THREE from 'three';

// Componente de partículas optimizado con LOD
function OptimizedParticles({ count }: { count: number }) {
  const points = useRef<THREE.Points>(null);
  
  const positions = useMemo(() => {
    const pos = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 30;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 30;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 30;
    }
    return pos;
  }, [count]);

  const colors = useMemo(() => {
    const cols = new Float32Array(count * 3);
    const colorPalette = [
      [0, 0.83, 1],      // cyan
      [0.83, 0.69, 0.22], // gold
      [0.55, 0.36, 0.96], // purple
    ];
    for (let i = 0; i < count; i++) {
      const color = colorPalette[i % colorPalette.length];
      cols[i * 3] = color[0];
      cols[i * 3 + 1] = color[1];
      cols[i * 3 + 2] = color[2];
    }
    return cols;
  }, [count]);

  useFrame((state) => {
    if (points.current) {
      points.current.rotation.y = state.clock.elapsedTime * 0.02;
      points.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.01) * 0.1;
    }
  });

  return (
    <points ref={points}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={count}
          array={positions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-color"
          count={count}
          array={colors}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.05}
        vertexColors
        transparent
        opacity={0.8}
        sizeAttenuation
        depthWrite={false}
      />
    </points>
  );
}

// Estructura central con LOD
function CoreStructure({ performanceLevel }: { performanceLevel: 'low' | 'medium' | 'high' }) {
  const groupRef = useRef<THREE.Group>(null);
  
  const cubeCount = performanceLevel === 'low' ? 2 : performanceLevel === 'medium' ? 3 : 4;
  const satelliteCount = performanceLevel === 'low' ? 1 : performanceLevel === 'medium' ? 2 : 3;

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = state.clock.elapsedTime * 0.03;
    }
  });

  return (
    <group ref={groupRef}>
      {/* Central quantum core */}
      <Float speed={1.2} rotationIntensity={0.3} floatIntensity={0.3}>
        <QuantumSphere 
          position={[0, 0, 0]} 
          color="#00d4ff" 
          scale={1.8}
          distort={performanceLevel === 'low' ? 0.1 : 0.25}
          speed={1.2}
        />
      </Float>

      {/* Orbital rings */}
      <OrbitalRings 
        count={performanceLevel === 'low' ? 2 : 3} 
        radius={2.8} 
        color="#00d4ff" 
      />

      {/* Floating cubes - adaptado según rendimiento */}
      {cubeCount >= 1 && <FloatingCube position={[-4, 2, -2]} size={0.9} color="#d4af37" wireframe />}
      {cubeCount >= 2 && <FloatingCube position={[4, -1, -3]} size={0.7} color="#8b5cf6" wireframe />}
      {cubeCount >= 3 && <FloatingCube position={[-3, -2, 1]} size={0.8} color="#00d4ff" wireframe />}
      {cubeCount >= 4 && <FloatingCube position={[3.5, 1.5, 2]} size={0.6} color="#d4af37" wireframe />}

      {/* Satellite spheres - adaptado según rendimiento */}
      {satelliteCount >= 1 && (
        <Float speed={1.5} rotationIntensity={0.6} floatIntensity={0.6}>
          <QuantumSphere position={[5.5, 0, 0]} color="#d4af37" scale={0.5} distort={0.3} />
        </Float>
      )}
      {satelliteCount >= 2 && (
        <Float speed={1.8} rotationIntensity={0.8} floatIntensity={0.8}>
          <QuantumSphere position={[-5, 1.5, 2]} color="#8b5cf6" scale={0.4} distort={0.4} />
        </Float>
      )}
      {satelliteCount >= 3 && (
        <Float speed={1.4} rotationIntensity={0.5} floatIntensity={0.5}>
          <QuantumSphere position={[0, -4.5, 0]} color="#22c55e" scale={0.45} distort={0.3} />
        </Float>
      )}
    </group>
  );
}

// Contenido de la escena optimizado
function SceneContent() {
  const { level, particleCount, starCount, enablePostProcessing } = useDevicePerformance();

  return (
    <>
      {/* Iluminación optimizada */}
      <ambientLight intensity={0.15} />
      <pointLight position={[10, 10, 10]} intensity={0.8} color="#00d4ff" />
      {level !== 'low' && (
        <pointLight position={[-10, -10, -10]} intensity={0.4} color="#d4af37" />
      )}
      {level === 'high' && (
        <spotLight
          position={[0, 15, 0]}
          angle={0.3}
          penumbra={1}
          intensity={0.8}
          color="#ffffff"
        />
      )}

      {/* Estrellas de fondo - optimizado */}
      <Stars 
        radius={50} 
        depth={50} 
        count={starCount} 
        factor={3} 
        saturation={0} 
        fade 
        speed={0.3} 
      />
      
      {/* Sparkles solo si no es bajo rendimiento */}
      {level !== 'low' && (
        <Sparkles 
          count={level === 'high' ? 150 : 80} 
          scale={12} 
          size={1.5} 
          speed={0.2} 
          color="#00d4ff" 
        />
      )}
      
      {/* Partículas optimizadas */}
      <OptimizedParticles count={particleCount} />

      {/* Estructura principal 3D */}
      <CoreStructure performanceLevel={level} />

      {/* Environment solo si el dispositivo lo soporta */}
      {enablePostProcessing && <Environment preset="night" />}

      {/* Fog para profundidad */}
      <fog attach="fog" args={['#030712', 8, 45]} />
    </>
  );
}

export function OptimizedHeroScene() {
  const { dpr, isMobile } = useDevicePerformance();

  return (
    <div className="absolute inset-0 z-0">
      <Canvas
        camera={{ position: [0, 0, isMobile ? 14 : 12], fov: isMobile ? 65 : 60 }}
        gl={{ 
          antialias: !isMobile,
          alpha: true,
          powerPreference: 'high-performance',
          stencil: false,
          depth: true
        }}
        dpr={dpr}
        frameloop="demand"
      >
        <Suspense fallback={null}>
          <AdaptiveDpr pixelated />
          <AdaptiveEvents />
          <SceneContent />
          <Preload all />
        </Suspense>
      </Canvas>
    </div>
  );
}
