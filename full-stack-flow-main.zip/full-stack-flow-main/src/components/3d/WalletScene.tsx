import { Suspense, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float, Sparkles, MeshDistortMaterial, RoundedBox } from '@react-three/drei';
import { useDevicePerformance } from '@/hooks/use-device-performance';
import * as THREE from 'three';

function Vault() {
  const groupRef = useRef<THREE.Group>(null);
  const ringRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.3) * 0.1;
    }
    if (ringRef.current) {
      ringRef.current.rotation.z = state.clock.elapsedTime * 0.5;
    }
  });

  return (
    <group ref={groupRef}>
      {/* Main vault body */}
      <Float speed={1} rotationIntensity={0.2} floatIntensity={0.3}>
        <RoundedBox args={[2, 2, 0.5]} radius={0.1} smoothness={4}>
          <meshStandardMaterial
            color="#d4af37"
            metalness={0.9}
            roughness={0.1}
            emissive="#d4af37"
            emissiveIntensity={0.1}
          />
        </RoundedBox>
      </Float>

      {/* Security ring */}
      <mesh ref={ringRef} position={[0, 0, 0.3]}>
        <torusGeometry args={[1.3, 0.05, 16, 100]} />
        <meshStandardMaterial
          color="#00d4ff"
          emissive="#00d4ff"
          emissiveIntensity={0.5}
          transparent
          opacity={0.8}
        />
      </mesh>

      {/* Inner core */}
      <mesh position={[0, 0, 0.3]}>
        <sphereGeometry args={[0.3, 32, 32]} />
        <MeshDistortMaterial
          color="#d4af37"
          emissive="#d4af37"
          emissiveIntensity={0.5}
          distort={0.2}
          speed={3}
        />
      </mesh>

      {/* Shield particles */}
      <Sparkles
        count={40}
        scale={3}
        size={2}
        speed={0.5}
        color="#d4af37"
        position={[0, 0, 0]}
      />
    </group>
  );
}

function CoinParticles() {
  const groupRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = state.clock.elapsedTime * 0.2;
    }
  });

  return (
    <group ref={groupRef}>
      {[...Array(6)].map((_, i) => {
        const angle = (i / 6) * Math.PI * 2;
        const radius = 3;
        return (
          <Float key={i} speed={1 + i * 0.2} floatIntensity={0.5}>
            <mesh position={[Math.cos(angle) * radius, Math.sin(i) * 0.5, Math.sin(angle) * radius]}>
              <cylinderGeometry args={[0.15, 0.15, 0.03, 16]} />
              <meshStandardMaterial
                color="#d4af37"
                metalness={0.9}
                roughness={0.1}
                emissive="#d4af37"
                emissiveIntensity={0.2}
              />
            </mesh>
          </Float>
        );
      })}
    </group>
  );
}

function SceneContent() {
  const { level } = useDevicePerformance();

  return (
    <>
      <ambientLight intensity={0.2} />
      <pointLight position={[5, 5, 5]} intensity={0.8} color="#d4af37" />
      <pointLight position={[-5, 5, -5]} intensity={0.5} color="#00d4ff" />
      <spotLight position={[0, 10, 0]} angle={0.3} penumbra={1} intensity={0.5} />

      <Vault />
      {level !== 'low' && <CoinParticles />}

      <fog attach="fog" args={['#030712', 5, 25]} />
    </>
  );
}

export function WalletScene() {
  const { dpr, isMobile } = useDevicePerformance();

  return (
    <div className="absolute inset-0 z-0 opacity-40">
      <Canvas
        camera={{ position: [0, 0, 6], fov: 50 }}
        gl={{ antialias: !isMobile, alpha: true, powerPreference: 'high-performance' }}
        dpr={dpr}
      >
        <Suspense fallback={null}>
          <SceneContent />
        </Suspense>
      </Canvas>
    </div>
  );
}
