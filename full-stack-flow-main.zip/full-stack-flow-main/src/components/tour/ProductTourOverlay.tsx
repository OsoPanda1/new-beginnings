import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ChevronRight, ChevronLeft, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { 
  ProductTourStep, 
  ProductTourState, 
  TAMV_TOUR_STEPS,
  shouldShowTour,
  startTour,
  nextStep,
  completeTour,
  resetTour
} from '@/data/tour-steps';

interface ProductTourOverlayProps {
  onComplete?: () => void;
}

export function ProductTourOverlay({ onComplete }: ProductTourOverlayProps) {
  const [tourState, setTourState] = useState<ProductTourState>({ isActive: false, currentStepIndex: 0 });
  const [targetRect, setTargetRect] = useState<DOMRect | null>(null);

  const currentStep = TAMV_TOUR_STEPS[tourState.currentStepIndex];

  // Verificar si mostrar el tour al montar
  useEffect(() => {
    const timer = setTimeout(() => {
      if (shouldShowTour()) {
        setTourState(startTour());
      }
    }, 2000); // Esperar 2 segundos antes de mostrar

    return () => clearTimeout(timer);
  }, []);

  // Encontrar y resaltar el elemento objetivo
  useEffect(() => {
    if (!tourState.isActive || !currentStep) return;

    const findElement = () => {
      const element = document.querySelector(currentStep.targetSelector);
      if (element) {
        const rect = element.getBoundingClientRect();
        setTargetRect(rect);
        element.scrollIntoView({ behavior: 'smooth', block: 'center' });
      } else {
        setTargetRect(null);
      }
    };

    findElement();
    window.addEventListener('resize', findElement);
    window.addEventListener('scroll', findElement);

    return () => {
      window.removeEventListener('resize', findElement);
      window.removeEventListener('scroll', findElement);
    };
  }, [tourState.isActive, tourState.currentStepIndex, currentStep]);

  const handleNext = useCallback(() => {
    const newState = nextStep(tourState);
    if (!newState.isActive) {
      completeTour();
      setTourState({ isActive: false, currentStepIndex: 0 });
      onComplete?.();
    } else {
      setTourState(newState);
    }
  }, [tourState, onComplete]);

  const handlePrev = useCallback(() => {
    if (tourState.currentStepIndex > 0) {
      setTourState(prev => ({ ...prev, currentStepIndex: prev.currentStepIndex - 1 }));
    }
  }, [tourState.currentStepIndex]);

  const handleSkip = useCallback(() => {
    completeTour();
    setTourState({ isActive: false, currentStepIndex: 0 });
    onComplete?.();
  }, [onComplete]);

  // Función para reiniciar el tour (exportada para uso externo)
  const restartTour = useCallback(() => {
    resetTour();
    setTourState(startTour());
  }, []);

  // Exponer restartTour globalmente para uso desde otros componentes
  useEffect(() => {
    (window as any).restartTAMVTour = restartTour;
    return () => {
      delete (window as any).restartTAMVTour;
    };
  }, [restartTour]);

  if (!tourState.isActive || !currentStep) return null;

  // Calcular posición del tooltip
  const getTooltipPosition = () => {
    if (!targetRect) {
      return { top: '50%', left: '50%', transform: 'translate(-50%, -50%)' };
    }

    const padding = 20;
    const tooltipWidth = 320;
    const tooltipHeight = 200;

    switch (currentStep.position) {
      case 'bottom':
        return {
          top: `${targetRect.bottom + padding}px`,
          left: `${Math.max(padding, Math.min(targetRect.left + targetRect.width / 2 - tooltipWidth / 2, window.innerWidth - tooltipWidth - padding))}px`,
        };
      case 'top':
        return {
          top: `${targetRect.top - tooltipHeight - padding}px`,
          left: `${Math.max(padding, Math.min(targetRect.left + targetRect.width / 2 - tooltipWidth / 2, window.innerWidth - tooltipWidth - padding))}px`,
        };
      case 'left':
        return {
          top: `${targetRect.top + targetRect.height / 2 - tooltipHeight / 2}px`,
          left: `${targetRect.left - tooltipWidth - padding}px`,
        };
      case 'right':
        return {
          top: `${targetRect.top + targetRect.height / 2 - tooltipHeight / 2}px`,
          left: `${targetRect.right + padding}px`,
        };
      default:
        return { top: '50%', left: '50%', transform: 'translate(-50%, -50%)' };
    }
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[9999] pointer-events-auto"
      >
        {/* Overlay oscuro con recorte para el elemento resaltado */}
        <svg className="absolute inset-0 w-full h-full">
          <defs>
            <mask id="tour-spotlight">
              <rect x="0" y="0" width="100%" height="100%" fill="white" />
              {targetRect && (
                <rect
                  x={targetRect.left - 8}
                  y={targetRect.top - 8}
                  width={targetRect.width + 16}
                  height={targetRect.height + 16}
                  rx="12"
                  fill="black"
                />
              )}
            </mask>
          </defs>
          <rect
            x="0"
            y="0"
            width="100%"
            height="100%"
            fill="rgba(0, 0, 0, 0.85)"
            mask="url(#tour-spotlight)"
          />
        </svg>

        {/* Borde brillante alrededor del elemento */}
        {targetRect && (
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="absolute pointer-events-none"
            style={{
              left: targetRect.left - 8,
              top: targetRect.top - 8,
              width: targetRect.width + 16,
              height: targetRect.height + 16,
            }}
          >
            <div className="absolute inset-0 rounded-xl border-2 border-primary animate-pulse" />
            <div className="absolute inset-0 rounded-xl bg-primary/10" />
          </motion.div>
        )}

        {/* Tooltip */}
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="absolute w-80 pointer-events-auto"
          style={getTooltipPosition()}
        >
          <div className="bg-card border border-border rounded-2xl shadow-2xl overflow-hidden">
            {/* Header */}
            <div className="bg-gradient-to-r from-primary/20 to-accent/20 p-4 border-b border-border">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-primary" />
                  <span className="text-xs text-muted-foreground">
                    Paso {tourState.currentStepIndex + 1} de {TAMV_TOUR_STEPS.length}
                  </span>
                </div>
                <button
                  onClick={handleSkip}
                  className="p-1 hover:bg-secondary rounded-lg transition-colors"
                >
                  <X className="w-4 h-4 text-muted-foreground" />
                </button>
              </div>
            </div>

            {/* Content */}
            <div className="p-4">
              <h3 className="font-display text-lg font-bold text-foreground mb-2">
                {currentStep.title}
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {currentStep.description}
              </p>
            </div>

            {/* Progress Bar */}
            <div className="px-4 pb-2">
              <div className="flex gap-1">
                {TAMV_TOUR_STEPS.map((_, i) => (
                  <div
                    key={i}
                    className={`h-1 flex-1 rounded-full transition-colors ${
                      i <= tourState.currentStepIndex ? 'bg-primary' : 'bg-muted'
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* Actions */}
            <div className="p-4 pt-2 flex items-center justify-between">
              <button
                onClick={handleSkip}
                className="text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                Omitir tour
              </button>
              <div className="flex gap-2">
                {tourState.currentStepIndex > 0 && (
                  <Button variant="ghost" size="sm" onClick={handlePrev}>
                    <ChevronLeft className="w-4 h-4" />
                  </Button>
                )}
                <Button variant="quantum" size="sm" onClick={handleNext}>
                  {tourState.currentStepIndex === TAMV_TOUR_STEPS.length - 1 ? (
                    'Finalizar'
                  ) : (
                    <>
                      Siguiente
                      <ChevronRight className="w-4 h-4 ml-1" />
                    </>
                  )}
                </Button>
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
