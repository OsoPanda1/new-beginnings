import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Maximize2, Minimize2, Volume2, VolumeX } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { VideoTutorial, formatDuration, LEVEL_LABELS, TUTORIAL_CATEGORIES } from '@/data/tutorials';

interface VideoPlayerProps {
  tutorial: VideoTutorial;
  onClose: () => void;
}

export function VideoPlayer({ tutorial, onClose }: VideoPlayerProps) {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isMuted, setIsMuted] = useState(false);

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[100] bg-background/95 backdrop-blur-xl flex items-center justify-center p-4"
        onClick={(e) => {
          if (e.target === e.currentTarget) onClose();
        }}
      >
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.95, opacity: 0 }}
          className={`bg-card rounded-2xl overflow-hidden border border-border shadow-2xl ${
            isFullscreen ? 'w-full h-full' : 'w-full max-w-4xl'
          }`}
        >
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-border">
            <div className="flex-1 min-w-0">
              <h2 className="font-display font-bold text-lg truncate">{tutorial.title}</h2>
              <div className="flex items-center gap-3 text-sm text-muted-foreground">
                <span>{TUTORIAL_CATEGORIES[tutorial.category].label}</span>
                <span>•</span>
                <span>{LEVEL_LABELS[tutorial.level]}</span>
                <span>•</span>
                <span>{formatDuration(tutorial.durationSeconds)}</span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon" onClick={() => setIsMuted(!isMuted)}>
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </Button>
              <Button variant="ghost" size="icon" onClick={toggleFullscreen}>
                {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
              </Button>
              <Button variant="ghost" size="icon" onClick={onClose}>
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Video Container */}
          <div className={`relative ${isFullscreen ? 'h-[calc(100%-80px)]' : 'aspect-video'}`}>
            <iframe
              src={`${tutorial.videoUrl}?autoplay=1&mute=${isMuted ? 1 : 0}`}
              className="w-full h-full"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </div>

          {/* Description (only when not fullscreen) */}
          {!isFullscreen && (
            <div className="p-4 border-t border-border">
              <p className="text-sm text-muted-foreground">{tutorial.description}</p>
            </div>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
