import { motion } from 'framer-motion';
import { Play, Clock, BookOpen } from 'lucide-react';
import { VideoTutorial, formatDuration, LEVEL_LABELS, TUTORIAL_CATEGORIES } from '@/data/tutorials';

interface TutorialCardProps {
  tutorial: VideoTutorial;
  onClick: () => void;
  index?: number;
}

export function TutorialCard({ tutorial, onClick, index = 0 }: TutorialCardProps) {
  const levelColors = {
    basico: 'bg-success/10 text-success border-success/30',
    intermedio: 'bg-warning/10 text-warning border-warning/30',
    avanzado: 'bg-primary/10 text-primary border-primary/30'
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      onClick={onClick}
      className="glass-card rounded-xl overflow-hidden cursor-pointer group hover:ring-2 hover:ring-primary/50 transition-all duration-300"
    >
      {/* Thumbnail Placeholder */}
      <div className="relative aspect-video bg-gradient-to-br from-primary/20 via-accent/20 to-nebula-purple/20 overflow-hidden">
        {/* Animated Background Pattern */}
        <div className="absolute inset-0 grid-pattern opacity-30" />
        
        {/* Play Button Overlay */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-background/50 backdrop-blur-sm">
          <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center shadow-lg shadow-primary/30">
            <Play className="w-8 h-8 text-primary-foreground ml-1" />
          </div>
        </div>

        {/* Duration Badge */}
        <div className="absolute bottom-2 right-2 px-2 py-1 rounded-md bg-background/80 backdrop-blur-sm text-xs font-mono flex items-center gap-1">
          <Clock className="w-3 h-3" />
          {formatDuration(tutorial.durationSeconds)}
        </div>

        {/* Category Icon */}
        <div className="absolute top-2 left-2 w-10 h-10 rounded-lg bg-background/80 backdrop-blur-sm flex items-center justify-center">
          <BookOpen className="w-5 h-5 text-primary" />
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        <div className="flex items-center gap-2 mb-2">
          <span className={`px-2 py-0.5 rounded-full text-xs font-medium border ${levelColors[tutorial.level]}`}>
            {LEVEL_LABELS[tutorial.level]}
          </span>
          <span className="text-xs text-muted-foreground">
            {TUTORIAL_CATEGORIES[tutorial.category].label}
          </span>
        </div>

        <h3 className="font-display font-semibold text-foreground mb-2 line-clamp-2 group-hover:text-primary transition-colors">
          {tutorial.title}
        </h3>

        <p className="text-sm text-muted-foreground line-clamp-2">
          {tutorial.description}
        </p>
      </div>
    </motion.div>
  );
}
