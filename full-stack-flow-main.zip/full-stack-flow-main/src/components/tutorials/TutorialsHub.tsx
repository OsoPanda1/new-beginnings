import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Search, Filter, BookOpen, GraduationCap, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { TutorialCard } from './TutorialCard';
import { VideoPlayer } from './VideoPlayer';
import { 
  VideoTutorial, 
  TutorialCategory, 
  TUTORIALS, 
  TUTORIAL_CATEGORIES,
  LEVEL_LABELS,
  filterTutorials 
} from '@/data/tutorials';

interface TutorialsHubProps {
  isOpen: boolean;
  onClose: () => void;
}

export function TutorialsHub({ isOpen, onClose }: TutorialsHubProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<TutorialCategory | undefined>();
  const [selectedLevel, setSelectedLevel] = useState<VideoTutorial['level'] | undefined>();
  const [selectedTutorial, setSelectedTutorial] = useState<VideoTutorial | null>(null);

  // Filtrar tutoriales
  const filteredTutorials = filterTutorials(TUTORIALS, selectedCategory, selectedLevel)
    .filter(t => 
      searchQuery === '' || 
      t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.description.toLowerCase().includes(searchQuery.toLowerCase())
    );

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[100] bg-background overflow-hidden"
      >
        {/* Header */}
        <div className="border-b border-border bg-card/50 backdrop-blur-xl sticky top-0 z-10">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                  <GraduationCap className="w-5 h-5 text-primary-foreground" />
                </div>
                <div>
                  <h1 className="font-display text-xl font-bold">Centro de Tutoriales</h1>
                  <p className="text-sm text-muted-foreground">Aprende a dominar TAMV ONLINE</p>
                </div>
              </div>
              <Button variant="ghost" size="icon" onClick={onClose}>
                <X className="w-5 h-5" />
              </Button>
            </div>

            {/* Search and Filters */}
            <div className="flex flex-col md:flex-row gap-4">
              {/* Search */}
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar tutoriales..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>

              {/* Category Filter */}
              <div className="flex gap-2 overflow-x-auto pb-2 md:pb-0">
                <Button
                  variant={selectedCategory === undefined ? 'quantum' : 'outline'}
                  size="sm"
                  onClick={() => setSelectedCategory(undefined)}
                >
                  Todos
                </Button>
                {(Object.keys(TUTORIAL_CATEGORIES) as TutorialCategory[]).slice(0, 4).map((cat) => (
                  <Button
                    key={cat}
                    variant={selectedCategory === cat ? 'quantum' : 'outline'}
                    size="sm"
                    onClick={() => setSelectedCategory(cat === selectedCategory ? undefined : cat)}
                    className="whitespace-nowrap"
                  >
                    {TUTORIAL_CATEGORIES[cat].label}
                  </Button>
                ))}
              </div>
            </div>

            {/* Level Filter */}
            <div className="flex gap-2 mt-3">
              <span className="text-sm text-muted-foreground flex items-center gap-1">
                <Filter className="w-3 h-3" />
                Nivel:
              </span>
              {(['basico', 'intermedio', 'avanzado'] as const).map((level) => (
                <button
                  key={level}
                  onClick={() => setSelectedLevel(level === selectedLevel ? undefined : level)}
                  className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${
                    selectedLevel === level
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-secondary text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {LEVEL_LABELS[level]}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="container mx-auto px-4 py-6 overflow-y-auto h-[calc(100vh-200px)]">
          {filteredTutorials.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredTutorials.map((tutorial, index) => (
                <TutorialCard
                  key={tutorial.id}
                  tutorial={tutorial}
                  index={index}
                  onClick={() => setSelectedTutorial(tutorial)}
                />
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-16">
              <BookOpen className="w-16 h-16 text-muted-foreground mb-4" />
              <h3 className="font-display text-lg font-semibold mb-2">No hay tutoriales</h3>
              <p className="text-muted-foreground text-center max-w-md">
                No se encontraron tutoriales con los filtros seleccionados. 
                Intenta con otros criterios de búsqueda.
              </p>
              <Button
                variant="outline"
                className="mt-4"
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory(undefined);
                  setSelectedLevel(undefined);
                }}
              >
                Limpiar filtros
              </Button>
            </div>
          )}

          {/* Featured Section */}
          {!searchQuery && !selectedCategory && !selectedLevel && (
            <div className="mt-12">
              <div className="flex items-center gap-2 mb-6">
                <Sparkles className="w-5 h-5 text-accent" />
                <h2 className="font-display text-lg font-semibold">Destacados</h2>
              </div>
              <div className="glass-card rounded-2xl p-6 bg-gradient-to-br from-primary/10 via-transparent to-accent/10">
                <div className="flex flex-col md:flex-row gap-6 items-center">
                  <div className="flex-1">
                    <h3 className="font-display text-2xl font-bold mb-2">
                      ¿Nuevo en TAMV?
                    </h3>
                    <p className="text-muted-foreground mb-4">
                      Comienza con nuestra serie de tutoriales básicos y domina todas las 
                      funciones de la plataforma en menos de una hora.
                    </p>
                    <Button variant="quantum" onClick={() => setSelectedLevel('basico')}>
                      Ver tutoriales básicos
                    </Button>
                  </div>
                  <div className="w-full md:w-48 h-32 rounded-xl bg-gradient-to-br from-primary/30 to-accent/30 flex items-center justify-center">
                    <GraduationCap className="w-16 h-16 text-primary" />
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Video Player Modal */}
        {selectedTutorial && (
          <VideoPlayer
            tutorial={selectedTutorial}
            onClose={() => setSelectedTutorial(null)}
          />
        )}
      </motion.div>
    </AnimatePresence>
  );
}
