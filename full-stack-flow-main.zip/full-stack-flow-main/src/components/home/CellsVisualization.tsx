import { motion } from "framer-motion";
import { CellsNetwork } from "@/components/3d/CellsNetwork";
import { Button } from "@/components/ui/button";
import { ArrowRight, Network, Shield, Zap } from "lucide-react";
import { Link } from "react-router-dom";

export function CellsVisualization() {
  return (
    <section className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 grid-pattern opacity-30" />
      <div className="container mx-auto px-4 relative">
        <motion.div 
          initial={{ opacity: 0, y: 30 }} 
          whileInView={{ opacity: 1, y: 0 }} 
          viewport={{ once: true }} 
          className="text-center max-w-3xl mx-auto mb-12"
        >
          <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-success/10 border border-success/30 text-success text-sm font-display mb-4">
            <Network className="w-4 h-4" />
            Red Federada
          </span>
          <h2 className="font-display text-4xl md:text-6xl font-bold mb-6">
            <span className="text-foreground">Organismo </span>
            <span className="text-gradient-gold">Nacional</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            Visualización 3D en tiempo real de las Cells Federadas conectadas al BookPI Ledger.
          </p>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }} 
          whileInView={{ opacity: 1, scale: 1 }} 
          viewport={{ once: true }} 
          className="mb-12"
        >
          <CellsNetwork />
        </motion.div>

        <div className="grid md:grid-cols-3 gap-6 mb-8">
          {[
            { icon: Network, title: "Arquitectura Federada", desc: "Cada cell opera autónoma con sincronización al ledger central.", color: "primary" },
            { icon: Shield, title: "Auto-sanación", desc: "Detección y aislamiento automático de cells comprometidas.", color: "success" },
            { icon: Zap, title: "Failover Instantáneo", desc: "Redirección automática a cells de respaldo.", color: "warning" }
          ].map((f, i) => (
            <div key={i} className="glass-card rounded-xl p-6">
              <f.icon className={`w-8 h-8 text-${f.color} mb-3`} />
              <h3 className="font-display font-semibold mb-2">{f.title}</h3>
              <p className="text-sm text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </div>

        <div className="text-center">
          <Link to="/cells">
            <Button variant="cell" size="lg">
              Explorar Cells
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
