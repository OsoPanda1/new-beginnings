import { motion } from "framer-motion";
import { IsabellaAvatar } from "@/components/3d/IsabellaAvatar";
import { Button } from "@/components/ui/button";
import { MessageCircle, Sparkles, Brain, Heart, Shield } from "lucide-react";
import { Link } from "react-router-dom";

export function IsabellaSection() {
  return (
    <section className="py-24 relative overflow-hidden bg-gradient-to-b from-background via-isabella-pink/5 to-background">
      {/* Background effects */}
      <div className="absolute inset-0 aztec-pattern" />
      
      <div className="container mx-auto px-4 relative">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="order-2 lg:order-1"
          >
            <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-isabella-pink/10 border border-isabella-pink/30 text-isabella-pink text-sm font-display mb-4">
              <Sparkles className="w-4 h-4" />
              Inteligencia Artificial
            </span>
            
            <h2 className="font-display text-4xl md:text-6xl font-bold mb-6">
              <span className="text-foreground">Conoce a </span>
              <span className="bg-gradient-to-r from-isabella-pink to-nebula-purple bg-clip-text text-transparent">
                Isabella
              </span>
            </h2>
            
            <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
              Tu asistente IA conversacional con alma latina. Isabella combina inteligencia artificial 
              avanzada con comprensión cultural profunda para guiarte en el ecosistema TAMV.
            </p>

            {/* Capabilities */}
            <div className="grid grid-cols-2 gap-4 mb-8">
              {[
                { icon: Brain, label: "Procesamiento Quantum" },
                { icon: Heart, label: "Empatía Cultural" },
                { icon: Shield, label: "Privacidad Total" },
                { icon: MessageCircle, label: "Multilingüe" },
              ].map((cap, i) => (
                <motion.div
                  key={cap.label}
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: 0.3 + i * 0.1 }}
                  className="flex items-center gap-3 p-3 rounded-lg glass-card"
                >
                  <div className="w-8 h-8 rounded-lg bg-isabella-pink/10 flex items-center justify-center">
                    <cap.icon className="w-4 h-4 text-isabella-pink" />
                  </div>
                  <span className="text-sm font-medium">{cap.label}</span>
                </motion.div>
              ))}
            </div>

            <Link to="/isabella">
              <Button variant="isabella" size="lg" className="group">
                <MessageCircle className="mr-2 w-5 h-5" />
                Conversar con Isabella
              </Button>
            </Link>
          </motion.div>

          {/* 3D Avatar */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="order-1 lg:order-2"
          >
            <div className="relative">
              {/* Glow effect behind avatar */}
              <div className="absolute inset-0 bg-gradient-radial from-isabella-pink/20 via-transparent to-transparent blur-3xl" />
              
              <IsabellaAvatar />
              
              {/* Floating info cards */}
              <motion.div
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                className="absolute top-8 right-0 glass-card px-4 py-2 rounded-lg border border-isabella-pink/20"
              >
                <span className="text-xs text-muted-foreground">Tiempo de respuesta</span>
                <div className="font-display font-bold text-isabella-pink">{"<"}50ms</div>
              </motion.div>
              
              <motion.div
                animate={{ y: [0, 10, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut", delay: 1 }}
                className="absolute bottom-24 left-0 glass-card px-4 py-2 rounded-lg border border-nebula-purple/20"
              >
                <span className="text-xs text-muted-foreground">Idiomas soportados</span>
                <div className="font-display font-bold text-nebula-purple">15+</div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
