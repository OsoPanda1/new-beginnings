import { useRef, ReactNode } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';

interface ParallaxSectionProps {
  children: ReactNode;
  className?: string;
  speed?: number;
  direction?: 'up' | 'down';
}

export function ParallaxSection({ 
  children, 
  className = '', 
  speed = 0.5,
  direction = 'up' 
}: ParallaxSectionProps) {
  const ref = useRef<HTMLDivElement>(null);
  
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start end', 'end start']
  });

  const multiplier = direction === 'up' ? -1 : 1;
  const y = useTransform(scrollYProgress, [0, 1], [100 * speed * multiplier, -100 * speed * multiplier]);
  const opacity = useTransform(scrollYProgress, [0, 0.2, 0.8, 1], [0, 1, 1, 0]);
  const scale = useTransform(scrollYProgress, [0, 0.2, 0.8, 1], [0.95, 1, 1, 0.95]);

  return (
    <div ref={ref} className={`relative overflow-hidden ${className}`}>
      <motion.div style={{ y, opacity, scale }}>
        {children}
      </motion.div>
    </div>
  );
}

interface Parallax3DProps {
  children: ReactNode;
  className?: string;
  rotateX?: number;
  rotateY?: number;
  translateZ?: number;
}

export function Parallax3D({ 
  children, 
  className = '',
  rotateX = 10,
  rotateY = 5,
  translateZ = 50
}: Parallax3DProps) {
  const ref = useRef<HTMLDivElement>(null);
  
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start end', 'end start']
  });

  const rotX = useTransform(scrollYProgress, [0, 0.5, 1], [rotateX, 0, -rotateX]);
  const rotY = useTransform(scrollYProgress, [0, 0.5, 1], [-rotateY, 0, rotateY]);
  const transZ = useTransform(scrollYProgress, [0, 0.5, 1], [-translateZ, 0, -translateZ]);
  const opacity = useTransform(scrollYProgress, [0, 0.15, 0.85, 1], [0, 1, 1, 0]);

  return (
    <div ref={ref} className={`relative ${className}`} style={{ perspective: '1000px' }}>
      <motion.div 
        style={{ 
          rotateX: rotX, 
          rotateY: rotY, 
          z: transZ,
          opacity,
          transformStyle: 'preserve-3d'
        }}
      >
        {children}
      </motion.div>
    </div>
  );
}

interface FloatingElementProps {
  children: ReactNode;
  className?: string;
  delay?: number;
  duration?: number;
  amplitude?: number;
}

export function FloatingElement({ 
  children, 
  className = '',
  delay = 0,
  duration = 6,
  amplitude = 20
}: FloatingElementProps) {
  return (
    <motion.div
      className={className}
      animate={{
        y: [0, -amplitude, 0],
        rotateZ: [-1, 1, -1]
      }}
      transition={{
        duration,
        delay,
        repeat: Infinity,
        ease: 'easeInOut'
      }}
    >
      {children}
    </motion.div>
  );
}

interface GlowOrbProps {
  className?: string;
  color?: 'primary' | 'accent' | 'purple' | 'pink';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  blur?: 'sm' | 'md' | 'lg';
  animated?: boolean;
}

export function GlowOrb({ 
  className = '',
  color = 'primary',
  size = 'md',
  blur = 'md',
  animated = true
}: GlowOrbProps) {
  const colorClasses = {
    primary: 'bg-primary/30',
    accent: 'bg-accent/30',
    purple: 'bg-nebula-purple/30',
    pink: 'bg-isabella-pink/30'
  };

  const sizeClasses = {
    sm: 'w-32 h-32',
    md: 'w-64 h-64',
    lg: 'w-96 h-96',
    xl: 'w-[500px] h-[500px]'
  };

  const blurClasses = {
    sm: 'blur-2xl',
    md: 'blur-3xl',
    lg: 'blur-[100px]'
  };

  return (
    <motion.div
      className={`absolute rounded-full ${colorClasses[color]} ${sizeClasses[size]} ${blurClasses[blur]} ${className}`}
      animate={animated ? {
        scale: [1, 1.2, 1],
        opacity: [0.3, 0.5, 0.3]
      } : undefined}
      transition={{
        duration: 8,
        repeat: Infinity,
        ease: 'easeInOut'
      }}
    />
  );
}

interface ScrollRevealProps {
  children: ReactNode;
  className?: string;
  delay?: number;
  direction?: 'up' | 'down' | 'left' | 'right';
}

export function ScrollReveal({ 
  children, 
  className = '',
  delay = 0,
  direction = 'up'
}: ScrollRevealProps) {
  const directionVariants = {
    up: { y: 60, x: 0 },
    down: { y: -60, x: 0 },
    left: { x: 60, y: 0 },
    right: { x: -60, y: 0 }
  };

  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, ...directionVariants[direction] }}
      whileInView={{ opacity: 1, y: 0, x: 0 }}
      viewport={{ once: true, margin: '-100px' }}
      transition={{ duration: 0.8, delay, ease: [0.25, 0.1, 0.25, 1] }}
    >
      {children}
    </motion.div>
  );
}
