import { motion } from 'framer-motion';
import { 
  Video, 
  Music, 
  Image, 
  MessageCircle, 
  Heart, 
  Share2, 
  Trophy, 
  Wallet,
  Globe,
  Sparkles
} from 'lucide-react';
import { ScrollReveal, FloatingElement, GlowOrb } from './ParallaxSection';

const socialFeatures = [
  {
    icon: Video,
    title: 'KAOS Visuals',
    description: 'Reels inmersivos con efectos cuánticos',
    color: 'from-red-500 to-pink-500'
  },
  {
    icon: Music,
    title: 'Conciertos Sensoriales',
    description: 'Experiencias musicales en DreamSpaces',
    color: 'from-purple-500 to-indigo-500'
  },
  {
    icon: Image,
    title: 'Galleries NFT',
    description: 'Arte digital con propiedad verificable',
    color: 'from-blue-500 to-cyan-500'
  },
  {
    icon: MessageCircle,
    title: 'Puentes Oníricos',
    description: 'Match colaborativo con creadores afines',
    color: 'from-green-500 to-teal-500'
  },
  {
    icon: Heart,
    title: 'Reactions Cuánticas',
    description: 'Emociones que resuenan en el metaverso',
    color: 'from-pink-500 to-rose-500'
  },
  {
    icon: Share2,
    title: 'Cross-Reality Sharing',
    description: 'Comparte entre realidades XR',
    color: 'from-orange-500 to-amber-500'
  },
  {
    icon: Trophy,
    title: 'Lucha Libre Challenges',
    description: 'Retos gamificados con recompensas',
    color: 'from-yellow-500 to-orange-500'
  },
  {
    icon: Wallet,
    title: 'Banco TAMV',
    description: 'Economía soberana para creadores',
    color: 'from-emerald-500 to-green-500'
  },
  {
    icon: Globe,
    title: 'DreamSpaces XR',
    description: 'Mundos virtuales personalizables',
    color: 'from-violet-500 to-purple-500'
  },
  {
    icon: Sparkles,
    title: 'Isabella IA',
    description: 'Tu compañera cuántica emocional',
    color: 'from-pink-500 to-purple-500'
  }
];

export function SocialFeaturesSection() {
  return (
    <section className="py-32 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-card/30 to-background" />
      <GlowOrb color="purple" size="xl" blur="lg" className="-top-48 -left-48 opacity-20" />
      <GlowOrb color="pink" size="lg" blur="lg" className="-bottom-32 -right-32 opacity-20" />

      <div className="container mx-auto px-4 relative z-10">
        {/* Header */}
        <ScrollReveal className="text-center max-w-4xl mx-auto mb-20">
          <motion.span 
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 border border-accent/30 text-accent text-sm font-display mb-6"
            whileHover={{ scale: 1.05 }}
          >
            <Globe className="w-4 h-4" />
            Metaverso Social
          </motion.span>
          <h2 className="font-display text-4xl md:text-6xl font-bold mb-6">
            Lo mejor de <span className="text-gradient">10 plataformas</span>
            <br />en un solo ecosistema
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Fusionamos las mejores características visuales e interactivas de TikTok, Instagram, 
            Twitch, Discord, LinkedIn, Meta Horizon, y más. Todo bajo el paradigma de soberanía digital.
          </p>
        </ScrollReveal>

        {/* Features Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 md:gap-6">
          {socialFeatures.map((feature, index) => (
            <ScrollReveal key={feature.title} delay={index * 0.05}>
              <FloatingElement delay={index * 0.3} amplitude={5} duration={4 + index * 0.5}>
                <motion.div
                  whileHover={{ scale: 1.05, y: -5 }}
                  whileTap={{ scale: 0.98 }}
                  className="group relative p-6 rounded-2xl bg-card/50 backdrop-blur-sm border border-border hover:border-primary/50 transition-all duration-300 cursor-pointer h-full"
                >
                  {/* Glow on hover */}
                  <div className="absolute inset-0 rounded-2xl bg-gradient-to-br opacity-0 group-hover:opacity-10 transition-opacity duration-300" 
                    style={{ 
                      backgroundImage: `linear-gradient(to bottom right, var(--tw-gradient-stops))`,
                    }}
                  />
                  
                  {/* Icon */}
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                    <feature.icon className="w-6 h-6 text-white" />
                  </div>

                  {/* Content */}
                  <h3 className="font-display font-semibold text-sm mb-1 group-hover:text-primary transition-colors">
                    {feature.title}
                  </h3>
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    {feature.description}
                  </p>
                </motion.div>
              </FloatingElement>
            </ScrollReveal>
          ))}
        </div>

        {/* Bottom Stats */}
        <ScrollReveal delay={0.5} className="mt-20">
          <div className="flex flex-wrap justify-center gap-8 md:gap-16">
            {[
              { value: '10+', label: 'Plataformas fusionadas' },
              { value: '50+', label: 'Características únicas' },
              { value: '∞', label: 'Posibilidades creativas' }
            ].map((stat) => (
              <motion.div 
                key={stat.label}
                whileHover={{ scale: 1.1 }}
                className="text-center"
              >
                <div className="font-display text-4xl md:text-5xl font-bold text-gradient mb-2">
                  {stat.value}
                </div>
                <div className="text-sm text-muted-foreground uppercase tracking-wider">
                  {stat.label}
                </div>
              </motion.div>
            ))}
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}
