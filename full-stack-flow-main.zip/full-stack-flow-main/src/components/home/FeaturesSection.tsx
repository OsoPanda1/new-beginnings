import { motion } from "framer-motion";
import { 
  Cpu, 
  Brain, 
  Shield, 
  BookOpen, 
  Zap, 
  Eye, 
  Coins, 
  Sparkles, 
  Fingerprint,
  ArrowUpRight
} from "lucide-react";
import { Link } from "react-router-dom";

const features = [
  {
    icon: Cpu,
    title: "Cells Federadas",
    description: "Red de nodos autónomos que operan como un organismo vivo, capaces de auto-sanarse y resistir ataques.",
    color: "text-success",
    bg: "bg-success/10",
    href: "/cells"
  },
  {
    icon: Brain,
    title: "Isabella IA",
    description: "Asistente conversacional con alma latina y procesamiento quantum para guiarte en el ecosistema.",
    color: "text-isabella-pink",
    bg: "bg-isabella-pink/10",
    href: "/isabella"
  },
  {
    icon: Shield,
    title: "Dekateotl Security",
    description: "10 capas de seguridad inspiradas en el panteón mexica. Protección divina para tus datos.",
    color: "text-destructive",
    bg: "bg-destructive/10",
    href: "/sentinel"
  },
  {
    icon: BookOpen,
    title: "BookPI Ledger",
    description: "Registro inmutable con hash SHA-512 y timestamp legal para auditoría transparente.",
    color: "text-accent",
    bg: "bg-accent/10",
    href: "/dashboard"
  },
  {
    icon: Zap,
    title: "Quantum Mesh",
    description: "Capa de operaciones cuánticas para procesamiento de ultra-alta velocidad y encriptación.",
    color: "text-primary",
    bg: "bg-primary/10",
    href: "/quantum"
  },
  {
    icon: Eye,
    title: "Anubis Sentinel",
    description: "Sistema de monitoreo 24/7 que protege el ecosistema como el guardián del inframundo.",
    color: "text-warning",
    bg: "bg-warning/10",
    href: "/sentinel"
  },
  {
    icon: Coins,
    title: "Economía Digital",
    description: "Sistema monetario soberano con tokens nativos y exchange integrado.",
    color: "text-accent",
    bg: "bg-accent/10",
    href: "/wallet"
  },
  {
    icon: Sparkles,
    title: "DreamSpaces",
    description: "Espacios virtuales inmersivos para creadores donde la imaginación cobra vida.",
    color: "text-nebula-purple",
    bg: "bg-nebula-purple/10",
    href: "/dashboard"
  },
  {
    icon: Fingerprint,
    title: "ID-Nvida",
    description: "Identidad digital soberana verificable, portable y resistente a la censura.",
    color: "text-info",
    bg: "bg-info/10",
    href: "/auth"
  },
];

export function FeaturesSection() {
  return (
    <section className="py-24 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-card/50 to-background" />
      <div className="absolute inset-0 grid-pattern opacity-20" />

      <div className="container mx-auto px-4 relative">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/30 text-primary text-sm font-display mb-4">
            <Cpu className="w-4 h-4" />
            Ecosistema Completo
          </span>
          <h2 className="font-display text-4xl md:text-6xl font-bold mb-6">
            <span className="text-foreground">Tecnología </span>
            <span className="text-gradient">Soberana</span>
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Nueve pilares tecnológicos que conforman el ecosistema más avanzado de soberanía 
            digital para creadores latinoamericanos.
          </p>
        </motion.div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, i) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.05 }}
            >
              <Link to={feature.href}>
                <div className="group h-full glass-card rounded-2xl p-6 hover:border-primary/30 transition-all duration-300 hover:scale-[1.02] cursor-pointer">
                  {/* Icon */}
                  <div className={`w-14 h-14 rounded-xl ${feature.bg} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                    <feature.icon className={`w-7 h-7 ${feature.color}`} />
                  </div>

                  {/* Content */}
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-display text-xl font-semibold group-hover:text-primary transition-colors">
                      {feature.title}
                    </h3>
                    <ArrowUpRight className="w-5 h-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 group-hover:-translate-y-1 transition-all opacity-0 group-hover:opacity-100" />
                  </div>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {feature.description}
                  </p>

                  {/* Decorative line */}
                  <div className="mt-4 h-0.5 bg-gradient-to-r from-transparent via-border to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
