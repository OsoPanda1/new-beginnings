import { useState } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { WalletScene } from "@/components/3d/WalletScene";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Wallet as WalletIcon, 
  Plus, 
  Send, 
  Download, 
  ArrowUpRight, 
  ArrowDownLeft,
  Shield,
  Eye,
  EyeOff,
  Copy,
  ExternalLink,
  CreditCard,
  TrendingUp,
  Clock
} from "lucide-react";
import { toast } from "sonner";

interface Transaction {
  id: string;
  type: "in" | "out";
  amount: number;
  description: string;
  timestamp: Date;
  bookpi_hash: string;
}

const mockTransactions: Transaction[] = [
  { id: "tx-001", type: "in", amount: 500, description: "Compra de créditos", timestamp: new Date(Date.now() - 3600000), bookpi_hash: "sha512:abc123" },
  { id: "tx-002", type: "out", amount: 50, description: "Operación cuántica", timestamp: new Date(Date.now() - 7200000), bookpi_hash: "sha512:def456" },
  { id: "tx-003", type: "in", amount: 1000, description: "Recompensa comunitaria", timestamp: new Date(Date.now() - 86400000), bookpi_hash: "sha512:ghi789" },
  { id: "tx-004", type: "out", amount: 25, description: "Isabella IA Premium", timestamp: new Date(Date.now() - 172800000), bookpi_hash: "sha512:jkl012" },
  { id: "tx-005", type: "out", amount: 100, description: "DreamSpace Ticket", timestamp: new Date(Date.now() - 259200000), bookpi_hash: "sha512:mno345" },
];

export default function Wallet() {
  const [showBalance, setShowBalance] = useState(true);
  const [transactions] = useState<Transaction[]>(mockTransactions);
  
  const balance = 2325;
  const walletId = "0x7a9B...c3D4";

  const handleCopyAddress = () => {
    navigator.clipboard.writeText("0x7a9B1234567890abcdef1234567890abcdef1234c3D4");
    toast.success("Dirección copiada al portapapeles");
  };

  return (
    <div className="min-h-screen bg-background relative">
      <WalletScene />
      <Navbar />
      
      <main className="pt-20 pb-12">
        <div className="container mx-auto px-4 max-w-4xl">
          {/* Header */}
          <div className="mb-8">
            <h1 className="font-display text-2xl md:text-3xl font-bold mb-2">
              Wallet <span className="text-gradient-gold">Soberano</span>
            </h1>
            <p className="text-muted-foreground">
              Gestiona tus créditos TAMV con seguridad Ojo de Ra
            </p>
          </div>

          {/* Balance Card */}
          <div className="glass-card rounded-2xl p-6 md:p-8 mb-6 relative overflow-hidden">
            {/* Background Pattern */}
            <div className="absolute inset-0 aztec-pattern" />
            <div className="absolute inset-0 bg-gradient-to-br from-accent/10 via-transparent to-primary/10" />
            
            <div className="relative z-10">
              <div className="flex items-start justify-between mb-6">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Balance Total</p>
                  <div className="flex items-center gap-3">
                    <h2 className="font-display text-4xl md:text-5xl font-bold">
                      {showBalance ? `${balance.toLocaleString()} TAM` : "••••••"}
                    </h2>
                    <button
                      onClick={() => setShowBalance(!showBalance)}
                      className="p-2 rounded-lg hover:bg-secondary transition-colors"
                    >
                      {showBalance ? (
                        <EyeOff className="w-5 h-5 text-muted-foreground" />
                      ) : (
                        <Eye className="w-5 h-5 text-muted-foreground" />
                      )}
                    </button>
                  </div>
                  <p className="text-sm text-success mt-1 flex items-center gap-1">
                    <TrendingUp className="w-4 h-4" />
                    +12.5% este mes
                  </p>
                </div>
                <div className="flex items-center gap-2 p-3 rounded-xl bg-success/10 border border-success/30">
                  <Shield className="w-5 h-5 text-success" />
                  <span className="text-sm font-medium text-success">KYC Verificado</span>
                </div>
              </div>

              {/* Wallet ID */}
              <div className="flex items-center gap-2 p-3 rounded-lg bg-secondary/50 mb-6">
                <WalletIcon className="w-4 h-4 text-muted-foreground" />
                <span className="font-mono text-sm">{walletId}</span>
                <button onClick={handleCopyAddress} className="ml-auto p-1 hover:bg-secondary rounded">
                  <Copy className="w-4 h-4 text-muted-foreground" />
                </button>
              </div>

              {/* Quick Actions */}
              <div className="grid grid-cols-3 gap-3">
                <Button variant="aztec" className="flex-col h-auto py-4">
                  <Plus className="w-5 h-5 mb-1" />
                  <span className="text-xs">Comprar</span>
                </Button>
                <Button variant="outline" className="flex-col h-auto py-4">
                  <Send className="w-5 h-5 mb-1" />
                  <span className="text-xs">Enviar</span>
                </Button>
                <Button variant="outline" className="flex-col h-auto py-4">
                  <Download className="w-5 h-5 mb-1" />
                  <span className="text-xs">Retirar</span>
                </Button>
              </div>
            </div>
          </div>

          {/* Stats Row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            {[
              { label: "Recibido", value: "1,500 TAM", icon: ArrowDownLeft, color: "success" },
              { label: "Enviado", value: "175 TAM", icon: ArrowUpRight, color: "warning" },
              { label: "En Proceso", value: "0 TAM", icon: Clock, color: "info" },
              { label: "Transacciones", value: "23", icon: CreditCard, color: "primary" },
            ].map((stat) => {
              const Icon = stat.icon;
              return (
                <div key={stat.label} className="glass-card rounded-xl p-4">
                  <div className={`w-8 h-8 rounded-lg bg-${stat.color}/10 flex items-center justify-center mb-2`}>
                    <Icon className={`w-4 h-4 text-${stat.color}`} />
                  </div>
                  <div className="font-display font-bold">{stat.value}</div>
                  <div className="text-xs text-muted-foreground">{stat.label}</div>
                </div>
              );
            })}
          </div>

          {/* Transactions */}
          <div className="glass-card rounded-xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="font-display text-lg font-semibold">Historial de Transacciones</h2>
              <Button variant="ghost" size="sm">
                Ver Todo
                <ExternalLink className="w-4 h-4 ml-2" />
              </Button>
            </div>

            <div className="space-y-3">
              {transactions.map((tx) => (
                <div
                  key={tx.id}
                  className="flex items-center gap-4 p-4 rounded-lg bg-secondary/30 hover:bg-secondary/50 transition-colors"
                >
                  {/* Icon */}
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    tx.type === "in" ? "bg-success/20" : "bg-warning/20"
                  }`}>
                    {tx.type === "in" ? (
                      <ArrowDownLeft className="w-5 h-5 text-success" />
                    ) : (
                      <ArrowUpRight className="w-5 h-5 text-warning" />
                    )}
                  </div>

                  {/* Info */}
                  <div className="flex-1">
                    <div className="font-medium text-sm">{tx.description}</div>
                    <div className="text-xs text-muted-foreground">
                      {tx.timestamp.toLocaleDateString()} • {tx.timestamp.toLocaleTimeString()}
                    </div>
                  </div>

                  {/* Amount */}
                  <div className="text-right">
                    <div className={`font-display font-bold ${
                      tx.type === "in" ? "text-success" : "text-foreground"
                    }`}>
                      {tx.type === "in" ? "+" : "-"}{tx.amount} TAM
                    </div>
                    <div className="text-xs text-muted-foreground font-mono truncate max-w-24">
                      {tx.bookpi_hash}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Security Notice */}
          <div className="mt-6 p-4 rounded-xl bg-accent/10 border border-accent/30">
            <div className="flex items-start gap-3">
              <Shield className="w-5 h-5 text-accent mt-0.5" />
              <div>
                <h3 className="font-semibold text-sm mb-1">Protección Ojo de Ra</h3>
                <p className="text-xs text-muted-foreground">
                  Todas las transacciones son monitoreadas por nuestro sistema anti-fraude que detecta 
                  patrones sospechosos, anomalías de velocidad y discrepancias de geolocalización. 
                  Cada movimiento queda registrado en BookPI con evidencia inmutable.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
