import { useState, useRef, useEffect } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { IsabellaScene } from "@/components/3d/IsabellaScene";
import { IsabellaChat } from "@/components/isabella/IsabellaChat";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Send, 
  Brain, 
  Sparkles, 
  Heart, 
  Shield, 
  Info,
  Mic,
  Paperclip,
  MoreVertical,
  User,
  Loader2
} from "lucide-react";
import { useIsabellaChat } from "@/hooks/useIsabellaChat";
import { useAuth } from "@/hooks/useAuth";
import { Link } from "react-router-dom";

const suggestedQuestions = [
  "¿Qué es el ecosistema TAMV ONLINE?",
  "¿Cómo funciona la seguridad Dekateotl?",
  "Explícame el sistema BookPI",
  "¿Qué son las Cells Federadas?",
];

export default function Isabella() {
  const { user, loading: authLoading } = useAuth();
  const { messages, isLoading, error, sendMessage } = useIsabellaChat();
  const [input, setInput] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;
    const message = input;
    setInput("");
    await sendMessage(message);
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background relative">
      <IsabellaScene />
      <Navbar />
      
      <main className="pt-16 h-screen flex flex-col">
        <div className="flex-1 container mx-auto px-4 py-4 flex flex-col max-w-4xl">
          {/* Header */}
          <div className="glass-card rounded-xl p-4 mb-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-isabella-pink to-nebula-purple flex items-center justify-center">
                    <Brain className="w-6 h-6 text-foreground" />
                  </div>
                  <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-success rounded-full border-2 border-card" />
                </div>
                <div>
                  <h1 className="font-display text-lg font-semibold flex items-center gap-2">
                    Isabella IA™
                    <Sparkles className="w-4 h-4 text-isabella-pink" />
                  </h1>
                  <p className="text-xs text-muted-foreground">Inteligencia Cuántica Emocional • Online</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {user && (
                  <span className="text-xs text-muted-foreground hidden sm:block">
                    {user.email}
                  </span>
                )}
                <Button variant="ghost" size="icon">
                  <Info className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Check if user is logged in */}
          {!user ? (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center glass-card rounded-2xl p-8 max-w-md">
                <div className="w-20 h-20 rounded-full bg-gradient-to-br from-isabella-pink/20 to-nebula-purple/20 flex items-center justify-center mx-auto mb-6">
                  <Brain className="w-10 h-10 text-isabella-pink" />
                </div>
                <h2 className="font-display text-xl font-semibold mb-3">Conecta con Isabella</h2>
                <p className="text-muted-foreground mb-6">
                  Inicia sesión para conversar con Isabella IA y obtener respuestas personalizadas sobre el ecosistema TAMV.
                </p>
                <Link to="/auth">
                  <Button variant="quantum" size="lg">Iniciar Sesión</Button>
                </Link>
              </div>
            </div>
          ) : (
            <>
              {/* Messages Area */}
              <div className="flex-1 overflow-y-auto mb-4 space-y-4">
                {messages.length === 0 && (
                  <div className="flex flex-col items-center justify-center h-full text-center p-8">
                    <div className="w-20 h-20 rounded-full bg-gradient-to-br from-isabella-pink/20 to-nebula-purple/20 flex items-center justify-center mb-6">
                      <Brain className="w-10 h-10 text-isabella-pink" />
                    </div>
                    <h2 className="font-display text-xl font-semibold mb-3">
                      ¡Hola, querido creador! ✨
                    </h2>
                    <p className="text-muted-foreground max-w-md mb-4">
                      Soy Isabella, tu guía en el ecosistema TAMV. Estoy aquí para ayudarte, 
                      educarte y protegerte con mi motor cuántico-emocional.
                    </p>
                  </div>
                )}

                {messages.map((message, index) => (
                  <div
                    key={index}
                    className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className={`flex gap-3 max-w-[85%] ${
                        message.role === "user" ? "flex-row-reverse" : ""
                      }`}
                    >
                      {/* Avatar */}
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                          message.role === "user"
                            ? "bg-primary/20"
                            : "bg-gradient-to-br from-isabella-pink to-nebula-purple"
                        }`}
                      >
                        {message.role === "user" ? (
                          <User className="w-4 h-4 text-primary" />
                        ) : (
                          <Brain className="w-4 h-4 text-foreground" />
                        )}
                      </div>

                      {/* Message Bubble */}
                      <div
                        className={`rounded-2xl px-4 py-3 ${
                          message.role === "user"
                            ? "bg-primary text-primary-foreground rounded-tr-md"
                            : "glass-card rounded-tl-md"
                        }`}
                      >
                        <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.content}</p>
                      </div>
                    </div>
                  </div>
                ))}

                {/* Typing Indicator */}
                {isLoading && (
                  <div className="flex justify-start">
                    <div className="flex gap-3">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-isabella-pink to-nebula-purple flex items-center justify-center">
                        <Brain className="w-4 h-4 text-foreground" />
                      </div>
                      <div className="glass-card rounded-2xl rounded-tl-md px-4 py-3">
                        <div className="flex items-center gap-2">
                          <Loader2 className="w-4 h-4 animate-spin text-isabella-pink" />
                          <span className="text-sm text-muted-foreground">Isabella está pensando...</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                <div ref={messagesEndRef} />
              </div>

              {/* Suggested Questions */}
              {messages.length === 0 && (
                <div className="mb-4">
                  <p className="text-xs text-muted-foreground mb-2">Preguntas sugeridas:</p>
                  <div className="flex flex-wrap gap-2">
                    {suggestedQuestions.map((question) => (
                      <button
                        key={question}
                        onClick={() => setInput(question)}
                        className="px-3 py-1.5 rounded-full text-xs bg-secondary hover:bg-secondary/80 transition-colors"
                      >
                        {question}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Error Display */}
              {error && (
                <div className="mb-4 p-3 rounded-lg bg-destructive/10 border border-destructive/20">
                  <p className="text-sm text-destructive">{error}</p>
                </div>
              )}

              {/* Input Area */}
              <div className="glass-card rounded-xl p-3">
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="icon" className="flex-shrink-0">
                    <Paperclip className="w-4 h-4" />
                  </Button>
                  <Input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && handleSend()}
                    placeholder="Escribe un mensaje a Isabella..."
                    className="flex-1 bg-transparent border-0 focus-visible:ring-0"
                  />
                  <Button variant="ghost" size="icon" className="flex-shrink-0">
                    <Mic className="w-4 h-4" />
                  </Button>
                  <Button 
                    variant="quantum" 
                    size="icon" 
                    onClick={handleSend}
                    disabled={!input.trim() || isLoading}
                    className="flex-shrink-0"
                  >
                    {isLoading ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Send className="w-4 h-4" />
                    )}
                  </Button>
                </div>
                
                {/* Footer Info */}
                <div className="flex items-center justify-center gap-2 mt-2 pt-2 border-t border-border/50">
                  <Shield className="w-3 h-3 text-success" />
                  <span className="text-xs text-muted-foreground">
                    Conversación auditada en BookPI • Privacidad garantizada
                  </span>
                </div>
              </div>
            </>
          )}
        </div>
      </main>
    </div>
  );
}