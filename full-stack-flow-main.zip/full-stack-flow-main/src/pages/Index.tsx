import { useState } from "react";
import { motion } from "framer-motion";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { HeroSection } from "@/components/home/HeroSection";
import { FeaturesSection } from "@/components/home/FeaturesSection";
import { SocialFeaturesSection } from "@/components/home/SocialFeaturesSection";
import { CellsVisualization } from "@/components/home/CellsVisualization";
import { IsabellaSection } from "@/components/home/IsabellaSection";
import { CTASection } from "@/components/home/CTASection";
import { ProductTourOverlay } from "@/components/tour/ProductTourOverlay";
import { TutorialsHub } from "@/components/tutorials/TutorialsHub";
import { ParallaxSection, GlowOrb } from "@/components/home/ParallaxSection";
import { HelpCircle } from "lucide-react";

const Index = () => {
  const [showTutorials, setShowTutorials] = useState(false);

  return (
    <div className="min-h-screen bg-background overflow-x-hidden">
      <Navbar />
      
      {/* Floating Glow Orbs */}
      <GlowOrb color="primary" size="xl" blur="lg" className="fixed -top-64 -left-64 opacity-20 pointer-events-none" />
      <GlowOrb color="accent" size="lg" blur="lg" className="fixed top-1/2 -right-32 opacity-15 pointer-events-none" />
      <GlowOrb color="purple" size="xl" blur="lg" className="fixed -bottom-64 left-1/4 opacity-15 pointer-events-none" />

      <main>
        {/* Hero with Parallax */}
        <section id="tamv-hero">
          <HeroSection />
        </section>

        {/* Social Features with Parallax */}
        <ParallaxSection speed={0.3}>
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
          >
            <SocialFeaturesSection />
          </motion.div>
        </ParallaxSection>

        {/* Features with 3D Parallax */}
        <ParallaxSection speed={0.2} direction="down">
          <section id="tamv-features">
            <FeaturesSection />
          </section>
        </ParallaxSection>

        {/* Cells Visualization */}
        <ParallaxSection speed={0.4}>
          <section id="tamv-cells-viz">
            <CellsVisualization />
          </section>
        </ParallaxSection>

        {/* Isabella Section */}
        <ParallaxSection speed={0.3} direction="down">
          <section id="tamv-isabella">
            <IsabellaSection />
          </section>
        </ParallaxSection>

        {/* CTA Section */}
        <section id="tamv-cta">
          <CTASection />
        </section>
      </main>
      
      <Footer />
      
      {/* Product Tour */}
      <ProductTourOverlay />
      
      {/* Tutorials Hub */}
      <TutorialsHub isOpen={showTutorials} onClose={() => setShowTutorials(false)} />
      
      {/* Help Button */}
      <motion.button
        onClick={() => setShowTutorials(true)}
        className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full bg-gradient-to-r from-primary to-accent shadow-lg shadow-primary/30 flex items-center justify-center hover:scale-110 transition-transform"
        aria-label="Abrir tutoriales"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.5 }}
      >
        <HelpCircle className="w-6 h-6 text-primary-foreground" />
      </motion.button>
    </div>
  );
};

export default Index;