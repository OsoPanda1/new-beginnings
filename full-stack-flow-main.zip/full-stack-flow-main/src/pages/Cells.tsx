import { useState } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { CellsScene } from "@/components/3d/CellsScene";
import { Button } from "@/components/ui/button";
import { 
  Cpu, 
  CheckCircle, 
  AlertTriangle, 
  XCircle, 
  Pause,
  Activity,
  HardDrive,
  Network,
  RefreshCw,
  Settings,
  Eye,
  ChevronDown,
  ChevronUp
} from "lucide-react";

interface Cell {
  id: string;
  name: string;
  description: string;
  status: "healthy" | "degraded" | "failover" | "isolated";
  metrics: {
    cpu: number;
    memory: number;
    latency: number;
    uptime: string;
    requests: number;
  };
  lastSync: Date;
}

const cellsData: Cell[] = [
  {
    id: "edu",
    name: "Cell Educación",
    description: "Servicios educativos, cursos, certificaciones y contenido académico",
    status: "healthy",
    metrics: { cpu: 23, memory: 45, latency: 12, uptime: "99.99%", requests: 15420 },
    lastSync: new Date(Date.now() - 120000),
  },
  {
    id: "salud",
    name: "Cell Salud",
    description: "Telemedicina, registros médicos, bienestar y citas",
    status: "healthy",
    metrics: { cpu: 34, memory: 52, latency: 18, uptime: "99.95%", requests: 8930 },
    lastSync: new Date(Date.now() - 180000),
  },
  {
    id: "fintech",
    name: "Cell Fintech",
    description: "Servicios financieros, pagos, créditos y wallet",
    status: "degraded",
    metrics: { cpu: 78, memory: 85, latency: 45, uptime: "99.5%", requests: 45200 },
    lastSync: new Date(Date.now() - 60000),
  },
  {
    id: "cultura",
    name: "Cell Cultura",
    description: "Arte, música, eventos culturales y patrimonio",
    status: "healthy",
    metrics: { cpu: 15, memory: 32, latency: 8, uptime: "99.99%", requests: 6780 },
    lastSync: new Date(Date.now() - 300000),
  },
  {
    id: "defensa",
    name: "Cell Defensa",
    description: "Ciberseguridad, protección de datos y respuesta a incidentes",
    status: "healthy",
    metrics: { cpu: 45, memory: 60, latency: 15, uptime: "100%", requests: 120500 },
    lastSync: new Date(Date.now() - 30000),
  },
  {
    id: "ambiente",
    name: "Cell Ambiente",
    description: "Monitoreo ambiental, sostenibilidad y recursos naturales",
    status: "healthy",
    metrics: { cpu: 28, memory: 40, latency: 10, uptime: "99.98%", requests: 3420 },
    lastSync: new Date(Date.now() - 240000),
  },
  {
    id: "ciencia",
    name: "Cell Ciencia",
    description: "Investigación, laboratorios y publicaciones científicas",
    status: "failover",
    metrics: { cpu: 92, memory: 95, latency: 120, uptime: "95.2%", requests: 1890 },
    lastSync: new Date(Date.now() - 900000),
  },
  {
    id: "gobierno",
    name: "Cell Gobierno",
    description: "Trámites, transparencia y servicios gubernamentales",
    status: "healthy",
    metrics: { cpu: 38, memory: 55, latency: 20, uptime: "99.9%", requests: 22100 },
    lastSync: new Date(Date.now() - 150000),
  },
];

const statusConfig = {
  healthy: { icon: CheckCircle, color: "success", label: "Saludable", bg: "bg-success/10 border-success/30" },
  degraded: { icon: AlertTriangle, color: "warning", label: "Degradado", bg: "bg-warning/10 border-warning/30" },
  failover: { icon: XCircle, color: "destructive", label: "Failover", bg: "bg-destructive/10 border-destructive/30" },
  isolated: { icon: Pause, color: "muted", label: "Aislado", bg: "bg-muted border-border" },
};

export default function Cells() {
  const [expandedCell, setExpandedCell] = useState<string | null>(null);
  const [cells] = useState<Cell[]>(cellsData);

  const healthyCells = cells.filter((c) => c.status === "healthy").length;
  const totalCells = cells.length;

  return (
    <div className="min-h-screen bg-background relative">
      <CellsScene />
      <Navbar />
      
      <main className="pt-20 pb-12">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
            <div>
              <h1 className="font-display text-2xl md:text-3xl font-bold mb-2">
                Cells <span className="text-gradient">Federadas</span>
              </h1>
              <p className="text-muted-foreground">
                Monitoreo y gestión del Organismo Nacional Líder
              </p>
            </div>
            <div className="flex items-center gap-3">
              <div className="glass-card rounded-lg px-4 py-2">
                <span className="text-sm text-muted-foreground">Estado Global:</span>
                <span className="ml-2 text-success font-semibold">{healthyCells}/{totalCells} Activas</span>
              </div>
              <Button variant="outline" size="icon">
                <RefreshCw className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Summary Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            {Object.entries(statusConfig).map(([key, config]) => {
              const count = cells.filter((c) => c.status === key).length;
              const Icon = config.icon;
              return (
                <div key={key} className={`rounded-xl p-4 border ${config.bg}`}>
                  <div className="flex items-center gap-2 mb-2">
                    <Icon className={`w-5 h-5 text-${config.color}`} />
                    <span className={`text-sm font-medium text-${config.color}`}>{config.label}</span>
                  </div>
                  <div className="font-display text-3xl font-bold">{count}</div>
                </div>
              );
            })}
          </div>

          {/* Cells Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {cells.map((cell) => {
              const status = statusConfig[cell.status];
              const StatusIcon = status.icon;
              const isExpanded = expandedCell === cell.id;

              return (
                <div
                  key={cell.id}
                  className={`glass-card rounded-xl overflow-hidden transition-all duration-300 ${
                    isExpanded ? "ring-2 ring-primary" : ""
                  }`}
                >
                  {/* Header */}
                  <div className="p-4 md:p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                          <Cpu className="w-6 h-6 text-primary" />
                        </div>
                        <div>
                          <h3 className="font-display font-semibold">{cell.name}</h3>
                          <p className="text-xs text-muted-foreground">{cell.description}</p>
                        </div>
                      </div>
                      <div className={`flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium ${status.bg}`}>
                        <StatusIcon className={`w-3 h-3 text-${status.color}`} />
                        <span className={`text-${status.color}`}>{status.label}</span>
                      </div>
                    </div>

                    {/* Quick Metrics */}
                    <div className="grid grid-cols-4 gap-3 mb-4">
                      <div className="text-center">
                        <Activity className="w-4 h-4 mx-auto text-muted-foreground mb-1" />
                        <div className="font-mono text-sm font-medium">{cell.metrics.cpu}%</div>
                        <div className="text-xs text-muted-foreground">CPU</div>
                      </div>
                      <div className="text-center">
                        <HardDrive className="w-4 h-4 mx-auto text-muted-foreground mb-1" />
                        <div className="font-mono text-sm font-medium">{cell.metrics.memory}%</div>
                        <div className="text-xs text-muted-foreground">MEM</div>
                      </div>
                      <div className="text-center">
                        <Network className="w-4 h-4 mx-auto text-muted-foreground mb-1" />
                        <div className="font-mono text-sm font-medium">{cell.metrics.latency}ms</div>
                        <div className="text-xs text-muted-foreground">LAT</div>
                      </div>
                      <div className="text-center">
                        <CheckCircle className="w-4 h-4 mx-auto text-muted-foreground mb-1" />
                        <div className="font-mono text-sm font-medium">{cell.metrics.uptime}</div>
                        <div className="text-xs text-muted-foreground">UP</div>
                      </div>
                    </div>

                    {/* Progress Bars */}
                    <div className="space-y-2 mb-4">
                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-muted-foreground">CPU</span>
                          <span>{cell.metrics.cpu}%</span>
                        </div>
                        <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                          <div
                            className={`h-full transition-all duration-500 ${
                              cell.metrics.cpu > 80 ? "bg-destructive" : cell.metrics.cpu > 60 ? "bg-warning" : "bg-success"
                            }`}
                            style={{ width: `${cell.metrics.cpu}%` }}
                          />
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-muted-foreground">Memory</span>
                          <span>{cell.metrics.memory}%</span>
                        </div>
                        <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                          <div
                            className={`h-full transition-all duration-500 ${
                              cell.metrics.memory > 80 ? "bg-destructive" : cell.metrics.memory > 60 ? "bg-warning" : "bg-success"
                            }`}
                            style={{ width: `${cell.metrics.memory}%` }}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-muted-foreground">
                        Última sync: {cell.lastSync.toLocaleTimeString()}
                      </span>
                      <div className="flex items-center gap-2">
                        <Button variant="ghost" size="sm">
                          <Eye className="w-4 h-4 mr-1" />
                          Detalles
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => setExpandedCell(isExpanded ? null : cell.id)}>
                          {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                        </Button>
                      </div>
                    </div>
                  </div>

                  {/* Expanded Content */}
                  {isExpanded && (
                    <div className="border-t border-border p-4 md:p-6 bg-secondary/30 animate-fade-in">
                      <h4 className="font-display text-sm font-semibold mb-3">Métricas Detalladas</h4>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-muted-foreground">Requests Hoy:</span>
                          <span className="ml-2 font-mono">{cell.metrics.requests.toLocaleString()}</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Uptime:</span>
                          <span className="ml-2 font-mono">{cell.metrics.uptime}</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Cell ID:</span>
                          <span className="ml-2 font-mono">cell-{cell.id}-prod</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Cluster:</span>
                          <span className="ml-2 font-mono">tamv-main-01</span>
                        </div>
                      </div>
                      <div className="mt-4 flex gap-2">
                        <Button variant="outline" size="sm">
                          <RefreshCw className="w-4 h-4 mr-1" />
                          Sync
                        </Button>
                        <Button variant="outline" size="sm">
                          <Settings className="w-4 h-4 mr-1" />
                          Configurar
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </main>
    </div>
  );
}
