import { useState } from "react";
import { Link } from "react-router-dom";
import { Navbar } from "@/components/layout/Navbar";
import { DashboardScene } from "@/components/3d/DashboardScene";
import { Button } from "@/components/ui/button";
import { 
  Cpu, 
  Users, 
  Activity, 
  TrendingUp, 
  Shield, 
  Wallet, 
  Bell, 
  Settings,
  MessageSquare,
  Atom,
  FileText,
  Eye,
  ChevronRight,
  CheckCircle,
  AlertTriangle,
  XCircle
} from "lucide-react";

const quickStats = [
  { label: "Cells Activas", value: "8/12", change: "+2", icon: Cpu, color: "primary" },
  { label: "Uptime", value: "99.9%", change: "+0.1%", icon: Activity, color: "success" },
  { label: "Operaciones Hoy", value: "12,456", change: "+15%", icon: TrendingUp, color: "accent" },
  { label: "Alertas", value: "3", change: "-2", icon: Bell, color: "warning" },
];

const recentActivity = [
  { type: "success", message: "Cell Educación sincronizada correctamente", time: "Hace 2 min", icon: CheckCircle },
  { type: "warning", message: "Cell Fintech en estado degradado", time: "Hace 15 min", icon: AlertTriangle },
  { type: "info", message: "Nueva operación cuántica completada", time: "Hace 32 min", icon: Atom },
  { type: "success", message: "Backup BookPI completado", time: "Hace 1 hora", icon: FileText },
  { type: "error", message: "Cell Ciencia en failover - restauración iniciada", time: "Hace 2 horas", icon: XCircle },
];

const quickActions = [
  { name: "Nueva Operación", icon: Atom, href: "/quantum", color: "primary" },
  { name: "Chat con Isabella", icon: MessageSquare, href: "/isabella", color: "isabella-pink" },
  { name: "Ver Wallet", icon: Wallet, href: "/wallet", color: "accent" },
  { name: "Sentinel", icon: Shield, href: "/sentinel", color: "success" },
];

export default function Dashboard() {
  const [selectedPeriod, setSelectedPeriod] = useState("24h");

  return (
    <div className="min-h-screen bg-background relative">
      <DashboardScene />
      <Navbar />
      
      <main className="pt-20 pb-12">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
            <div>
              <h1 className="font-display text-2xl md:text-3xl font-bold mb-1">
                Panel <span className="text-gradient">Universal</span>
              </h1>
              <p className="text-muted-foreground">
                Bienvenido al ecosistema TAMV ONLINE • Último acceso: Hoy, 10:30 AM
              </p>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1 bg-secondary rounded-lg p-1">
                {["24h", "7d", "30d"].map((period) => (
                  <button
                    key={period}
                    onClick={() => setSelectedPeriod(period)}
                    className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
                      selectedPeriod === period
                        ? "bg-primary text-primary-foreground"
                        : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {period}
                  </button>
                ))}
              </div>
              <Button variant="outline" size="icon">
                <Settings className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            {quickStats.map((stat) => {
              const Icon = stat.icon;
              return (
                <div key={stat.label} className="glass-card rounded-xl p-4 md:p-6">
                  <div className="flex items-center justify-between mb-3">
                    <div className={`w-10 h-10 rounded-lg bg-${stat.color}/10 flex items-center justify-center`}>
                      <Icon className={`w-5 h-5 text-${stat.color}`} />
                    </div>
                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full bg-${stat.color}/10 text-${stat.color}`}>
                      {stat.change}
                    </span>
                  </div>
                  <div className="font-display text-2xl md:text-3xl font-bold mb-1">{stat.value}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </div>
              );
            })}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Chart Area */}
            <div className="lg:col-span-2 glass-card rounded-xl p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="font-display text-lg font-semibold">Métricas del Sistema</h2>
                <Button variant="ghost" size="sm">
                  Ver Detalles
                  <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </div>
              
              {/* Placeholder Chart */}
              <div className="relative h-64 bg-secondary/30 rounded-lg overflow-hidden">
                <div className="absolute inset-0 grid-pattern opacity-30" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <Activity className="w-12 h-12 text-primary mb-3 mx-auto" />
                    <p className="text-muted-foreground">Gráficas de rendimiento en tiempo real</p>
                    <p className="text-xs text-muted-foreground mt-1">Latencia • CPU • Memoria • Red</p>
                  </div>
                </div>
                
                {/* Simulated Chart Lines */}
                <svg className="absolute inset-0 w-full h-full" preserveAspectRatio="none">
                  <defs>
                    <linearGradient id="chartGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity="0.3" />
                      <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity="0" />
                    </linearGradient>
                  </defs>
                  <path
                    d="M 0 200 Q 50 150, 100 160 T 200 140 T 300 120 T 400 130 T 500 100 T 600 110 T 700 80 V 256 H 0 Z"
                    fill="url(#chartGradient)"
                  />
                  <path
                    d="M 0 200 Q 50 150, 100 160 T 200 140 T 300 120 T 400 130 T 500 100 T 600 110 T 700 80"
                    fill="none"
                    stroke="hsl(var(--primary))"
                    strokeWidth="2"
                  />
                </svg>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="glass-card rounded-xl p-6">
              <h2 className="font-display text-lg font-semibold mb-4">Acciones Rápidas</h2>
              <div className="grid grid-cols-2 gap-3">
                {quickActions.map((action) => {
                  const Icon = action.icon;
                  return (
                    <Link
                      key={action.name}
                      to={action.href}
                      className={`flex flex-col items-center justify-center p-4 rounded-xl bg-${action.color}/10 border border-${action.color}/20 hover:border-${action.color}/50 transition-all duration-300 hover:scale-105`}
                    >
                      <Icon className={`w-6 h-6 text-${action.color} mb-2`} />
                      <span className="text-xs font-medium text-center">{action.name}</span>
                    </Link>
                  );
                })}
              </div>

              {/* Recent Activity */}
              <h3 className="font-display text-lg font-semibold mt-6 mb-4">Actividad Reciente</h3>
              <div className="space-y-3">
                {recentActivity.slice(0, 4).map((activity, index) => {
                  const Icon = activity.icon;
                  const colors = {
                    success: "text-success",
                    warning: "text-warning",
                    error: "text-destructive",
                    info: "text-info",
                  };
                  return (
                    <div key={index} className="flex items-start gap-3">
                      <Icon className={`w-4 h-4 mt-0.5 ${colors[activity.type as keyof typeof colors]}`} />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm truncate">{activity.message}</p>
                        <p className="text-xs text-muted-foreground">{activity.time}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Cells Status */}
          <div className="mt-6 glass-card rounded-xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="font-display text-lg font-semibold">Estado de Cells Federadas</h2>
              <Link to="/cells">
                <Button variant="ghost" size="sm">
                  Ver Todas
                  <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </Link>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
              {[
                { name: "Educación", status: "healthy" },
                { name: "Salud", status: "healthy" },
                { name: "Fintech", status: "degraded" },
                { name: "Cultura", status: "healthy" },
                { name: "Defensa", status: "healthy" },
                { name: "Ambiente", status: "healthy" },
                { name: "Ciencia", status: "failover" },
                { name: "Gobierno", status: "healthy" },
              ].map((cell) => {
                const statusColors = {
                  healthy: "bg-success/20 border-success/50 text-success",
                  degraded: "bg-warning/20 border-warning/50 text-warning",
                  failover: "bg-destructive/20 border-destructive/50 text-destructive",
                };
                return (
                  <div
                    key={cell.name}
                    className={`p-3 rounded-lg border text-center ${statusColors[cell.status as keyof typeof statusColors]}`}
                  >
                    <Cpu className="w-5 h-5 mx-auto mb-1" />
                    <span className="text-xs font-medium">{cell.name}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
