import { Link, useLocation } from "react-router-dom";
import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Home, ArrowLeft, Shield } from "lucide-react";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error("404 Error: User attempted to access non-existent route:", location.pathname);
  }, [location.pathname]);

  return (
    <div className="min-h-screen bg-background flex items-center justify-center relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 grid-pattern opacity-30" />
      <div className="absolute inset-0 bg-gradient-radial from-destructive/10 via-transparent to-transparent" />

      {/* Animated Rings */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] pointer-events-none opacity-20">
        <div className="absolute inset-0 border border-destructive/30 rounded-full animate-spin-slow" />
        <div className="absolute inset-16 border border-destructive/20 rounded-full animate-spin-slow" style={{ animationDirection: 'reverse' }} />
        <div className="absolute inset-32 border border-destructive/10 rounded-full animate-spin-slow" style={{ animationDuration: '25s' }} />
      </div>

      <div className="relative z-10 text-center px-4 max-w-lg">
        {/* Error Code */}
        <div className="relative mb-8">
          <h1 className="font-display text-[150px] md:text-[200px] font-black text-destructive/10 leading-none select-none">
            404
          </h1>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-24 h-24 rounded-full bg-destructive/20 flex items-center justify-center">
              <Shield className="w-12 h-12 text-destructive" />
            </div>
          </div>
        </div>

        {/* Message */}
        <h2 className="font-display text-2xl md:text-3xl font-bold mb-4">
          Ruta No <span className="text-destructive">Encontrada</span>
        </h2>
        <p className="text-muted-foreground mb-8">
          El sistema Anubis Sentinel no pudo localizar la ruta solicitada. 
          Es posible que la página haya sido movida o eliminada.
        </p>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Link to="/">
            <Button variant="quantum" size="lg">
              <Home className="w-5 h-5 mr-2" />
              Ir al Inicio
            </Button>
          </Link>
          <Button variant="outline" size="lg" onClick={() => window.history.back()}>
            <ArrowLeft className="w-5 h-5 mr-2" />
            Volver Atrás
          </Button>
        </div>

        {/* Route Info */}
        <div className="mt-8 p-4 rounded-lg bg-secondary/50 border border-border">
          <p className="text-xs text-muted-foreground">
            Ruta intentada: <code className="font-mono text-destructive">{location.pathname}</code>
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            Este evento ha sido registrado en BookPI para auditoría.
          </p>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
