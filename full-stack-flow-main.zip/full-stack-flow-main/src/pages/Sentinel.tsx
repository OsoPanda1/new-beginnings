import { useState } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { SentinelScene } from "@/components/3d/SentinelScene";
import { Button } from "@/components/ui/button";
import { 
  Shield, 
  AlertTriangle, 
  AlertCircle,
  CheckCircle,
  Eye,
  Lock,
  Unlock,
  Activity,
  TrendingUp,
  Clock,
  FileText,
  RefreshCw,
  Play,
  Pause
} from "lucide-react";

interface Alert {
  id: string;
  level: "critical" | "warning" | "info";
  title: string;
  description: string;
  cell: string;
  timestamp: Date;
  status: "active" | "acknowledged" | "resolved";
}

const alerts: Alert[] = [
  {
    id: "alert-001",
    level: "critical",
    title: "Cell Ciencia en estado Failover",
    description: "Alta utilización de recursos detectada. Se ha iniciado el protocolo FÉNIX REX.",
    cell: "ciencia",
    timestamp: new Date(Date.now() - 1800000),
    status: "active",
  },
  {
    id: "alert-002",
    level: "warning",
    title: "Latencia elevada en Cell Fintech",
    description: "Latencia P99 > 45ms. Monitoreo activo.",
    cell: "fintech",
    timestamp: new Date(Date.now() - 3600000),
    status: "acknowledged",
  },
  {
    id: "alert-003",
    level: "info",
    title: "Backup BookPI completado",
    description: "Backup diario completado exitosamente con verificación de integridad.",
    cell: "bookpi",
    timestamp: new Date(Date.now() - 7200000),
    status: "resolved",
  },
  {
    id: "alert-004",
    level: "warning",
    title: "Intento de acceso sospechoso",
    description: "Múltiples intentos de login fallidos desde IP anómala.",
    cell: "auth",
    timestamp: new Date(Date.now() - 10800000),
    status: "resolved",
  },
];

const metrics = [
  { label: "Alertas Activas", value: "2", icon: AlertTriangle, color: "warning" },
  { label: "Células Monitoreadas", value: "12", icon: Shield, color: "success" },
  { label: "Eventos/Hora", value: "1.2K", icon: Activity, color: "primary" },
  { label: "Uptime Sentinel", value: "100%", icon: CheckCircle, color: "success" },
];

const securityLayers = [
  { name: "WAF", status: "active" },
  { name: "API Gateway", status: "active" },
  { name: "QuantumTLS", status: "active" },
  { name: "MFA Adaptativo", status: "active" },
  { name: "AES-256-GCM", status: "active" },
  { name: "HSM/KMS", status: "active" },
  { name: "PQC (Kyber)", status: "active" },
  { name: "Merkle Trees", status: "active" },
  { name: "Anomaly Detection", status: "active" },
  { name: "Auto Response", status: "active" },
  { name: "Governance", status: "active" },
];

export default function Sentinel() {
  const [activeAlerts] = useState<Alert[]>(alerts);
  const [isSimulating, setIsSimulating] = useState(false);

  const levelConfig = {
    critical: { icon: AlertCircle, color: "destructive", bg: "bg-destructive/10 border-destructive/30" },
    warning: { icon: AlertTriangle, color: "warning", bg: "bg-warning/10 border-warning/30" },
    info: { icon: CheckCircle, color: "info", bg: "bg-info/10 border-info/30" },
  };

  return (
    <div className="min-h-screen bg-background relative">
      <SentinelScene />
      <Navbar />
      
      <main className="pt-20 pb-12">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
            <div>
              <h1 className="font-display text-2xl md:text-3xl font-bold mb-2">
                Anubis <span className="text-gradient">Sentinel</span>
              </h1>
              <p className="text-muted-foreground">
                Sistema de vigilancia y protección del ecosistema TAMV
              </p>
            </div>
            <div className="flex items-center gap-3">
              <Button 
                variant={isSimulating ? "destructive" : "outline"}
                onClick={() => setIsSimulating(!isSimulating)}
              >
                {isSimulating ? (
                  <>
                    <Pause className="w-4 h-4 mr-2" />
                    Detener Simulacro
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 mr-2" />
                    Iniciar DRP
                  </>
                )}
              </Button>
              <Button variant="outline" size="icon">
                <RefreshCw className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Metrics */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            {metrics.map((metric) => {
              const Icon = metric.icon;
              return (
                <div key={metric.label} className="glass-card rounded-xl p-4">
                  <div className={`w-10 h-10 rounded-lg bg-${metric.color}/10 flex items-center justify-center mb-3`}>
                    <Icon className={`w-5 h-5 text-${metric.color}`} />
                  </div>
                  <div className="font-display text-2xl font-bold">{metric.value}</div>
                  <div className="text-sm text-muted-foreground">{metric.label}</div>
                </div>
              );
            })}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Alerts */}
            <div className="lg:col-span-2">
              <div className="glass-card rounded-xl p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="font-display text-lg font-semibold">Alertas del Sistema</h2>
                  <Button variant="ghost" size="sm">
                    Ver Historial
                  </Button>
                </div>

                <div className="space-y-4">
                  {activeAlerts.map((alert) => {
                    const config = levelConfig[alert.level];
                    const Icon = config.icon;

                    return (
                      <div
                        key={alert.id}
                        className={`p-4 rounded-xl border ${config.bg} transition-all hover:scale-[1.01]`}
                      >
                        <div className="flex items-start gap-4">
                          <div className={`w-10 h-10 rounded-lg bg-${config.color}/20 flex items-center justify-center flex-shrink-0`}>
                            <Icon className={`w-5 h-5 text-${config.color}`} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <h3 className="font-semibold text-sm">{alert.title}</h3>
                              <span className={`px-2 py-0.5 rounded-full text-xs bg-${config.color}/20 text-${config.color}`}>
                                {alert.level.toUpperCase()}
                              </span>
                              {alert.status === "acknowledged" && (
                                <span className="px-2 py-0.5 rounded-full text-xs bg-info/20 text-info">
                                  ACK
                                </span>
                              )}
                              {alert.status === "resolved" && (
                                <span className="px-2 py-0.5 rounded-full text-xs bg-success/20 text-success">
                                  RESUELTO
                                </span>
                              )}
                            </div>
                            <p className="text-sm text-muted-foreground mb-2">{alert.description}</p>
                            <div className="flex items-center gap-4 text-xs text-muted-foreground">
                              <span className="flex items-center gap-1">
                                <Shield className="w-3 h-3" />
                                Cell: {alert.cell}
                              </span>
                              <span className="flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                {alert.timestamp.toLocaleString()}
                              </span>
                            </div>
                          </div>
                          {alert.status === "active" && (
                            <div className="flex gap-2">
                              <Button variant="outline" size="sm">
                                <Eye className="w-4 h-4 mr-1" />
                                Ver
                              </Button>
                              <Button variant="outline" size="sm">
                                ACK
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Security Layers */}
            <div className="space-y-6">
              {/* Dekateotl Status */}
              <div className="glass-card rounded-xl p-6">
                <h2 className="font-display text-lg font-semibold mb-4">Dekateotl Security</h2>
                <p className="text-sm text-muted-foreground mb-4">
                  Estado de las 11 capas de seguridad
                </p>
                <div className="space-y-2">
                  {securityLayers.map((layer, index) => (
                    <div
                      key={layer.name}
                      className="flex items-center justify-between p-2 rounded-lg bg-secondary/30"
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-muted-foreground w-4">{index + 1}</span>
                        <span className="text-sm">{layer.name}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        {layer.status === "active" ? (
                          <>
                            <Lock className="w-3 h-3 text-success" />
                            <span className="text-xs text-success">Activo</span>
                          </>
                        ) : (
                          <>
                            <Unlock className="w-3 h-3 text-warning" />
                            <span className="text-xs text-warning">Inactivo</span>
                          </>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Quick Actions */}
              <div className="glass-card rounded-xl p-6">
                <h2 className="font-display text-lg font-semibold mb-4">Acciones Rápidas</h2>
                <div className="space-y-2">
                  <Button variant="outline" className="w-full justify-start">
                    <FileText className="w-4 h-4 mr-2" />
                    Exportar Logs
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Activity className="w-4 h-4 mr-2" />
                    Ver Métricas
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Shield className="w-4 h-4 mr-2" />
                    Override Panel
                  </Button>
                </div>
              </div>

              {/* FÉNIX REX Status */}
              <div className="glass-card rounded-xl p-6 border-2 border-accent/30">
                <div className="flex items-center gap-2 mb-3">
                  <Shield className="w-5 h-5 text-accent" />
                  <h3 className="font-display font-semibold">Protocolo FÉNIX REX</h3>
                </div>
                <p className="text-sm text-muted-foreground mb-4">
                  Sistema de recuperación ante desastres
                </p>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Último simulacro:</span>
                    <span>Hace 15 días</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">MTTD:</span>
                    <span className="text-success">3.2 min</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">MTTR:</span>
                    <span className="text-success">28 min</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
