import { Link } from "react-router-dom";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { 
  Download, 
  FileText, 
  Shield, 
  Cpu, 
  Brain, 
  Globe, 
  Lock,
  CheckCircle,
  ArrowRight,
  ExternalLink,
  Book
} from "lucide-react";

const sections = [
  {
    id: "resumen",
    title: "1. Resumen Ejecutivo",
    content: "TAMV ONLINE™ (TAMV DM-X4™) es una infraestructura digital civilizatoria, federada y multisensorial concebida en Real del Monte, Hidalgo, México. Diseñada para establecer un estándar global de protección de la dignidad digital, trazabilidad de propiedad intelectual (BookPI™), gobernanza institucional (DEKATEOTL™) y experiencia emocional/neuronal con ISABELLA AI™.",
  },
  {
    id: "contexto",
    title: "2. Contexto Latinoamericano",
    content: "El ecosistema surge de la necesidad de crear una infraestructura tecnológica soberana que no dependa de licencias extranjeras ni plataformas alquiladas. TAMV es un acto de soberanía digital que demuestra que Latinoamérica no solo consume tecnología, sino que la produce y exporta con dignidad.",
  },
  {
    id: "arquitectura",
    title: "3. Arquitectura Técnica",
    content: "La arquitectura se compone de QuantumPods™ (microservicios federados), ISABELLA AI™ (núcleo emocional auditado), KAOS Audio™ (motor audio 3D/XR), DEKATEOTL™ (sistema de gobernanza y defensa), BookPI™ (registro inmutable de PI), y DreamSpaces™ (XR institucional).",
  },
  {
    id: "bookpi",
    title: "4. BookPI - Trazabilidad",
    content: "Sistema de registro inmutable con hash SHA-512 y timestamp legal. Cada evento incluye: event_id, type, actor, payload_hash, timestamp, signature y DOI opcional. La firma se genera en HSM/KMS con esquema EdDSA/Dilithium para resistencia post-cuántica.",
  },
  {
    id: "seguridad",
    title: "5. Seguridad Dekateotl",
    content: "11 capas de protección: WAF, API Gateway, Auth (QuantumTLS), MFA adaptativa, cifrado at-rest (AES-256-GCM), HSM/KMS, PQC KEM+SIG (Kyber + Dilithium), integridad (Merkle trees), anomaly detection, automated response (rollback), y governance multipolar.",
  },
  {
    id: "gobernanza",
    title: "6. Gobernanza DEKATEOTL",
    content: "Estructura de comités con quórum y roles definidos: Ethics Board, Security Board, Legal Board. Protocolos de crisis, override multipolar y continuidad civilizatoria garantizada. Decisiones críticas requieren validación ética, legal y técnica.",
  },
  {
    id: "isabella",
    title: "7. Isabella IA NextGen",
    content: "Inteligencia Nativa Extensible con Quantum Engine (operadores cuántico-inspirados), Emotional Mapper (vector EOCT), Semantic Sorter (mitigación de sesgos), Intent Preserver (fidelidad al propósito) y Policy Engine multipolar.",
  },
  {
    id: "economia",
    title: "8. Economía Digital",
    content: "Sistema de wallet soberano con créditos TAM, anti-fraude Ojo de Ra, ledger inmutable y rampas de monetización digna. Protección contra velocity abuse, geolocation mismatch y pattern graphs maliciosos.",
  },
];

export default function WhitePaper() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-20">
        {/* Hero */}
        <section className="py-16 md:py-24 relative overflow-hidden">
          <div className="absolute inset-0 grid-pattern opacity-30" />
          <div className="absolute inset-0 bg-gradient-radial from-primary/10 via-transparent to-transparent" />
          
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-4xl mx-auto text-center">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 border border-accent/30 mb-6">
                <FileText className="w-4 h-4 text-accent" />
                <span className="text-sm font-medium text-accent">Versión 1.0.0 • Diciembre 2025</span>
              </div>
              
              <h1 className="font-display text-3xl md:text-5xl font-bold mb-6">
                WhitePaper <span className="text-gradient">TAMV DM-X4™</span>
              </h1>
              
              <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
                Documentación técnica completa del ecosistema latinoamericano para Web 4.0 / Web 5.0. 
                Expediente de autoría, registro y certificación institucional.
              </p>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
                <Button variant="aztec" size="lg">
                  <Download className="w-5 h-5 mr-2" />
                  Descargar PDF
                </Button>
                <Button variant="outline" size="lg">
                  <ExternalLink className="w-5 h-5 mr-2" />
                  Ver en BookPI
                </Button>
              </div>

              {/* Quick Info */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { label: "Autor", value: "Edwin O. Castillo Trejo" },
                  { label: "Alias", value: "Anubis Villaseñor" },
                  { label: "Origen", value: "Real del Monte, MX" },
                  { label: "DOI", value: "10.5555/tamv.v1" },
                ].map((item) => (
                  <div key={item.label} className="glass-card rounded-lg p-3">
                    <div className="text-xs text-muted-foreground">{item.label}</div>
                    <div className="text-sm font-medium truncate">{item.value}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Table of Contents */}
        <section className="py-12 bg-card/50">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <h2 className="font-display text-2xl font-bold mb-6 flex items-center gap-2">
                <Book className="w-6 h-6 text-primary" />
                Contenido
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {sections.map((section, index) => (
                  <a
                    key={section.id}
                    href={`#${section.id}`}
                    className="flex items-center gap-3 p-3 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors"
                  >
                    <span className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-sm font-medium text-primary">
                      {index + 1}
                    </span>
                    <span className="text-sm">{section.title.replace(/^\d+\.\s*/, '')}</span>
                    <ArrowRight className="w-4 h-4 ml-auto text-muted-foreground" />
                  </a>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Content Sections */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto space-y-12">
              {sections.map((section) => (
                <div key={section.id} id={section.id} className="scroll-mt-24">
                  <h2 className="font-display text-xl md:text-2xl font-bold mb-4 text-gradient">
                    {section.title}
                  </h2>
                  <div className="glass-card rounded-xl p-6">
                    <p className="text-muted-foreground leading-relaxed">{section.content}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Key Features */}
        <section className="py-16 bg-card/50">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <h2 className="font-display text-2xl font-bold mb-8 text-center">
                Componentes <span className="text-gradient">Principales</span>
              </h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {[
                  { icon: Cpu, name: "QuantumPods™", desc: "Microservicios federados" },
                  { icon: Brain, name: "Isabella AI™", desc: "Núcleo emocional auditado" },
                  { icon: Shield, name: "Dekateotl™", desc: "11 capas de seguridad" },
                  { icon: FileText, name: "BookPI™", desc: "Registro inmutable de PI" },
                  { icon: Globe, name: "DreamSpaces™", desc: "XR institucional" },
                  { icon: Lock, name: "ID-Nvida™", desc: "Identidad descentralizada" },
                ].map((item) => {
                  const Icon = item.icon;
                  return (
                    <div key={item.name} className="glass-card rounded-xl p-4 flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <Icon className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <div className="font-semibold text-sm">{item.name}</div>
                        <div className="text-xs text-muted-foreground">{item.desc}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </section>

        {/* Compliance */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <h2 className="font-display text-2xl font-bold mb-6 text-center">
                Cumplimiento <span className="text-gradient-gold">Normativo</span>
              </h2>
              <div className="flex flex-wrap items-center justify-center gap-4">
                {[
                  "GDPR", "AI Act EU", "LFPDPPP", "ISO 27001", "NIST 800-207", 
                  "WIPO", "HIPAA", "FERPA", "NOM-MX"
                ].map((cert) => (
                  <div
                    key={cert}
                    className="flex items-center gap-2 px-4 py-2 rounded-full bg-success/10 border border-success/30"
                  >
                    <CheckCircle className="w-4 h-4 text-success" />
                    <span className="text-sm font-medium">{cert}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-16 bg-card/50">
          <div className="container mx-auto px-4">
            <div className="max-w-2xl mx-auto text-center">
              <h2 className="font-display text-2xl font-bold mb-4">
                ¿Listo para Unirte?
              </h2>
              <p className="text-muted-foreground mb-6">
                Explora el ecosistema y sé parte de la revolución digital soberana de Latinoamérica.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Link to="/auth?mode=signup">
                  <Button variant="quantum" size="lg">
                    Crear Cuenta
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </Link>
                <Link to="/dashboard">
                  <Button variant="outline" size="lg">
                    Explorar Dashboard
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
