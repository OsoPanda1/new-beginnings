import { useState } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { QuantumScene } from "@/components/3d/QuantumScene";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Atom, 
  Play, 
  Pause, 
  RotateCcw,
  Clock,
  CheckCircle,
  XCircle,
  Loader2,
  FileText,
  ChevronRight,
  Zap,
  Database,
  Cpu
} from "lucide-react";
import { toast } from "sonner";

interface QuantumJob {
  id: string;
  type: string;
  status: "pending" | "running" | "completed" | "failed";
  progress: number;
  createdAt: Date;
  evidence_hash?: string;
}

const operationTypes = [
  { id: "grover", name: "Búsqueda de Grover", description: "Algoritmo de búsqueda cuántica", icon: Database },
  { id: "vqe", name: "VQE", description: "Variational Quantum Eigensolver", icon: Atom },
  { id: "qml", name: "QML", description: "Quantum Machine Learning", icon: Cpu },
  { id: "custom", name: "Personalizado", description: "Circuito cuántico custom", icon: Zap },
];

const mockJobs: QuantumJob[] = [
  { id: "qj-001", type: "grover", status: "completed", progress: 100, createdAt: new Date(Date.now() - 3600000), evidence_hash: "sha512:a1b2c3..." },
  { id: "qj-002", type: "vqe", status: "running", progress: 67, createdAt: new Date(Date.now() - 1800000) },
  { id: "qj-003", type: "qml", status: "pending", progress: 0, createdAt: new Date(Date.now() - 600000) },
  { id: "qj-004", type: "grover", status: "failed", progress: 45, createdAt: new Date(Date.now() - 7200000), evidence_hash: "sha512:d4e5f6..." },
];

export default function Quantum() {
  const [selectedType, setSelectedType] = useState<string | null>(null);
  const [jobs, setJobs] = useState<QuantumJob[]>(mockJobs);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmitJob = async () => {
    if (!selectedType) {
      toast.error("Selecciona un tipo de operación");
      return;
    }

    setIsSubmitting(true);
    await new Promise((resolve) => setTimeout(resolve, 1500));

    const newJob: QuantumJob = {
      id: `qj-${Date.now()}`,
      type: selectedType,
      status: "pending",
      progress: 0,
      createdAt: new Date(),
    };

    setJobs([newJob, ...jobs]);
    setSelectedType(null);
    setIsSubmitting(false);

    toast.success("Operación cuántica enviada", {
      description: `Job ID: ${newJob.id}`,
    });

    // Simulate job progress
    let progress = 0;
    const interval = setInterval(() => {
      progress += 10;
      setJobs((prevJobs) =>
        prevJobs.map((job) =>
          job.id === newJob.id
            ? {
                ...job,
                status: progress < 100 ? "running" : "completed",
                progress: Math.min(progress, 100),
                evidence_hash: progress >= 100 ? `sha512:${Math.random().toString(36).substr(2, 8)}` : undefined,
              }
            : job
        )
      );
      if (progress >= 100) {
        clearInterval(interval);
        toast.success("Operación completada", {
          description: "Evidencia registrada en BookPI",
        });
      }
    }, 1000);
  };

  const getStatusIcon = (status: QuantumJob["status"]) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="w-4 h-4 text-success" />;
      case "running":
        return <Loader2 className="w-4 h-4 text-primary animate-spin" />;
      case "pending":
        return <Clock className="w-4 h-4 text-warning" />;
      case "failed":
        return <XCircle className="w-4 h-4 text-destructive" />;
    }
  };

  const getStatusLabel = (status: QuantumJob["status"]) => {
    const labels = {
      completed: "Completado",
      running: "Ejecutando",
      pending: "Pendiente",
      failed: "Fallido",
    };
    return labels[status];
  };

  return (
    <div className="min-h-screen bg-background relative">
      <QuantumScene />
      <Navbar />
      
      <main className="pt-20 pb-12">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="mb-8">
            <h1 className="font-display text-2xl md:text-3xl font-bold mb-2">
              Operaciones <span className="text-gradient">Cuánticas</span>
            </h1>
            <p className="text-muted-foreground">
              Ejecuta algoritmos cuántico-inspirados con trazabilidad completa en BookPI
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* New Operation */}
            <div className="lg:col-span-1">
              <div className="glass-card rounded-xl p-6">
                <h2 className="font-display text-lg font-semibold mb-4">Nueva Operación</h2>
                
                {/* Operation Types */}
                <div className="space-y-3 mb-6">
                  {operationTypes.map((op) => {
                    const Icon = op.icon;
                    const isSelected = selectedType === op.id;
                    return (
                      <button
                        key={op.id}
                        onClick={() => setSelectedType(op.id)}
                        className={`w-full flex items-center gap-3 p-3 rounded-lg border transition-all ${
                          isSelected
                            ? "border-primary bg-primary/10"
                            : "border-border hover:border-primary/50 hover:bg-secondary/50"
                        }`}
                      >
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                          isSelected ? "bg-primary/20" : "bg-secondary"
                        }`}>
                          <Icon className={`w-5 h-5 ${isSelected ? "text-primary" : "text-muted-foreground"}`} />
                        </div>
                        <div className="text-left">
                          <div className="font-medium text-sm">{op.name}</div>
                          <div className="text-xs text-muted-foreground">{op.description}</div>
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Parameters */}
                <div className="space-y-4 mb-6">
                  <div>
                    <Label htmlFor="timeout">Timeout (segundos)</Label>
                    <Input id="timeout" type="number" defaultValue={300} className="mt-1" />
                  </div>
                  <div>
                    <Label htmlFor="backend">Backend</Label>
                    <select
                      id="backend"
                      className="w-full mt-1 px-3 py-2 rounded-lg bg-secondary border border-border text-sm"
                    >
                      <option value="simulator">Simulador</option>
                      <option value="hardware">Hardware (Premium)</option>
                    </select>
                  </div>
                </div>

                <Button 
                  variant="quantum" 
                  className="w-full" 
                  onClick={handleSubmitJob}
                  disabled={!selectedType || isSubmitting}
                >
                  {isSubmitting ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <>
                      <Play className="w-4 h-4" />
                      Ejecutar Operación
                    </>
                  )}
                </Button>
              </div>

              {/* Info Card */}
              <div className="glass-card rounded-xl p-6 mt-6">
                <h3 className="font-display text-sm font-semibold mb-3">Quantum Service Layer</h3>
                <p className="text-xs text-muted-foreground mb-4">
                  Todos los jobs se ejecutan con validación de cuota, attach de evidencia a BookPI 
                  y notificación de eventos del ciclo de vida.
                </p>
                <div className="space-y-2 text-xs">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-3 h-3 text-success" />
                    <span className="text-muted-foreground">Circuit hash adjunto</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-3 h-3 text-success" />
                    <span className="text-muted-foreground">Eventos pub/sub</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-3 h-3 text-success" />
                    <span className="text-muted-foreground">Quota management</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Jobs List */}
            <div className="lg:col-span-2">
              <div className="glass-card rounded-xl p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="font-display text-lg font-semibold">Historial de Jobs</h2>
                  <Button variant="ghost" size="sm">
                    <RotateCcw className="w-4 h-4 mr-2" />
                    Actualizar
                  </Button>
                </div>

                <div className="space-y-4">
                  {jobs.map((job) => {
                    const opType = operationTypes.find((op) => op.id === job.type);
                    const OpIcon = opType?.icon || Atom;
                    
                    return (
                      <div
                        key={job.id}
                        className="flex items-center gap-4 p-4 rounded-lg bg-secondary/30 hover:bg-secondary/50 transition-colors"
                      >
                        {/* Icon */}
                        <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                          <OpIcon className="w-6 h-6 text-primary" />
                        </div>

                        {/* Info */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-mono text-sm font-medium">{job.id}</span>
                            <span className="text-xs px-2 py-0.5 rounded-full bg-secondary text-muted-foreground">
                              {opType?.name}
                            </span>
                          </div>
                          <div className="flex items-center gap-3 text-xs text-muted-foreground">
                            <span>{job.createdAt.toLocaleString()}</span>
                            {job.evidence_hash && (
                              <span className="font-mono truncate max-w-32">{job.evidence_hash}</span>
                            )}
                          </div>
                          
                          {/* Progress Bar */}
                          {job.status === "running" && (
                            <div className="mt-2">
                              <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                                <div
                                  className="h-full bg-primary transition-all duration-500"
                                  style={{ width: `${job.progress}%` }}
                                />
                              </div>
                            </div>
                          )}
                        </div>

                        {/* Status */}
                        <div className="flex items-center gap-2">
                          {getStatusIcon(job.status)}
                          <span className="text-sm">{getStatusLabel(job.status)}</span>
                        </div>

                        {/* Actions */}
                        <Button variant="ghost" size="icon">
                          <ChevronRight className="w-4 h-4" />
                        </Button>
                      </div>
                    );
                  })}
                </div>

                {jobs.length === 0 && (
                  <div className="text-center py-12">
                    <Atom className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">No hay jobs recientes</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Crea una nueva operación para comenzar
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
