import { useState, useEffect } from 'react';

export type PerformanceLevel = 'low' | 'medium' | 'high';

interface DevicePerformance {
  level: PerformanceLevel;
  isMobile: boolean;
  particleCount: number;
  starCount: number;
  enablePostProcessing: boolean;
  dpr: [number, number];
}

export function useDevicePerformance(): DevicePerformance {
  const [performance, setPerformance] = useState<DevicePerformance>({
    level: 'medium',
    isMobile: false,
    particleCount: 500,
    starCount: 1500,
    enablePostProcessing: true,
    dpr: [1, 2],
  });

  useEffect(() => {
    const checkPerformance = () => {
      const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) || window.innerWidth < 768;
      const cores = navigator.hardwareConcurrency || 4;
      const memory = (navigator as any).deviceMemory || 4;
      
      let level: PerformanceLevel = 'high';
      
      if (isMobile || cores <= 2 || memory <= 2) {
        level = 'low';
      } else if (cores <= 4 || memory <= 4) {
        level = 'medium';
      }

      const config: DevicePerformance = {
        level,
        isMobile,
        particleCount: level === 'low' ? 100 : level === 'medium' ? 300 : 800,
        starCount: level === 'low' ? 500 : level === 'medium' ? 1000 : 2000,
        enablePostProcessing: level !== 'low',
        dpr: level === 'low' ? [1, 1] : level === 'medium' ? [1, 1.5] : [1, 2],
      };

      setPerformance(config);
    };

    checkPerformance();
    window.addEventListener('resize', checkPerformance);
    return () => window.removeEventListener('resize', checkPerformance);
  }, []);

  return performance;
}
