
import React, { useState } from 'react';
import { 
  X, 
  Coins, 
  ShoppingCart, 
  TrendingUp, 
  Gift,
  Wallet,
  CreditCard,
  Star
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface VirtualEconomyProps {
  userId?: string;
  onClose: () => void;
}

interface NFTItem {
  id: string;
  name: string;
  price: number;
  type: 'avatar' | 'land' | 'item' | 'accessory';
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  image: string;
}

export const VirtualEconomy: React.FC<VirtualEconomyProps> = ({ userId, onClose }) => {
  const [activeTab, setActiveTab] = useState<'wallet' | 'store' | 'nfts' | 'trading'>('wallet');
  const [zipCoins, setZipCoins] = useState(1250);
  const [userNFTs, setUserNFTs] = useState<NFTItem[]>([]);

  const storeItems: NFTItem[] = [
    {
      id: '1',
      name: 'Avatar Cyberpunk',
      price: 500,
      type: 'avatar',
      rarity: 'epic',
      image: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=200'
    },
    {
      id: '2',
      name: 'Terreno Virtual Plaza',
      price: 2000,
      type: 'land',
      rarity: 'legendary',
      image: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=200'
    },
    {
      id: '3',
      name: 'Espada de Luz',
      price: 150,
      type: 'item',
      rarity: 'rare',
      image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=200'
    },
    {
      id: '4',
      name: 'Casco Holográfico',
      price: 300,
      type: 'accessory',
      rarity: 'epic',
      image: 'https://images.unsplash.com/photo-1649972904349-6e44c42644a7?w=200'
    }
  ];

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'text-gray-400 border-gray-400';
      case 'rare': return 'text-blue-400 border-blue-400';
      case 'epic': return 'text-purple-400 border-purple-400';
      case 'legendary': return 'text-yellow-400 border-yellow-400';
      default: return 'text-gray-400 border-gray-400';
    }
  };

  const buyItem = (item: NFTItem) => {
    if (zipCoins >= item.price) {
      setZipCoins(prev => prev - item.price);
      setUserNFTs(prev => [...prev, item]);
      console.log(`Compraste: ${item.name}`);
    }
  };

  const tabs = [
    { id: 'wallet', name: 'Billetera', icon: Wallet },
    { id: 'store', name: 'Tienda', icon: ShoppingCart },
    { id: 'nfts', name: 'Mis NFTs', icon: Star },
    { id: 'trading', name: 'Trading', icon: TrendingUp }
  ];

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-gray-900 rounded-xl border border-purple-500/30 w-full max-w-4xl h-[80vh] flex flex-col overflow-hidden"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-purple-600 to-pink-600 p-4 flex items-center justify-between">
            <h2 className="text-xl font-bold text-white">ZipVerse Economy</h2>
            <button
              onClick={onClose}
              className="text-white hover:bg-white/20 p-2 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Tabs */}
          <div className="flex border-b border-gray-700">
            {tabs.map((tab) => {
              const IconComponent = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex-1 flex items-center justify-center gap-2 p-4 transition-colors ${
                    activeTab === tab.id
                      ? 'bg-purple-600 text-white'
                      : 'text-gray-400 hover:text-white hover:bg-gray-800'
                  }`}
                >
                  <IconComponent className="w-5 h-5" />
                  <span>{tab.name}</span>
                </button>
              );
            })}
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto p-6">
            {activeTab === 'wallet' && (
              <div className="space-y-6">
                <div className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg p-6 text-white">
                  <div className="flex items-center gap-3 mb-4">
                    <Coins className="w-8 h-8" />
                    <div>
                      <h3 className="text-xl font-bold">ZipCoins</h3>
                      <p className="text-purple-200">Tu moneda virtual</p>
                    </div>
                  </div>
                  <div className="text-3xl font-bold">{zipCoins.toLocaleString()}</div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-gray-800 rounded-lg p-4">
                    <div className="flex items-center gap-3 mb-3">
                      <CreditCard className="w-6 h-6 text-green-400" />
                      <h4 className="text-white font-medium">Comprar ZipCoins</h4>
                    </div>
                    <div className="space-y-2">
                      <button className="w-full bg-green-600 hover:bg-green-700 text-white p-3 rounded-lg transition-colors">
                        1000 ZipCoins - $10 USD
                      </button>
                      <button className="w-full bg-green-600 hover:bg-green-700 text-white p-3 rounded-lg transition-colors">
                        5000 ZipCoins - $45 USD
                      </button>
                      <button className="w-full bg-green-600 hover:bg-green-700 text-white p-3 rounded-lg transition-colors">
                        10000 ZipCoins - $80 USD
                      </button>
                    </div>
                  </div>

                  <div className="bg-gray-800 rounded-lg p-4">
                    <div className="flex items-center gap-3 mb-3">
                      <Gift className="w-6 h-6 text-yellow-400" />
                      <h4 className="text-white font-medium">Gana ZipCoins</h4>
                    </div>
                    <div className="space-y-2 text-gray-300">
                      <div className="flex justify-between">
                        <span>Login diario</span>
                        <span className="text-yellow-400">+50</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Completar misiones</span>
                        <span className="text-yellow-400">+100</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Referir amigos</span>
                        <span className="text-yellow-400">+500</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'store' && (
              <div>
                <h3 className="text-2xl font-bold text-white mb-6">Tienda de NFTs</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {storeItems.map((item) => (
                    <div key={item.id} className="bg-gray-800 rounded-lg overflow-hidden border border-gray-700 hover:border-purple-500/50 transition-colors">
                      <img 
                        src={item.image} 
                        alt={item.name}
                        className="w-full h-48 object-cover"
                      />
                      <div className="p-4">
                        <div className={`inline-block px-2 py-1 rounded text-xs font-medium border mb-2 ${getRarityColor(item.rarity)}`}>
                          {item.rarity.toUpperCase()}
                        </div>
                        <h4 className="text-white font-medium mb-2">{item.name}</h4>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1 text-yellow-400">
                            <Coins className="w-4 h-4" />
                            <span className="font-bold">{item.price}</span>
                          </div>
                          <button
                            onClick={() => buyItem(item)}
                            disabled={zipCoins < item.price}
                            className="bg-purple-600 hover:bg-purple-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white px-4 py-2 rounded-lg text-sm transition-colors"
                          >
                            Comprar
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'nfts' && (
              <div>
                <h3 className="text-2xl font-bold text-white mb-6">Mis NFTs</h3>
                {userNFTs.length === 0 ? (
                  <div className="text-center text-gray-400 py-12">
                    <Star className="w-16 h-16 mx-auto mb-4 opacity-50" />
                    <p>No tienes NFTs aún</p>
                    <p className="text-sm">¡Visita la tienda para comprar tu primer NFT!</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {userNFTs.map((item, index) => (
                      <div key={`${item.id}-${index}`} className="bg-gray-800 rounded-lg overflow-hidden border border-gray-700">
                        <img 
                          src={item.image} 
                          alt={item.name}
                          className="w-full h-48 object-cover"
                        />
                        <div className="p-4">
                          <div className={`inline-block px-2 py-1 rounded text-xs font-medium border mb-2 ${getRarityColor(item.rarity)}`}>
                            {item.rarity.toUpperCase()}
                          </div>
                          <h4 className="text-white font-medium mb-2">{item.name}</h4>
                          <button className="w-full bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg transition-colors">
                            Equipar
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'trading' && (
              <div>
                <h3 className="text-2xl font-bold text-white mb-6">Centro de Trading</h3>
                <div className="bg-gray-800 rounded-lg p-6 text-center">
                  <TrendingUp className="w-16 h-16 mx-auto mb-4 text-purple-400" />
                  <h4 className="text-xl font-bold text-white mb-2">Próximamente</h4>
                  <p className="text-gray-400">El sistema de trading estará disponible pronto</p>
                </div>
              </div>
            )}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};
