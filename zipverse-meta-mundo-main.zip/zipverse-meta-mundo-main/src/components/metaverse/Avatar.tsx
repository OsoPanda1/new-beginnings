
import React, { useRef, useEffect } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { useBox } from '@react-three/cannon';
import { Sphere, Box } from '@react-three/drei';
import { Group, Vector3 } from 'three';

interface AvatarProps {
  userId?: string;
  position?: [number, number, number];
}

export const Avatar: React.FC<AvatarProps> = ({ 
  userId, 
  position = [0, 2, 5] 
}) => {
  const avatarRef = useRef<Group>(null);
  const { camera } = useThree();
  
  const [bodyRef, bodyApi] = useBox(() => ({ 
    position,
    args: [0.8, 1.8, 0.4],
    mass: 1,
    material: { friction: 0.3 }
  }));

  const keys = useRef({
    forward: false,
    backward: false,
    left: false,
    right: false,
    jump: false
  });

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      switch (e.code) {
        case 'KeyW':
        case 'ArrowUp':
          keys.current.forward = true;
          break;
        case 'KeyS':
        case 'ArrowDown':
          keys.current.backward = true;
          break;
        case 'KeyA':
        case 'ArrowLeft':
          keys.current.left = true;
          break;
        case 'KeyD':
        case 'ArrowRight':
          keys.current.right = true;
          break;
        case 'Space':
          keys.current.jump = true;
          e.preventDefault();
          break;
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      switch (e.code) {
        case 'KeyW':
        case 'ArrowUp':
          keys.current.forward = false;
          break;
        case 'KeyS':
        case 'ArrowDown':
          keys.current.backward = false;
          break;
        case 'KeyA':
        case 'ArrowLeft':
          keys.current.left = false;
          break;
        case 'KeyD':
        case 'ArrowRight':
          keys.current.right = false;
          break;
        case 'Space':
          keys.current.jump = false;
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  useFrame(() => {
    if (!bodyApi) return;

    const velocity = new Vector3();
    const speed = 5;

    if (keys.current.forward) velocity.z -= speed;
    if (keys.current.backward) velocity.z += speed;
    if (keys.current.left) velocity.x -= speed;
    if (keys.current.right) velocity.x += speed;

    bodyApi.velocity.set(velocity.x, velocity.y, velocity.z);

    if (keys.current.jump) {
      bodyApi.velocity.set(velocity.x, 8, velocity.z);
      keys.current.jump = false;
    }

    // Seguir al avatar con la cámara
    if (avatarRef.current) {
      const avatarPosition = avatarRef.current.position;
      camera.position.lerp(
        new Vector3(
          avatarPosition.x,
          avatarPosition.y + 5,
          avatarPosition.z + 10
        ),
        0.05
      );
      camera.lookAt(avatarPosition);
    }
  });

  return (
    <group ref={avatarRef}>
      <group ref={bodyRef}>
        {/* Cuerpo del avatar */}
        <Box args={[0.8, 1.8, 0.4]} position={[0, 0, 0]} castShadow>
          <meshStandardMaterial color="#4A90E2" />
        </Box>
        
        {/* Cabeza */}
        <Sphere args={[0.3]} position={[0, 1.2, 0]} castShadow>
          <meshStandardMaterial color="#FFDBAC" />
        </Sphere>
        
        {/* Ojos */}
        <Sphere args={[0.05]} position={[-0.1, 1.25, 0.25]} castShadow>
          <meshStandardMaterial color="#000000" />
        </Sphere>
        <Sphere args={[0.05]} position={[0.1, 1.25, 0.25]} castShadow>
          <meshStandardMaterial color="#000000" />
        </Sphere>
        
        {/* Brazos */}
        <Box args={[0.2, 1, 0.2]} position={[-0.6, 0.2, 0]} castShadow>
          <meshStandardMaterial color="#FFDBAC" />
        </Box>
        <Box args={[0.2, 1, 0.2]} position={[0.6, 0.2, 0]} castShadow>
          <meshStandardMaterial color="#FFDBAC" />
        </Box>
        
        {/* Piernas */}
        <Box args={[0.25, 1.2, 0.25]} position={[-0.2, -1.8, 0]} castShadow>
          <meshStandardMaterial color="#2C3E50" />
        </Box>
        <Box args={[0.25, 1.2, 0.25]} position={[0.2, -1.8, 0]} castShadow>
          <meshStandardMaterial color="#2C3E50" />
        </Box>
      </group>
    </group>
  );
};
