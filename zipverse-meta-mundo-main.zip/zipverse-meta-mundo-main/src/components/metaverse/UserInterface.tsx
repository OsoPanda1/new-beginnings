
import React, { useState } from 'react';
import { 
  Map, 
  Store, 
  Users, 
  Settings, 
  Wallet, 
  Trophy,
  Home,
  Museum,
  ShoppingBag,
  Gamepad2
} from 'lucide-react';
import { motion } from 'framer-motion';

interface UserInterfaceProps {
  onWorldChange: (world: string) => void;
  onShowEconomy: () => void;
  onShowSocial: () => void;
  currentWorld: string;
}

export const UserInterface: React.FC<UserInterfaceProps> = ({
  onWorldChange,
  onShowEconomy,
  onShowSocial,
  currentWorld
}) => {
  const [showWorldMenu, setShowWorldMenu] = useState(false);

  const worlds = [
    { id: 'plaza', name: 'Plaza Central', icon: Home, color: 'from-blue-500 to-cyan-500' },
    { id: 'museo', name: 'Museo Virtual', icon: Museum, color: 'from-purple-500 to-indigo-500' },
    { id: 'comercial', name: 'Zona Comercial', icon: ShoppingBag, color: 'from-green-500 to-emerald-500' },
    { id: 'juegos', name: 'Zona de Juegos', icon: Gamepad2, color: 'from-red-500 to-pink-500' }
  ];

  return (
    <>
      {/* Menú principal superior */}
      <div className="fixed top-4 left-4 right-4 z-40 flex justify-between items-start">
        {/* Panel de mundos */}
        <div className="relative">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowWorldMenu(!showWorldMenu)}
            className="bg-black/60 backdrop-blur-md text-white px-4 py-2 rounded-lg border border-purple-500/30 flex items-center gap-2 hover:bg-black/80 transition-colors"
          >
            <Map className="w-5 h-5" />
            <span>Mundos</span>
          </motion.button>

          {showWorldMenu && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="absolute top-full mt-2 left-0 bg-black/80 backdrop-blur-md rounded-lg border border-purple-500/30 p-2 min-w-48"
            >
              {worlds.map((world) => {
                const IconComponent = world.icon;
                return (
                  <button
                    key={world.id}
                    onClick={() => {
                      onWorldChange(world.id);
                      setShowWorldMenu(false);
                    }}
                    className={`w-full text-left p-3 rounded-lg mb-1 last:mb-0 transition-colors flex items-center gap-3 ${
                      currentWorld === world.id 
                        ? 'bg-gradient-to-r ' + world.color + ' text-white' 
                        : 'text-gray-300 hover:bg-white/10'
                    }`}
                  >
                    <IconComponent className="w-5 h-5" />
                    <span>{world.name}</span>
                  </button>
                );
              })}
            </motion.div>
          )}
        </div>

        {/* Controles de usuario */}
        <div className="flex gap-2">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onShowEconomy}
            className="bg-black/60 backdrop-blur-md text-white p-3 rounded-lg border border-purple-500/30 hover:bg-black/80 transition-colors"
          >
            <Wallet className="w-5 h-5" />
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onShowSocial}
            className="bg-black/60 backdrop-blur-md text-white p-3 rounded-lg border border-purple-500/30 hover:bg-black/80 transition-colors"
          >
            <Users className="w-5 h-5" />
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="bg-black/60 backdrop-blur-md text-white p-3 rounded-lg border border-purple-500/30 hover:bg-black/80 transition-colors"
          >
            <Trophy className="w-5 h-5" />
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="bg-black/60 backdrop-blur-md text-white p-3 rounded-lg border border-purple-500/30 hover:bg-black/80 transition-colors"
          >
            <Settings className="w-5 h-5" />
          </motion.button>
        </div>
      </div>

      {/* Controles de movimiento para móvil */}
      <div className="fixed bottom-20 left-4 z-40 md:hidden">
        <div className="bg-black/60 backdrop-blur-md rounded-lg p-4 border border-purple-500/30">
          <div className="text-white text-sm mb-2 text-center">Controles</div>
          <div className="grid grid-cols-3 gap-2">
            <div></div>
            <button className="bg-white/20 p-3 rounded text-white">↑</button>
            <div></div>
            <button className="bg-white/20 p-3 rounded text-white">←</button>
            <button className="bg-white/20 p-3 rounded text-white">↓</button>
            <button className="bg-white/20 p-3 rounded text-white">→</button>
          </div>
          <button className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white p-2 rounded mt-2">
            Saltar
          </button>
        </div>
      </div>

      {/* Información de ayuda */}
      <div className="fixed bottom-4 left-4 z-40 hidden md:block">
        <div className="bg-black/60 backdrop-blur-md text-white p-3 rounded-lg border border-purple-500/30 text-sm">
          <div className="font-medium mb-1">Controles:</div>
          <div>WASD - Moverse</div>
          <div>Espacio - Saltar</div>
          <div>Mouse - Mirar alrededor</div>
        </div>
      </div>
    </>
  );
};
