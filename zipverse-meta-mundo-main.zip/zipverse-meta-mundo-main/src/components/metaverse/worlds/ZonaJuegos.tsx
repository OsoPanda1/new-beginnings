
import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Box, Sphere, Text3D, Cylinder, Torus } from '@react-three/drei';
import { useBox, useSphere } from '@react-three/cannon';
import { Mesh } from 'three';

export const ZonaJuegos: React.FC = () => {
  const spinnerRef = useRef<Mesh>(null);
  const ballRef = useRef<Mesh>(null);

  useFrame((state) => {
    if (spinnerRef.current) {
      spinnerRef.current.rotation.y += 0.02;
    }
    if (ballRef.current) {
      ballRef.current.position.y = Math.sin(state.clock.elapsedTime) * 0.5 + 2;
    }
  });

  const [platformRef] = useBox(() => ({ 
    position: [10, 1, 0], 
    args: [6, 2, 6],
    type: 'Static'
  }));

  const [rampRef] = useBox(() => ({ 
    position: [0, 1, 10], 
    args: [8, 0.5, 4],
    rotation: [0, 0, Math.PI / 12],
    type: 'Static'
  }));

  const [ballPhysicsRef] = useSphere(() => ({ 
    position: [-10, 5, 0], 
    args: [1],
    mass: 1
  }));

  return (
    <>
      {/* Plataforma de juegos */}
      <Box ref={platformRef} args={[6, 2, 6]} castShadow receiveShadow>
        <meshStandardMaterial color="#FF4500" />
      </Box>

      {/* Rampa */}
      <Box ref={rampRef} args={[8, 0.5, 4]} castShadow receiveShadow>
        <meshStandardMaterial color="#9370DB" />
      </Box>

      {/* Juego de pelota interactiva */}
      <Sphere ref={ballPhysicsRef} args={[1]} castShadow>
        <meshStandardMaterial color="#FF69B4" />
      </Sphere>

      {/* Spinner giratorio */}
      <group position={[5, 0, -8]}>
        <Torus ref={spinnerRef} args={[3, 0.5, 16, 100]}>
          <meshStandardMaterial color="#00CED1" />
        </Torus>
      </group>

      {/* Pelota flotante */}
      <Sphere ref={ballRef} args={[0.8]} position={[-5, 2, -8]} castShadow>
        <meshStandardMaterial color="#FFFF00" />
      </Sphere>

      {/* Obstáculos de parkour */}
      <Box args={[2, 1, 2]} position={[0, 0.5, -15]} castShadow receiveShadow>
        <meshStandardMaterial color="#8B4513" />
      </Box>
      <Box args={[2, 2, 2]} position={[4, 1, -15]} castShadow receiveShadow>
        <meshStandardMaterial color="#8B4513" />
      </Box>
      <Box args={[2, 3, 2]} position={[8, 1.5, -15]} castShadow receiveShadow>
        <meshStandardMaterial color="#8B4513" />
      </Box>

      {/* Letrero de zona de juegos */}
      <Text3D
        font="/fonts/helvetiker_regular.typeface.json"
        size={1.2}
        height={0.2}
        position={[-6, 6, -5]}
      >
        Gaming Zone
        <meshStandardMaterial color="#FF0000" />
      </Text3D>

      {/* Área de competencias */}
      <Cylinder args={[8, 8, 0.3]} position={[-10, 0.15, -10]}>
        <meshStandardMaterial color="#228B22" />
      </Cylinder>

      <Text3D
        font="/fonts/helvetiker_regular.typeface.json"
        size={0.8}
        height={0.1}
        position={[-13, 1, -10]}
      >
        Arena PvP
        <meshStandardMaterial color="#FFFFFF" />
      </Text3D>
    </>
  );
};
