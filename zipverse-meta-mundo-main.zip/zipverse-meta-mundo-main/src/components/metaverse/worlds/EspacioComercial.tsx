
import React from 'react';
import { Box, Text3D, Cylinder } from '@react-three/drei';
import { useBox } from '@react-three/cannon';

export const EspacioComercial: React.FC = () => {
  const [shop1Ref] = useBox(() => ({ 
    position: [8, 2, -5], 
    args: [4, 4, 4],
    type: 'Static'
  }));

  const [shop2Ref] = useBox(() => ({ 
    position: [-8, 2, -5], 
    args: [4, 4, 4],
    type: 'Static'
  }));

  const [shop3Ref] = useBox(() => ({ 
    position: [8, 2, 5], 
    args: [4, 4, 4],
    type: 'Static'
  }));

  const [shop4Ref] = useBox(() => ({ 
    position: [-8, 2, 5], 
    args: [4, 4, 4],
    type: 'Static'
  }));

  return (
    <>
      {/* Tiendas */}
      <Box ref={shop1Ref} args={[4, 4, 4]} castShadow receiveShadow>
        <meshStandardMaterial color="#FF6347" />
      </Box>
      <Text3D
        font="/fonts/helvetiker_regular.typeface.json"
        size={0.4}
        height={0.1}
        position={[6.5, 5, -5]}
      >
        NFT Store
        <meshStandardMaterial color="#FFFFFF" />
      </Text3D>

      <Box ref={shop2Ref} args={[4, 4, 4]} castShadow receiveShadow>
        <meshStandardMaterial color="#32CD32" />
      </Box>
      <Text3D
        font="/fonts/helvetiker_regular.typeface.json"
        size={0.4}
        height={0.1}
        position={[-9.5, 5, -5]}
      >
        Avatar Shop
        <meshStandardMaterial color="#FFFFFF" />
      </Text3D>

      <Box ref={shop3Ref} args={[4, 4, 4]} castShadow receiveShadow>
        <meshStandardMaterial color="#4169E1" />
      </Box>
      <Text3D
        font="/fonts/helvetiker_regular.typeface.json"
        size={0.4}
        height={0.1}
        position={[6.5, 5, 5]}
      >
        Virtual Land
        <meshStandardMaterial color="#FFFFFF" />
      </Text3D>

      <Box ref={shop4Ref} args={[4, 4, 4]} castShadow receiveShadow>
        <meshStandardMaterial color="#FF1493" />
      </Box>
      <Text3D
        font="/fonts/helvetiker_regular.typeface.json"
        size={0.4}
        height={0.1}
        position={[-9.5, 5, 5]}
      >
        Crypto Exchange
        <meshStandardMaterial color="#FFFFFF" />
      </Text3D>

      {/* Plaza comercial central */}
      <Cylinder args={[6, 6, 0.2]} position={[0, 0.1, 0]}>
        <meshStandardMaterial color="#FFD700" />
      </Cylinder>

      <Text3D
        font="/fonts/helvetiker_regular.typeface.json"
        size={1}
        height={0.2}
        position={[-4, 2, 0]}
      >
        ZipMall
        <meshStandardMaterial color="#8B0000" />
      </Text3D>

      {/* Decoraciones comerciales */}
      <group position={[0, 0, 0]}>
        <Cylinder args={[0.2, 0.2, 3]} position={[3, 1.5, 3]}>
          <meshStandardMaterial color="#C0C0C0" />
        </Cylinder>
        <Cylinder args={[0.2, 0.2, 3]} position={[-3, 1.5, 3]}>
          <meshStandardMaterial color="#C0C0C0" />
        </Cylinder>
        <Cylinder args={[0.2, 0.2, 3]} position={[3, 1.5, -3]}>
          <meshStandardMaterial color="#C0C0C0" />
        </Cylinder>
        <Cylinder args={[0.2, 0.2, 3]} position={[-3, 1.5, -3]}>
          <meshStandardMaterial color="#C0C0C0" />
        </Cylinder>
      </group>
    </>
  );
};
