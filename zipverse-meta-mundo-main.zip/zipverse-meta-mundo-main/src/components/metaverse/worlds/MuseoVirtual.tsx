
import React from 'react';
import { Box, Text3D, Plane } from '@react-three/drei';
import { useBox } from '@react-three/cannon';

export const MuseoVirtual: React.FC = () => {
  const [wallRef1] = useBox(() => ({ 
    position: [0, 3, -10], 
    args: [20, 6, 1],
    type: 'Static'
  }));

  const [wallRef2] = useBox(() => ({ 
    position: [10, 3, 0], 
    args: [1, 6, 20],
    type: 'Static'
  }));

  const [wallRef3] = useBox(() => ({ 
    position: [-10, 3, 0], 
    args: [1, 6, 20],
    type: 'Static'
  }));

  return (
    <>
      {/* Paredes del museo */}
      <Box ref={wallRef1} args={[20, 6, 1]} castShadow receiveShadow>
        <meshStandardMaterial color="#F5F5DC" />
      </Box>
      <Box ref={wallRef2} args={[1, 6, 20]} castShadow receiveShadow>
        <meshStandardMaterial color="#F5F5DC" />
      </Box>
      <Box ref={wallRef3} args={[1, 6, 20]} castShadow receiveShadow>
        <meshStandardMaterial color="#F5F5DC" />
      </Box>

      {/* Exposiciones */}
      <group position={[0, 0, -5]}>
        <Box args={[1, 3, 0.1]} position={[0, 1.5, 0]}>
          <meshStandardMaterial color="#000080" />
        </Box>
        <Text3D
          font="/fonts/helvetiker_regular.typeface.json"
          size={0.5}
          height={0.1}
          position={[-2, 2.5, 0.1]}
        >
          Arte Digital NFT
          <meshStandardMaterial color="#FFD700" />
        </Text3D>
      </group>

      <group position={[5, 0, 0]}>
        <Box args={[1, 3, 0.1]} position={[0, 1.5, 0]}>
          <meshStandardMaterial color="#8B0000" />
        </Box>
        <Text3D
          font="/fonts/helvetiker_regular.typeface.json"
          size={0.5}
          height={0.1}
          position={[-2, 2.5, 0.1]}
        >
          Historia Virtual
          <meshStandardMaterial color="#FFD700" />
        </Text3D>
      </group>

      <group position={[-5, 0, 0]}>
        <Box args={[1, 3, 0.1]} position={[0, 1.5, 0]}>
          <meshStandardMaterial color="#006400" />
        </Box>
        <Text3D
          font="/fonts/helvetiker_regular.typeface.json"
          size={0.5}
          height={0.1}
          position={[-2, 2.5, 0.1]}
        >
          Ciencia 3D
          <meshStandardMaterial color="#FFD700" />
        </Text3D>
      </group>

      {/* Letrero del museo */}
      <Text3D
        font="/fonts/helvetiker_regular.typeface.json"
        size={1.5}
        height={0.2}
        position={[-5, 7, -9.5]}
      >
        Museo Virtual ZipVerse
        <meshStandardMaterial color="#4B0082" />
      </Text3D>
    </>
  );
};
