
import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Box, Sphere, Text3D, Cylinder } from '@react-three/drei';
import { useBox } from '@react-three/cannon';
import { Mesh } from 'three';

export const PlazaCentral: React.FC = () => {
  const fountainRef = useRef<Mesh>(null);

  useFrame((state) => {
    if (fountainRef.current) {
      fountainRef.current.rotation.y += 0.01;
    }
  });

  const [buildingRef1] = useBox(() => ({ 
    position: [10, 5, -10], 
    args: [4, 10, 4],
    type: 'Static'
  }));

  const [buildingRef2] = useBox(() => ({ 
    position: [-10, 7, -10], 
    args: [4, 14, 4],
    type: 'Static'
  }));

  const [buildingRef3] = useBox(() => ({ 
    position: [15, 4, 5], 
    args: [6, 8, 4],
    type: 'Static'
  }));

  return (
    <>
      {/* Fuente Central */}
      <group position={[0, 0, 0]}>
        <Cylinder ref={fountainRef} args={[3, 3, 0.5]} position={[0, 0.25, 0]}>
          <meshStandardMaterial color="#4a90e2" />
        </Cylinder>
        <Sphere args={[0.5]} position={[0, 2, 0]}>
          <meshStandardMaterial color="#87CEEB" />
        </Sphere>
      </group>

      {/* Edificios */}
      <Box ref={buildingRef1} args={[4, 10, 4]} castShadow receiveShadow>
        <meshStandardMaterial color="#8B4513" />
      </Box>

      <Box ref={buildingRef2} args={[4, 14, 4]} castShadow receiveShadow>
        <meshStandardMaterial color="#654321" />
      </Box>

      <Box ref={buildingRef3} args={[6, 8, 4]} castShadow receiveShadow>
        <meshStandardMaterial color="#8B7355" />
      </Box>

      {/* Letrero de Bienvenida */}
      <Text3D
        font="/fonts/helvetiker_regular.typeface.json"
        size={2}
        height={0.2}
        position={[0, 8, -15]}
        rotation={[0, 0, 0]}
      >
        ZipVerse Plaza
        <meshStandardMaterial color="#FFD700" />
      </Text3D>

      {/* Caminos */}
      <Box args={[2, 0.1, 20]} position={[0, 0.05, 0]}>
        <meshStandardMaterial color="#696969" />
      </Box>
      <Box args={[20, 0.1, 2]} position={[0, 0.05, 0]}>
        <meshStandardMaterial color="#696969" />
      </Box>

      {/* Árboles decorativos */}
      <group position={[7, 0, 7]}>
        <Cylinder args={[0.3, 0.3, 4]} position={[0, 2, 0]}>
          <meshStandardMaterial color="#8B4513" />
        </Cylinder>
        <Sphere args={[2]} position={[0, 5, 0]}>
          <meshStandardMaterial color="#228B22" />
        </Sphere>
      </group>

      <group position={[-7, 0, 7]}>
        <Cylinder args={[0.3, 0.3, 4]} position={[0, 2, 0]}>
          <meshStandardMaterial color="#8B4513" />
        </Cylinder>
        <Sphere args={[2]} position={[0, 5, 0]}>
          <meshStandardMaterial color="#228B22" />
        </Sphere>
      </group>
    </>
  );
};
