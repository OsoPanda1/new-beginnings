
import React, { useState } from 'react';
import { 
  X, 
  Users, 
  UserPlus, 
  MessageCircle, 
  Crown,
  Star,
  MapPin,
  Calendar
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface SocialHubProps {
  userId?: string;
  onClose: () => void;
}

interface User {
  id: string;
  username: string;
  avatar: string;
  level: number;
  location: string;
  status: 'online' | 'away' | 'busy' | 'offline';
  achievements: string[];
}

interface Event {
  id: string;
  title: string;
  description: string;
  date: Date;
  location: string;
  attendees: number;
}

export const SocialHub: React.FC<SocialHubProps> = ({ userId, onClose }) => {
  const [activeTab, setActiveTab] = useState<'friends' | 'leaderboard' | 'events' | 'guilds'>('friends');

  const friends: User[] = [
    {
      id: '1',
      username: 'CyberNinja2023',
      avatar: 'https://images.unsplash.com/photo-1649972904349-6e44c42644a7?w=100',
      level: 25,
      location: 'Plaza Central',
      status: 'online',
      achievements: ['Explorer', 'Trader']
    },
    {
      id: '2',
      username: 'VirtualBuilder',
      avatar: 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=100',
      level: 18,
      location: 'Zona Comercial',
      status: 'away',
      achievements: ['Architect', 'Creator']
    },
    {
      id: '3',
      username: 'MetaExplorer',
      avatar: 'https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?w=100',
      level: 32,
      location: 'Museo Virtual',
      status: 'online',
      achievements: ['Scholar', 'Pioneer', 'Legend']
    }
  ];

  const leaderboard: User[] = [
    {
      id: '4',
      username: 'MetaKing',
      avatar: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=100',
      level: 50,
      location: 'Plaza Central',
      status: 'online',
      achievements: ['Champion', 'Legend', 'Master']
    },
    {
      id: '5',
      username: 'ZipVersePro',
      avatar: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=100',
      level: 45,
      location: 'Zona de Juegos',
      status: 'online',
      achievements: ['Gamer', 'Expert']
    },
    {
      id: '3',
      username: 'MetaExplorer',
      avatar: 'https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?w=100',
      level: 32,
      location: 'Museo Virtual',
      status: 'online',
      achievements: ['Scholar', 'Pioneer']
    }
  ];

  const events: Event[] = [
    {
      id: '1',
      title: 'Concierto Virtual',
      description: 'Música electrónica en vivo en la Plaza Central',
      date: new Date(Date.now() + 86400000),
      location: 'Plaza Central',
      attendees: 150
    },
    {
      id: '2',
      title: 'Torneo PvP',
      description: 'Competencia semanal de combate',
      date: new Date(Date.now() + 172800000),
      location: 'Zona de Juegos',
      attendees: 89
    },
    {
      id: '3',
      title: 'Exposición NFT',
      description: 'Nuevas colecciones de arte digital',
      date: new Date(Date.now() + 259200000),
      location: 'Museo Virtual',
      attendees: 234
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'bg-green-500';
      case 'away': return 'bg-yellow-500';
      case 'busy': return 'bg-red-500';
      case 'offline': return 'bg-gray-500';
      default: return 'bg-gray-500';
    }
  };

  const tabs = [
    { id: 'friends', name: 'Amigos', icon: Users },
    { id: 'leaderboard', name: 'Ranking', icon: Crown },
    { id: 'events', name: 'Eventos', icon: Calendar },
    { id: 'guilds', name: 'Clanes', icon: Star }
  ];

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-gray-900 rounded-xl border border-purple-500/30 w-full max-w-4xl h-[80vh] flex flex-col overflow-hidden"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-purple-600 to-pink-600 p-4 flex items-center justify-between">
            <h2 className="text-xl font-bold text-white">Hub Social</h2>
            <button
              onClick={onClose}
              className="text-white hover:bg-white/20 p-2 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Tabs */}
          <div className="flex border-b border-gray-700">
            {tabs.map((tab) => {
              const IconComponent = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex-1 flex items-center justify-center gap-2 p-4 transition-colors ${
                    activeTab === tab.id
                      ? 'bg-purple-600 text-white'
                      : 'text-gray-400 hover:text-white hover:bg-gray-800'
                  }`}
                >
                  <IconComponent className="w-5 h-5" />
                  <span>{tab.name}</span>
                </button>
              );
            })}
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto p-6">
            {activeTab === 'friends' && (
              <div>
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-2xl font-bold text-white">Mis Amigos</h3>
                  <button className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors">
                    <UserPlus className="w-4 h-4" />
                    Añadir Amigo
                  </button>
                </div>
                <div className="space-y-4">
                  {friends.map((friend) => (
                    <div key={friend.id} className="bg-gray-800 rounded-lg p-4 flex items-center gap-4">
                      <div className="relative">
                        <img 
                          src={friend.avatar} 
                          alt={friend.username}
                          className="w-12 h-12 rounded-full object-cover"
                        />
                        <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-gray-800 ${getStatusColor(friend.status)}`}></div>
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <h4 className="text-white font-medium">{friend.username}</h4>
                          <span className="bg-blue-600 text-white text-xs px-2 py-1 rounded">Lv.{friend.level}</span>
                        </div>
                        <div className="flex items-center gap-2 text-gray-400 text-sm">
                          <MapPin className="w-3 h-3" />
                          <span>{friend.location}</span>
                        </div>
                        <div className="flex gap-1 mt-1">
                          {friend.achievements.map((achievement, index) => (
                            <span key={index} className="bg-yellow-600 text-white text-xs px-2 py-1 rounded">
                              {achievement}
                            </span>
                          ))}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <button className="bg-green-600 hover:bg-green-700 text-white p-2 rounded transition-colors">
                          <MessageCircle className="w-4 h-4" />
                        </button>
                        <button className="bg-blue-600 hover:bg-blue-700 text-white p-2 rounded transition-colors">
                          <MapPin className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'leaderboard' && (
              <div>
                <h3 className="text-2xl font-bold text-white mb-6">Tabla de Líderes</h3>
                <div className="space-y-4">
                  {leaderboard.map((user, index) => (
                    <div key={user.id} className="bg-gray-800 rounded-lg p-4 flex items-center gap-4">
                      <div className="flex items-center justify-center w-8 h-8 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full text-white font-bold">
                        {index + 1}
                      </div>
                      <img 
                        src={user.avatar} 
                        alt={user.username}
                        className="w-12 h-12 rounded-full object-cover"
                      />
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <h4 className="text-white font-medium">{user.username}</h4>
                          {index === 0 && <Crown className="w-5 h-5 text-yellow-500" />}
                        </div>
                        <div className="flex items-center gap-2 text-gray-400 text-sm">
                          <span>Nivel {user.level}</span>
                          <span>•</span>
                          <span>{user.location}</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-yellow-400 font-bold text-lg">{user.level * 1000}</div>
                        <div className="text-gray-400 text-sm">XP</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'events' && (
              <div>
                <h3 className="text-2xl font-bold text-white mb-6">Próximos Eventos</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {events.map((event) => (
                    <div key={event.id} className="bg-gray-800 rounded-lg p-6 border border-gray-700 hover:border-purple-500/50 transition-colors">
                      <h4 className="text-xl font-bold text-white mb-2">{event.title}</h4>
                      <p className="text-gray-400 mb-4">{event.description}</p>
                      <div className="space-y-2 text-sm">
                        <div className="flex items-center gap-2 text-gray-300">
                          <Calendar className="w-4 h-4" />
                          <span>{event.date.toLocaleDateString()}</span>
                        </div>
                        <div className="flex items-center gap-2 text-gray-300">
                          <MapPin className="w-4 h-4" />
                          <span>{event.location}</span>
                        </div>
                        <div className="flex items-center gap-2 text-gray-300">
                          <Users className="w-4 h-4" />
                          <span>{event.attendees} asistentes</span>
                        </div>
                      </div>
                      <button className="w-full bg-purple-600 hover:bg-purple-700 text-white py-2 rounded-lg mt-4 transition-colors">
                        Unirse al Evento
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'guilds' && (
              <div>
                <h3 className="text-2xl font-bold text-white mb-6">Clanes</h3>
                <div className="bg-gray-800 rounded-lg p-6 text-center">
                  <Star className="w-16 h-16 mx-auto mb-4 text-purple-400" />
                  <h4 className="text-xl font-bold text-white mb-2">Sistema de Clanes</h4>
                  <p className="text-gray-400 mb-4">Únete o crea tu propio clan para competir y colaborar</p>
                  <button className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-lg transition-colors">
                    Próximamente
                  </button>
                </div>
              </div>
            )}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};
