
import React, { useState, useEffect, useRef } from 'react';
import { Send, Users, Minimize2, Maximize2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface Message {
  id: string;
  userId: string;
  username: string;
  content: string;
  timestamp: Date;
  type: 'text' | 'system' | 'emoji';
}

interface ChatSystemProps {
  userId?: string;
}

export const ChatSystem: React.FC<ChatSystemProps> = ({ userId }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isMinimized, setIsMinimized] = useState(false);
  const [onlineUsers, setOnlineUsers] = useState<number>(1);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Simular mensajes del sistema
    const systemMessage: Message = {
      id: '1',
      userId: 'system',
      username: 'Sistema',
      content: '¡Bienvenido a ZipVerse! Usa WASD para moverte y Espacio para saltar.',
      timestamp: new Date(),
      type: 'system'
    };
    setMessages([systemMessage]);

    // Simular usuarios conectados
    const interval = setInterval(() => {
      setOnlineUsers(Math.floor(Math.random() * 50) + 10);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim()) return;

    const message: Message = {
      id: Date.now().toString(),
      userId: userId || 'user',
      username: 'Tú',
      content: newMessage,
      timestamp: new Date(),
      type: 'text'
    };

    setMessages(prev => [...prev, message]);
    setNewMessage('');

    // Simular respuesta automática
    setTimeout(() => {
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        userId: 'bot',
        username: 'ZipBot',
        content: '¡Excelente! ¿Te gustaría explorar algún mundo específico?',
        timestamp: new Date(),
        type: 'text'
      };
      setMessages(prev => [...prev, botResponse]);
    }, 1000);
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const getMessageColor = (type: string, username: string) => {
    if (type === 'system') return 'text-yellow-400';
    if (username === 'ZipBot') return 'text-blue-400';
    return 'text-white';
  };

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <AnimatePresence>
        {!isMinimized ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="w-80 h-96 bg-black/80 backdrop-blur-md rounded-lg border border-purple-500/30 overflow-hidden"
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-purple-600 to-pink-600 p-3 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4" />
                <span className="text-white font-medium">Chat Global</span>
                <span className="text-xs bg-white/20 px-2 py-1 rounded-full">
                  {onlineUsers} online
                </span>
              </div>
              <button
                onClick={() => setIsMinimized(true)}
                className="text-white hover:bg-white/20 p-1 rounded"
              >
                <Minimize2 className="w-4 h-4" />
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 p-3 h-64 overflow-y-auto scrollbar-thin scrollbar-thumb-purple-500/50">
              {messages.map((message) => (
                <div key={message.id} className="mb-2">
                  <div className="flex items-start gap-2">
                    <div className="text-xs text-gray-400">
                      {formatTime(message.timestamp)}
                    </div>
                    <div className={`font-medium text-sm ${getMessageColor(message.type, message.username)}`}>
                      {message.username}:
                    </div>
                  </div>
                  <div className="text-gray-200 text-sm ml-2">
                    {message.content}
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <form onSubmit={handleSendMessage} className="p-3 border-t border-purple-500/30">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder="Escribe un mensaje..."
                  className="flex-1 bg-gray-800 text-white px-3 py-2 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
                <button
                  type="submit"
                  className="bg-gradient-to-r from-purple-500 to-pink-500 text-white p-2 rounded-lg hover:opacity-80 transition-opacity"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </form>
          </motion.div>
        ) : (
          <motion.button
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            onClick={() => setIsMinimized(false)}
            className="bg-gradient-to-r from-purple-600 to-pink-600 text-white p-3 rounded-full shadow-lg hover:shadow-xl transition-shadow"
          >
            <Users className="w-6 h-6" />
            <div className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
              {onlineUsers}
            </div>
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  );
};
