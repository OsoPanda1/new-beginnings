
import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Box, Sphere, Plane, Text3D, useTexture } from '@react-three/drei';
import { useBox, usePlane } from '@react-three/cannon';
import { Mesh } from 'three';
import { PlazaCentral } from './worlds/PlazaCentral';
import { MuseoVirtual } from './worlds/MuseoVirtual';
import { EspacioComercial } from './worlds/EspacioComercial';
import { ZonaJuegos } from './worlds/ZonaJuegos';

interface MetaverseWorldProps {
  world: string;
}

export const MetaverseWorld: React.FC<MetaverseWorldProps> = ({ world }) => {
  const [groundRef] = usePlane(() => ({ 
    rotation: [-Math.PI / 2, 0, 0], 
    position: [0, -0.5, 0],
    type: 'Static'
  }));

  const renderWorld = () => {
    switch (world) {
      case 'plaza':
        return <PlazaCentral />;
      case 'museo':
        return <MuseoVirtual />;
      case 'comercial':
        return <EspacioComercial />;
      case 'juegos':
        return <ZonaJuegos />;
      default:
        return <PlazaCentral />;
    }
  };

  return (
    <>
      {/* Suelo */}
      <Plane 
        ref={groundRef}
        args={[100, 100]} 
        receiveShadow
      >
        <meshStandardMaterial color="#2d5a27" />
      </Plane>

      {/* Mundo específico */}
      {renderWorld()}

      {/* Cielo y elementos ambientales */}
      <fog attach="fog" args={['#87CEEB', 50, 200]} />
    </>
  );
};
