
import React, { Suspense, useState } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Sky, Text, Html } from '@react-three/drei';
import { Physics } from '@react-three/cannon';
import { MetaverseWorld } from '@/components/metaverse/MetaverseWorld';
import { Avatar } from '@/components/metaverse/Avatar';
import { ChatSystem } from '@/components/metaverse/ChatSystem';
import { UserInterface } from '@/components/metaverse/UserInterface';
import { VirtualEconomy } from '@/components/metaverse/VirtualEconomy';
import { SocialHub } from '@/components/metaverse/SocialHub';
import { useAuth } from '@/hooks/useAuth';

const Metaverse = () => {
  const { user, isAuthenticated } = useAuth();
  const [selectedWorld, setSelectedWorld] = useState('plaza');
  const [showEconomy, setShowEconomy] = useState(false);
  const [showSocial, setShowSocial] = useState(false);

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center">
        <div className="text-center text-white">
          <h1 className="text-6xl font-bold mb-8 bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
            ZipVerse Meta Mundo
          </h1>
          <p className="text-xl mb-8">Ingresa al metaverso más avanzado</p>
          <button 
            onClick={() => window.location.href = '/auth'}
            className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold py-4 px-8 rounded-full text-lg transition-all duration-300 transform hover:scale-105"
          >
            Entrar al Metaverso
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full h-screen relative overflow-hidden bg-black">
      {/* Mundo 3D Principal */}
      <Canvas
        camera={{ position: [0, 5, 10], fov: 60 }}
        shadows
        className="absolute inset-0"
      >
        <Suspense fallback={
          <Html center>
            <div className="text-white text-xl">Cargando metaverso...</div>
          </Html>
        }>
          <Sky sunPosition={[100, 20, 100]} />
          <ambientLight intensity={0.3} />
          <directionalLight 
            position={[10, 10, 5]} 
            intensity={1} 
            castShadow 
            shadow-mapSize-width={2048}
            shadow-mapSize-height={2048}
          />
          
          <Physics>
            <MetaverseWorld world={selectedWorld} />
            <Avatar userId={user?.id} />
          </Physics>
          
          <OrbitControls 
            enablePan={true} 
            enableZoom={true} 
            enableRotate={true}
            maxDistance={50}
            minDistance={5}
          />
        </Suspense>
      </Canvas>

      {/* Interfaz de Usuario */}
      <UserInterface 
        onWorldChange={setSelectedWorld}
        onShowEconomy={() => setShowEconomy(true)}
        onShowSocial={() => setShowSocial(true)}
        currentWorld={selectedWorld}
      />

      {/* Sistema de Chat */}
      <ChatSystem userId={user?.id} />

      {/* Economía Virtual */}
      {showEconomy && (
        <VirtualEconomy 
          userId={user?.id}
          onClose={() => setShowEconomy(false)}
        />
      )}

      {/* Hub Social */}
      {showSocial && (
        <SocialHub 
          userId={user?.id}
          onClose={() => setShowSocial(false)}
        />
      )}
    </div>
  );
};

export default Metaverse;
