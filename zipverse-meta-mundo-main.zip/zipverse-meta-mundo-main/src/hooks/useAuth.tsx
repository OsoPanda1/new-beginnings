
import { useState, useEffect, createContext, useContext } from 'react';

interface User {
  id: string;
  username: string;
  email: string;
  avatar?: string;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  register: (username: string, email: string, password: string) => Promise<boolean>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    // Verificar si hay una sesión guardada
    const savedUser = localStorage.getItem('zipverse_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
      setIsAuthenticated(true);
    }
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    // Simulación de login - en producción conectar con Supabase
    if (email && password) {
      const userData: User = {
        id: '1',
        username: 'ZipUser',
        email: email,
        avatar: 'https://images.unsplash.com/photo-1649972904349-6e44c42644a7?w=100'
      };
      
      setUser(userData);
      setIsAuthenticated(true);
      localStorage.setItem('zipverse_user', JSON.stringify(userData));
      return true;
    }
    return false;
  };

  const register = async (username: string, email: string, password: string): Promise<boolean> => {
    // Simulación de registro - en producción conectar con Supabase
    if (username && email && password) {
      const userData: User = {
        id: Date.now().toString(),
        username: username,
        email: email,
        avatar: 'https://images.unsplash.com/photo-1649972904349-6e44c42644a7?w=100'
      };
      
      setUser(userData);
      setIsAuthenticated(true);
      localStorage.setItem('zipverse_user', JSON.stringify(userData));
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
    setIsAuthenticated(false);
    localStorage.removeItem('zipverse_user');
  };

  return (
    <AuthContext.Provider value={{ user, isAuthenticated, login, logout, register }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
