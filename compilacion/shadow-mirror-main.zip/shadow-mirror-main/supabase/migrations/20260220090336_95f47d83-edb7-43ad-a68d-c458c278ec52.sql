
-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Enums
CREATE TYPE membership_type AS ENUM ('FREE', 'PREMIUM', 'VIP');
CREATE TYPE action_status AS ENUM ('PENDING', 'EXECUTED', 'OMITTED');
CREATE TYPE engine_state AS ENUM ('CAIDA', 'ESTANCAMIENTO', 'FALSA_MEJORA', 'SILENCIO', 'RECOMPOSICION');
CREATE TYPE avatar_style_type AS ENUM ('emo', 'beetle', 'shadow-doll', 'void');

-- Profiles table
CREATE TABLE public.profiles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  alias TEXT NOT NULL,
  membership membership_type NOT NULL DEFAULT 'FREE',
  current_level INTEGER NOT NULL DEFAULT -1 CHECK (current_level BETWEEN -5 AND -1),
  total_delta_s INTEGER NOT NULL DEFAULT 0,
  avatar_style avatar_style_type NOT NULL DEFAULT 'shadow-doll',
  consecutive_shadow_days INTEGER NOT NULL DEFAULT 0,
  shadow_score INTEGER NOT NULL DEFAULT 0,
  legal_accepted_at TIMESTAMPTZ,
  legal_version TEXT DEFAULT 'v1.0',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Actions table
CREATE TABLE public.actions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  description TEXT NOT NULL,
  deadline TIMESTAMPTZ NOT NULL,
  status action_status NOT NULL DEFAULT 'PENDING',
  is_critical BOOLEAN NOT NULL DEFAULT false,
  pattern_key TEXT,
  declared_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  executed_at TIMESTAMPTZ,
  omitted_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Shadow metrics table (daily records)
CREATE TABLE public.shadow_metrics (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  date DATE NOT NULL,
  delta_s_change INTEGER NOT NULL DEFAULT 0,
  total_delta_s INTEGER NOT NULL DEFAULT 0,
  level INTEGER NOT NULL DEFAULT -1,
  engine_state engine_state NOT NULL DEFAULT 'ESTANCAMIENTO',
  executed_count INTEGER NOT NULL DEFAULT 0,
  omitted_count INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, date)
);

-- Legal consents table
CREATE TABLE public.legal_consents (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  version TEXT NOT NULL DEFAULT 'v1.0',
  accepted_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  ip_hash TEXT,
  checkboxes JSONB NOT NULL DEFAULT '{
    "age_18": false,
    "no_clinical": false,
    "current_state": false,
    "voluntary_use": false,
    "data_automation": false
  }'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.actions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.shadow_metrics ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.legal_consents ENABLE ROW LEVEL SECURITY;

-- RLS Policies: profiles
CREATE POLICY "Users can view own profile" ON public.profiles FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own profile" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own profile" ON public.profiles FOR DELETE USING (auth.uid() = user_id);

-- RLS Policies: actions
CREATE POLICY "Users can view own actions" ON public.actions FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own actions" ON public.actions FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own actions" ON public.actions FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own actions" ON public.actions FOR DELETE USING (auth.uid() = user_id);

-- RLS Policies: shadow_metrics
CREATE POLICY "Users can view own shadow metrics" ON public.shadow_metrics FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own shadow metrics" ON public.shadow_metrics FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own shadow metrics" ON public.shadow_metrics FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own shadow metrics" ON public.shadow_metrics FOR DELETE USING (auth.uid() = user_id);

-- RLS Policies: legal_consents
CREATE POLICY "Users can view own legal consents" ON public.legal_consents FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own legal consents" ON public.legal_consents FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own legal consents" ON public.legal_consents FOR UPDATE USING (auth.uid() = user_id);

-- Auto-update trigger for profiles.updated_at
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Trigger: auto-create profile on user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (user_id, alias)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'alias', split_part(NEW.email, '@', 1)))
  ON CONFLICT (user_id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Indexes
CREATE INDEX idx_actions_user_id ON public.actions(user_id);
CREATE INDEX idx_actions_status ON public.actions(user_id, status);
CREATE INDEX idx_shadow_metrics_user_date ON public.shadow_metrics(user_id, date DESC);
CREATE INDEX idx_legal_consents_user ON public.legal_consents(user_id);
