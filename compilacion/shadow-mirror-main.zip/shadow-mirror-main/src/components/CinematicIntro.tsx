import { useState, useEffect, useRef, useCallback } from "react";
import introMusic from "@/assets/musica/introduccion.mp3";

interface CinematicIntroProps {
  onComplete: () => void;
}

const SCENES = [
  // 0-10s: El silencio que pesa
  {
    start: 0,
    end: 10,
    text: "No todos fracasan ruidosamente.",
    subText: null,
    voText: null,
    phase: "silence",
  },
  // 10-20s: La sombra toma forma
  {
    start: 10,
    end: 20,
    text: "La mayoría pierde en silencio.",
    subText: null,
    voText: null,
    phase: "form",
  },
  // 20-30s: La verdad incómoda
  {
    start: 20,
    end: 30,
    text: null,
    subText: null,
    voText: "Lo que no decides… también decide por ti.",
    phase: "truth",
  },
  // 30-40s: Nace THE SOF
  {
    start: 30,
    end: 40,
    text: "THE SOF",
    subText: "El sistema que te muestra lo que ya estás perdiendo.",
    voText: null,
    phase: "birth",
  },
  // 40-50s: La promesa peligrosa
  {
    start: 40,
    end: 50,
    text: null,
    subText: null,
    voText:
      "THE SOF no te motiva. No te juzga. No te promete nada. Solo registra lo que dijiste que era importante… y lo que elegiste no hacer.",
    phase: "promise",
  },
  // 50-60s: El llamado
  {
    start: 50,
    end: 60,
    text: "Entra.\nMira tu sombra.",
    subText: "THE SOF · Plataforma de auto‑observación para adultos · 18+",
    voText: null,
    phase: "call",
  },
];

export function CinematicIntro({ onComplete }: CinematicIntroProps) {
  const [currentTime, setCurrentTime] = useState(0);
  const [started, setStarted] = useState(false);
  const [ending, setEnding] = useState(false);
  const [audioLoaded, setAudioLoaded] = useState(false);
  const [audioError, setAudioError] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);
  const rafRef = useRef<number>();

  const tick = useCallback(() => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
      if (audioRef.current.currentTime >= 58) {
        setEnding(true);
      }
    }
    rafRef.current = requestAnimationFrame(tick);
  }, []);

  const start = async () => {
    // Immediately start the intro even if audio hasn't loaded yet
    setStarted(true);
    rafRef.current = requestAnimationFrame(tick);
    
    // Try to play audio
    if (audioRef.current) {
      try {
        await audioRef.current.play();
      } catch (error) {
        console.error("Audio play error:", error);
        setAudioError(true);
      }
    } else {
      setAudioError(true);
    }
  };

  const skip = () => {
    if (audioRef.current) {
      audioRef.current.pause();
    }
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    onComplete();
  };

  useEffect(() => {
    if (ending) {
      const t = setTimeout(() => {
        if (audioRef.current) audioRef.current.pause();
        if (rafRef.current) cancelAnimationFrame(rafRef.current);
        onComplete();
      }, 2000);
      return () => clearTimeout(t);
    }
  }, [ending, onComplete]);

  useEffect(() => {
    // Fallback timer in case audio doesn't play or progress doesn't update
    let fallbackTimer: NodeJS.Timeout;
    if (started) {
      fallbackTimer = setInterval(() => {
        setCurrentTime(prev => {
          if (prev >= 60) {
            setEnding(true);
            return prev;
          }
          return prev + 0.1;
        });
      }, 100);
    }
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      if (fallbackTimer) clearInterval(fallbackTimer);
    };
  }, [started]);

  const handleAudioLoad = () => {
    setAudioLoaded(true);
    console.log("Audio loaded successfully");
  };

  const handleAudioError = () => {
    console.error("Audio loading error");
    setAudioError(true);
    setAudioLoaded(true);
  };

  const currentScene = SCENES.find(
    (s) => currentTime >= s.start && currentTime < s.end
  );
  const sceneProgress = currentScene
    ? (currentTime - currentScene.start) / (currentScene.end - currentScene.start)
    : 0;

  if (!started) {
    return (
      <div className="fixed inset-0 z-[100] bg-void flex items-center justify-center">
        <div className="text-center">
          <div className="w-px h-16 bg-gradient-to-b from-transparent to-cherry/60 mx-auto mb-8 animate-drift" />
          <p className="font-mono-sof text-muted-foreground mb-8 tracking-widest">
            THE SOF
          </p>
          <button
            onClick={start}
            className="font-mono-sof text-sm px-10 py-3 border border-cherry/40 text-cherry hover:border-cherry hover:bg-cherry/10 transition-all duration-700 tracking-widest"
          >
            INICIAR EXPERIENCIA
          </button>
          <button
            onClick={skip}
            className="block mx-auto mt-6 font-mono-sof text-muted-foreground/40 hover:text-muted-foreground transition-colors text-xs"
          >
            SALTAR INTRO
          </button>
          {audioError && (
            <p className="text-sm text-cherry/60 mt-4 font-mono-sof">
              Audio no disponible
            </p>
          )}
        </div>
        <audio 
          ref={audioRef} 
          src={introMusic} 
          preload="auto"
          onLoadedData={handleAudioLoad}
          onError={handleAudioError}
        />
      </div>
    );
  }

  return (
    <div
      className={`fixed inset-0 z-[100] bg-void transition-opacity duration-2000 ${
        ending ? "opacity-0" : "opacity-100"
      }`}
    >
      <audio 
        ref={audioRef} 
        src={introMusic} 
        preload="auto"
        onLoadedData={handleAudioLoad}
        onError={handleAudioError}
        loop={false}
      />

      {/* Skip button */}
      <button
        onClick={skip}
        className="fixed top-6 right-6 z-[110] font-mono-sof text-muted-foreground/30 hover:text-muted-foreground transition-colors text-xs"
      >
        SALTAR ▸
      </button>

      {/* Grain overlay */}
      <div
        className="absolute inset-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E")`,
          backgroundSize: "128px",
        }}
      />

      {/* Scanlines overlay */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-[0.03]"
        style={{
          backgroundImage: `repeating-linear-gradient(
            0deg,
            transparent,
            transparent 2px,
            hsl(0, 0%, 100%) 2px,
            hsl(0, 0%, 100%) 4px
          )`
        }}
      />

      {/* Scene: silence (0-10s) */}
      {currentScene?.phase === "silence" && (
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          {/* Vertical light line */}
          <div
            className="w-px bg-gradient-to-b from-transparent via-foreground/20 to-transparent"
            style={{
              height: `${40 + sceneProgress * 30}%`,
              opacity: 0.2 + sceneProgress * 0.3,
              boxShadow: `0 0 ${8 + sceneProgress * 16}px hsl(0, 0%, 60% / 0.2)`,
            }}
          />
          {/* Text typing effect */}
          {sceneProgress > 0.3 && (
            <p
              className="font-display text-xl md:text-3xl text-foreground/80 mt-12 text-center px-8 italic"
              style={{
                opacity: Math.min(1, (sceneProgress - 0.3) * 2.5),
                letterSpacing: "0.05em",
              }}
            >
              {currentScene.text!
                .split("")
                .slice(0, Math.floor((sceneProgress - 0.3) * 50))
                .join("")}
              <span className="animate-pulse text-cherry">|</span>
            </p>
          )}
        </div>
      )}

      {/* Scene: form (10-20s) */}
      {currentScene?.phase === "form" && (
        <div className="absolute inset-0 flex items-center justify-center overflow-hidden">
          {/* Particle field — data fragments */}
          <div className="relative w-full h-full">
            {Array.from({ length: 40 }).map((_, i) => {
              const x = 30 + Math.sin(i * 0.8) * 20 + sceneProgress * Math.cos(i) * 5;
              const y = 20 + Math.cos(i * 0.6) * 30 + sceneProgress * Math.sin(i * 1.2) * 8;
              const delay = i * 0.05;
              const opacity = Math.min(1, Math.max(0, (sceneProgress - delay) * 3)) * 0.4;
              return (
                <div
                  key={i}
                  className="absolute w-1 h-1 rounded-full"
                  style={{
                    left: `${x}%`,
                    top: `${y}%`,
                    backgroundColor: i % 5 === 0 ? "hsl(0, 65%, 38%)" : "hsl(0, 0%, 40%)",
                    opacity,
                    boxShadow: i % 5 === 0 ? "0 0 6px hsl(0, 65%, 38% / 0.5)" : "none",
                    transition: "all 0.3s ease",
                  }}
                />
              );
            })}
          </div>
          {/* Floating broken phrases */}
          {sceneProgress > 0.2 && (
            <div className="absolute inset-0 flex items-center justify-center">
              {["mañana", "luego", "después", "no ahora"].map((word, i) => (
                <span
                  key={word}
                  className="absolute font-mono-sof text-cherry/20"
                  style={{
                    fontSize: "0.5rem",
                    left: `${35 + i * 8}%`,
                    top: `${40 + Math.sin(i * 2) * 10}%`,
                    opacity: Math.max(0, Math.min(0.3, (sceneProgress - 0.2 - i * 0.1) * 2)),
                    transform: `rotate(${-5 + i * 3}deg)`,
                  }}
                >
                  {word}
                </span>
              ))}
            </div>
          )}
          {/* Main text */}
          {sceneProgress > 0.5 && (
            <p
              className="absolute font-display text-xl md:text-3xl text-foreground/70 italic text-center px-8"
              style={{
                opacity: Math.min(1, (sceneProgress - 0.5) * 3),
                bottom: "25%",
              }}
            >
              {currentScene.text}
            </p>
          )}
        </div>
      )}

      {/* Scene: truth (20-30s) */}
      {currentScene?.phase === "truth" && (
        <div className="absolute inset-0 flex items-center justify-center">
          {/* Orbital ring suggestion */}
          <div
            className="w-48 h-48 md:w-72 md:h-72 rounded-full border border-border/20"
            style={{
              transform: `rotate(${sceneProgress * 180}deg)`,
              opacity: 0.15 + sceneProgress * 0.2,
            }}
          />
          {/* Descending timeline dots */}
          <div className="absolute flex flex-col items-center gap-2" style={{ bottom: "20%" }}>
            {Array.from({ length: 7 }).map((_, i) => (
              <div
                key={i}
                className="w-1.5 h-1.5 rounded-full transition-all duration-500"
                style={{
                  backgroundColor:
                    i < Math.floor(sceneProgress * 7)
                      ? "hsl(0, 0%, 15%)"
                      : "hsl(0, 0%, 40%)",
                  opacity: i < Math.floor(sceneProgress * 7) ? 0.3 : 0.7,
                }}
              />
            ))}
          </div>
          {/* Voice-over text */}
          {sceneProgress > 0.3 && (
            <p
              className="absolute font-display text-2xl md:text-4xl text-foreground text-center px-8 max-w-2xl"
              style={{
                opacity: Math.min(1, (sceneProgress - 0.3) * 2),
              }}
            >
              "{currentScene.voText}"
            </p>
          )}
        </div>
      )}

      {/* Scene: birth (30-40s) */}
      {currentScene?.phase === "birth" && (
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          {/* Monolith */}
          <div
            className="relative"
            style={{
              width: `${60 + sceneProgress * 40}px`,
              height: `${100 + sceneProgress * 80}px`,
              background: "linear-gradient(180deg, hsl(0, 0%, 6%) 0%, hsl(0, 0%, 3%) 100%)",
              border: "1px solid hsl(0, 0%, 20%)",
              boxShadow: `0 0 ${20 + sceneProgress * 40}px hsl(0, 65%, 28% / ${0.1 + sceneProgress * 0.2})`,
              transition: "all 0.5s ease",
            }}
          >
            {/* HUD levels */}
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-1 p-2">
              {[0, -1, -2, -3, -4, -5].map((l, i) => (
                <span
                  key={l}
                  className="font-mono-sof block"
                  style={{
                    fontSize: "0.45rem",
                    color:
                      i <= Math.floor(sceneProgress * 6)
                        ? "hsl(0, 65%, 38%)"
                        : "hsl(0, 0%, 20%)",
                    opacity: i <= Math.floor(sceneProgress * 6) ? 0.8 : 0.2,
                    transition: `all ${0.3 + i * 0.1}s ease`,
                  }}
                >
                  {l}
                </span>
              ))}
            </div>
          </div>

          {/* Title */}
          {sceneProgress > 0.4 && (
            <div
              className="mt-8 text-center"
              style={{ opacity: Math.min(1, (sceneProgress - 0.4) * 3) }}
            >
              <h1 className="font-display text-5xl md:text-7xl text-foreground tracking-tight">
                {currentScene.text}
              </h1>
              <p className="font-display text-lg text-muted-foreground italic mt-2">
                The Shadow of Failure
              </p>
            </div>
          )}
          {sceneProgress > 0.7 && (
            <p
              className="mt-6 text-sm text-muted-foreground text-center max-w-md px-6"
              style={{ opacity: Math.min(1, (sceneProgress - 0.7) * 4) }}
            >
              {currentScene.subText}
            </p>
          )}
        </div>
      )}

      {/* Scene: promise (40-50s) */}
      {currentScene?.phase === "promise" && (
        <div className="absolute inset-0 flex items-center justify-center">
          {/* Faint dashboard fragments */}
          <div
            className="absolute inset-0 flex items-center justify-center opacity-10"
            style={{ opacity: 0.05 + sceneProgress * 0.1 }}
          >
            <div className="bg-card border border-border/30 p-6 w-64">
              <p className="font-mono-sof text-muted-foreground text-xs mb-2">NIVEL</p>
              <p className="font-display text-4xl text-foreground">-2</p>
              <div className="mt-3 h-1 bg-border/30 w-full">
                <div className="h-full bg-cherry/40" style={{ width: "60%" }} />
              </div>
            </div>
          </div>
          {/* VO text */}
          <div className="relative z-10 max-w-xl px-8">
            {currentScene.voText!.split(". ").map((sentence, i) => {
              const sentenceStart = i * 0.18;
              const visible = sceneProgress > sentenceStart;
              return (
                <p
                  key={i}
                  className="font-display text-lg md:text-xl text-foreground/80 mb-4 leading-relaxed"
                  style={{
                    opacity: visible ? Math.min(1, (sceneProgress - sentenceStart) * 4) : 0,
                    transform: visible ? "translateY(0)" : "translateY(10px)",
                    transition: "all 0.8s ease",
                  }}
                >
                  {sentence}{i < currentScene.voText!.split(". ").length - 1 ? "." : ""}
                </p>
              );
            })}
          </div>
        </div>
      )}

      {/* Scene: call (50-60s) */}
      {currentScene?.phase === "call" && (
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          {/* Portal glow */}
          <div
            className="absolute w-48 h-64 md:w-64 md:h-80 border border-foreground/10"
            style={{
              boxShadow: `inset 0 0 ${30 + sceneProgress * 40}px hsl(0, 0%, 60% / ${0.05 + sceneProgress * 0.1}), 0 0 ${20 + sceneProgress * 30}px hsl(0, 65%, 28% / ${sceneProgress * 0.15})`,
              opacity: 0.3 + sceneProgress * 0.5,
            }}
          />
          {/* Main CTA text */}
          {sceneProgress > 0.2 && (
            <div
              className="relative z-10 text-center"
              style={{ opacity: Math.min(1, (sceneProgress - 0.2) * 2.5) }}
            >
              <p className="font-display text-3xl md:text-5xl text-foreground whitespace-pre-line leading-tight">
                {currentScene.text}
              </p>
            </div>
          )}
          {sceneProgress > 0.6 && (
            <p
              className="relative z-10 mt-12 font-mono-sof text-muted-foreground/50 text-center text-xs px-8"
              style={{ opacity: Math.min(1, (sceneProgress - 0.6) * 3) }}
            >
              {currentScene.subText}
            </p>
          )}
        </div>
      )}

      {/* Progress bar */}
      <div className="fixed bottom-0 left-0 right-0 h-px bg-border/20">
        <div
          className="h-full bg-cherry/40 transition-all duration-100"
          style={{ width: `${(currentTime / 60) * 100}%` }}
        />
      </div>
    </div>
  );
}
