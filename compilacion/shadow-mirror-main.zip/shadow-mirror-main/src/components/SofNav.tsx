import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { useAuth } from "@/lib/auth-context";
import { useSoundEffects } from "@/lib/sound-effects";

const navItems = [
  { label: "SISTEMA", path: "/" },
  { label: "SOMBRA", path: "/dashboard" },
  { label: "PERFIL", path: "/profile" },
  { label: "ACCIONES", path: "/actions" },
  { label: "CÍRCULO", path: "/circle" },
  { label: "REPORTE", path: "/report" },
  { label: "PLANES", path: "/memberships" },
];

export function SofNav() {
  const location = useLocation();
  const [open, setOpen] = useState(false);
  const { user, signOut } = useAuth();
  const soundEffects = useSoundEffects();

  const handleNavClick = () => {
    soundEffects.click();
  };

  const handleNavHover = () => {
    soundEffects.hover();
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 border-b border-border bg-background/90 backdrop-blur-sm">
      <div className="max-w-6xl mx-auto px-6 h-14 flex items-center justify-between">
        <Link 
          to="/" 
          className="flex items-center gap-3 group"
          onClick={handleNavClick}
          onMouseEnter={handleNavHover}
        >
          <span className="w-2 h-2 rounded-full bg-cherry animate-pulse-cherry" />
          <span className="font-mono-sof text-foreground tracking-widest group-hover:text-cherry transition-colors duration-500">
            THE SOF
          </span>
        </Link>

        {/* Desktop */}
        <div className="hidden md:flex items-center gap-6">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              onClick={handleNavClick}
              onMouseEnter={handleNavHover}
              className={`font-mono-sof transition-colors duration-300 text-xs ${
                location.pathname === item.path
                  ? "text-cherry"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {item.label}
            </Link>
          ))}
          {user ? (
            <button
              onClick={() => {
                handleNavClick();
                signOut();
              }}
              onMouseEnter={handleNavHover}
              className="font-mono-sof text-xs text-muted-foreground hover:text-cherry transition-colors"
            >
              SALIR
            </button>
          ) : (
            <Link
              to="/auth"
              onClick={handleNavClick}
              onMouseEnter={handleNavHover}
              className="font-mono-sof text-xs text-cherry hover:text-foreground transition-colors"
            >
              ENTRAR
            </Link>
          )}
        </div>

        {/* Mobile toggle */}
        <button
          onClick={() => {
            handleNavClick();
            setOpen(!open);
          }}
          className="md:hidden flex flex-col gap-1.5 p-2"
          aria-label="Menu"
        >
          <span className={`block w-5 h-px bg-foreground transition-all duration-300 ${open ? "rotate-45 translate-y-2.5" : ""}`} />
          <span className={`block w-5 h-px bg-foreground transition-all duration-300 ${open ? "opacity-0" : ""}`} />
          <span className={`block w-5 h-px bg-foreground transition-all duration-300 ${open ? "-rotate-45 -translate-y-2.5" : ""}`} />
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="md:hidden border-t border-border bg-background px-6 py-4 flex flex-col gap-4">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              onClick={() => {
                handleNavClick();
                setOpen(false);
              }}
              onMouseEnter={handleNavHover}
              className={`font-mono-sof transition-colors duration-300 ${
                location.pathname === item.path
                  ? "text-cherry"
                  : "text-muted-foreground"
              }`}
            >
              {item.label}
            </Link>
          ))}
          {user ? (
            <button
              onClick={() => { 
                handleNavClick();
                signOut(); 
                setOpen(false); 
              }}
              onMouseEnter={handleNavHover}
              className="font-mono-sof text-muted-foreground hover:text-cherry text-left"
            >
              SALIR
            </button>
          ) : (
            <Link 
              to="/auth" 
              onClick={() => {
                handleNavClick();
                setOpen(false);
              }}
              onMouseEnter={handleNavHover}
              className="font-mono-sof text-cherry"
            >
              ENTRAR
            </Link>
          )}
        </div>
      )}
    </nav>
  );
}
