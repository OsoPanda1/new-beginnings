import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useSoundEffects } from "@/lib/sound-effects";

export type NotificationType = "success" | "error" | "warning" | "info" | "system";

interface Notification {
  id: string;
  title: string;
  message: string;
  type: NotificationType;
  duration?: number;
  timestamp: number;
}

interface NotificationSystemProps {
  className?: string;
}

const NOTIFICATION_CONFIG: Record<NotificationType, { color: string; icon: string; bgColor: string }> = {
  success: {
    color: "hsl(120, 30%, 35%)",
    icon: "✓",
    bgColor: "hsl(120, 30%, 10%)",
  },
  error: {
    color: "hsl(0, 65%, 38%)",
    icon: "!",
    bgColor: "hsl(0, 50%, 10%)",
  },
  warning: {
    color: "hsl(45, 80%, 45%)",
    icon: "⚠",
    bgColor: "hsl(45, 50%, 10%)",
  },
  info: {
    color: "hsl(0, 0%, 70%)",
    icon: "ℹ",
    bgColor: "hsl(0, 0%, 10%)",
  },
  system: {
    color: "hsl(0, 65%, 38%)",
    icon: "⚡",
    bgColor: "hsl(0, 65%, 8%)",
  },
};

let notificationIdCounter = 0;

export function NotificationSystem({ className = "" }: NotificationSystemProps) {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const soundEffects = useSoundEffects();
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const addNotification = (
    title: string,
    message: string,
    type: NotificationType = "info",
    duration: number = 5000
  ) => {
    const id = `notification-${notificationIdCounter++}`;
    const newNotification: Notification = {
      id,
      title,
      message,
      type,
      duration,
      timestamp: Date.now(),
    };

    setNotifications((prev) => [newNotification, ...prev]);
    
    soundEffects.notification();

    if (duration > 0) {
      setTimeout(() => {
        removeNotification(id);
      }, duration);
    }
  };

  const removeNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  const clearAllNotifications = () => {
    setNotifications([]);
  };

  // Provide notification methods to window for global access
  useEffect(() => {
    (window as any).notify = addNotification;
    (window as any).clearNotifications = clearAllNotifications;

    return () => {
      delete (window as any).notify;
      delete (window as any).clearNotifications;
    };
  }, []);

  return (
    <div className={`fixed top-6 right-6 z-[1000] flex flex-col gap-2 ${className}`}>
      <AnimatePresence>
        {notifications.map((notification) => {
          const config = NOTIFICATION_CONFIG[notification.type];

          return (
            <motion.div
              key={notification.id}
              initial={{ opacity: 0, x: 50, scale: 0.9 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: 50, scale: 0.9 }}
              transition={{
                type: "spring",
                stiffness: 500,
                damping: 30,
              }}
              className="relative group"
            >
              <div
                className="px-4 py-3 rounded-sm border backdrop-blur-sm transition-all duration-300"
                style={{
                  backgroundColor: config.bgColor,
                  borderColor: config.color,
                  boxShadow: `0 0 20px ${config.color}33`,
                }}
              >
                {/* Icon */}
                <div className="flex items-start gap-3">
                  <div
                    className="flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold"
                    style={{
                      backgroundColor: config.color,
                      color: "white",
                    }}
                  >
                    {config.icon}
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <h3
                      className="font-mono-sof text-sm font-semibold mb-1"
                      style={{
                        color: config.color,
                      }}
                    >
                      {notification.title}
                    </h3>
                    <p
                      className="text-xs leading-relaxed"
                      style={{
                        color: "hsl(0, 0%, 70%)",
                      }}
                    >
                      {notification.message}
                    </p>
                  </div>

                  {/* Close button */}
                  <button
                    onClick={() => removeNotification(notification.id)}
                    className="flex-shrink-0 ml-2 text-xs opacity-50 hover:opacity-100 transition-opacity"
                    style={{
                      color: config.color,
                    }}
                  >
                    ×
                  </button>
                </div>

                {/* Progress bar */}
                {notification.duration > 0 && (
                  <div className="mt-3 h-0.5 bg-black/30 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: "100%" }}
                      animate={{ width: "0%" }}
                      transition={{
                        duration: notification.duration / 1000,
                        ease: "linear",
                      }}
                      className="h-full rounded-full"
                      style={{
                        backgroundColor: config.color,
                      }}
                    />
                  </div>
                )}
              </div>

              {/* Glow effect */}
              <div
                className="absolute inset-0 rounded-sm blur-lg opacity-50 group-hover:opacity-75 transition-opacity"
                style={{
                  backgroundColor: config.color,
                }}
              />
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}

// Helper function to create notifications directly
export const notify = (
  title: string,
  message: string,
  type: NotificationType = "info",
  duration: number = 5000
) => {
  (window as any).notify?.(title, message, type, duration);
};