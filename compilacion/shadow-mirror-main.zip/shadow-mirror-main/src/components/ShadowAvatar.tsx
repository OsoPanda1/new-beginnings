import React from 'react';

type Level = -1 | -2 | -3 | -4 | -5;

export const LEVEL_CONFIG: Record<
  Level,
  { label: string; opacity: number; blur: number; color: string; phrase: string; distortion: number }
> = {
  "-1": {
    label: "EL SUSURRANTE",
    opacity: 0.7,
    blur: 1,
    color: "hsl(0, 0%, 70%)",
    phrase: "Todavía escuchas. La sombra aún es pequeña.",
    distortion: 0
  },
  "-2": {
    label: "EL POSTERGADO",
    opacity: 0.55,
    blur: 3,
    color: "hsl(0, 0%, 45%)",
    phrase: "Empiezas a posponer lo que sabes que debes hacer.",
    distortion: 2
  },
  "-3": {
    label: "EL SOMBRÍO",
    opacity: 0.45,
    blur: 6,
    color: "hsl(0, 30%, 30%)",
    phrase: "Evitas más de lo que admites.",
    distortion: 5
  },
  "-4": {
    label: "EL ENTERRADO",
    opacity: 0.30,
    blur: 12,
    color: "hsl(0, 50%, 15%)",
    phrase: "Tu sombra ya te precede a donde vas.",
    distortion: 10
  },
  "-5": {
    label: "LA SOMBRA",
    opacity: 0.15,
    blur: 20,
    color: "hsl(0, 80%, 5%)",
    phrase: "Ya no estás fallando. Estás desapareciendo.",
    distortion: 20
  },
};

const SIZE_MAP = {
  sm: 64,
  md: 120,
  lg: 200,
  xl: 320,
};

export function ShadowAvatar({ level, size = "md", animated = true }: { level: Level; size?: keyof typeof SIZE_MAP; animated?: boolean }) {
  const config = LEVEL_CONFIG[level];
  const px = SIZE_MAP[size];
  const isCritical = Math.abs(level) >= 4;

  return (
    <div className="group relative flex flex-col items-center">
      <div 
        className="relative overflow-visible"
        style={{ width: px, height: px }}
      >
        <svg
          viewBox="0 0 100 100"
          className={`w-full h-full transition-all duration-1000 ${animated ? "animate-breathe" : ""}`}
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            {/* Filtro de Turbulencia para deformar la sombra en niveles bajos */}
            <filter id={`noise-${level}`} filterUnits="userSpaceOnUse">
              <feTurbulence type="fractalNoise" baseFrequency={0.05} numOctaves={3} result="noise" />
              <feDisplacementMap in="SourceGraphic" in2="noise" scale={config.distortion} />
            </filter>
            
            {/* Gradiente de vacío central */}
            <radialGradient id={`voidGrad-${level}`} cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor={config.color} stopOpacity={config.opacity} />
              <stop offset="100%" stopColor="black" stopOpacity="0" />
            </radialGradient>
          </defs>

          {/* Aura de distorsión de fondo */}
          <circle 
            cx="50" cy="50" r="40" 
            fill={`url(#voidGrad-${level})`}
            filter={`blur(${config.blur}px)`}
            className={animated ? "animate-spin-slow" : ""}
            style={{ transformOrigin: 'center' }}
          />

          <g filter={`url(#noise-${level})`}>
            {/* Cuerpo principal - Se vuelve más amorfo */}
            <path
              d={Math.abs(level) < 3 
                ? "M50 20 Q65 20 65 40 Q65 70 50 85 Q35 70 35 40 Q35 20 50 20" 
                : "M50 15 Q80 20 70 50 Q85 80 50 90 Q15 80 30 50 Q20 20 50 15"}
              fill={config.color}
              opacity={config.opacity + 0.2}
              className="transition-all duration-700"
            />

            {/* Extremidades tipo "glitch" o tentáculos en niveles bajos */}
            {Math.abs(level) >= 3 && (
              <g stroke={config.color} strokeWidth="2" fill="none" opacity={config.opacity}>
                <path d="M35 50 Q10 60 5 85" className="animate-wiggle" />
                <path d="M65 50 Q90 60 95 85" className="animate-wiggle-delayed" />
              </g>
            )}
          </g>

          {/* Ojos - El único punto de enfoque */}
          <g>
            <circle 
              cx="42" cy="38" 
              r={isCritical ? "1.2" : "2"} 
              fill={isCritical ? "#ff0000" : config.color} 
              className={animated ? "animate-blink" : ""}
            />
            <circle 
              cx="58" cy="38" 
              r={isCritical ? "1.2" : "2"} 
              fill={isCritical ? "#ff0000" : config.color} 
              className={animated ? "animate-blink" : ""}
            />
          </g>
        </svg>

        {/* Partículas de "ceniza" para el nivel -5 */}
        {level === -5 && animated && (
          <div className="absolute inset-0 pointer-events-none animate-ash-fall">
             <div className="w-1 h-1 bg-white/10 rounded-full absolute top-1/4 left-1/4" />
             <div className="w-1 h-1 bg-white/5 rounded-full absolute top-1/2 right-1/3" />
             <div className="w-1 h-1 bg-white/8 rounded-full absolute top-3/4 left-2/3" />
             <div className="w-1 h-1 bg-white/3 rounded-full absolute top-1/3 right-1/4" />
          </div>
        )}
      </div>

      {/* Etiqueta de Nivel Estilizada */}
      <div className="mt-4 text-center">
        <span className="block text-[10px] uppercase tracking-[0.3em] font-bold opacity-50" style={{ color: config.color }}>
          {config.label}
        </span>
        <p className="mt-1 text-[11px] italic max-w-[150px] leading-tight opacity-40 group-hover:opacity-80 transition-opacity">
          "{config.phrase}"
        </p>
      </div>
    </div>
  );
}
