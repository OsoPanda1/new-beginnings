import React from 'react';

export const IconSof = ({ 
  size = 24, 
  color = 'currentColor', 
  className = '' 
}: { 
  size?: number; 
  color?: string; 
  className?: string 
}) => {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <path d="M12 2L2 7L12 12L22 7L12 2Z" />
      <path d="M2 17L12 22L22 17" />
      <path d="M2 12L12 17L22 12" />
    </svg>
  );
};

export const IconShadow = ({ 
  size = 24, 
  color = 'currentColor', 
  className = '' 
}: { 
  size?: number; 
  color?: string; 
  className?: string 
}) => {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <path d="M12 2L2 7L12 12L22 7L12 2Z" />
      <path d="M2 17L12 22L22 17" />
      <path d="M2 12L12 17L22 12" />
    </svg>
  );
};

export const IconLevel1 = ({ 
  size = 24, 
  color = 'currentColor', 
  className = '' 
}: { 
  size?: number; 
  color?: string; 
  className?: string 
}) => {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <circle cx="12" cy="12" r="10" strokeOpacity="0.3" />
      <circle cx="12" cy="12" r="8" strokeOpacity="0.5" />
      <circle cx="12" cy="12" r="6" strokeOpacity="0.7" />
      <circle cx="12" cy="12" r="2" />
    </svg>
  );
};

export const IconLevel2 = ({ 
  size = 24, 
  color = 'currentColor', 
  className = '' 
}: { 
  size?: number; 
  color?: string; 
  className?: string 
}) => {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <circle cx="12" cy="12" r="10" strokeOpacity="0.2" />
      <path d="M12 22C16 18 20 14 20 10C20 5.58172 16.4183 2 12 2C7.58172 2 4 5.58172 4 10C4 14 8 18 12 22Z" />
      <path d="M12 12C14.2091 12 16 10.2091 16 8C16 5.79086 14.2091 4 12 4C9.79086 4 8 5.79086 8 8C8 10.2091 9.79086 12 12 12Z" />
    </svg>
  );
};

export const IconLevel3 = ({ 
  size = 24, 
  color = 'currentColor', 
  className = '' 
}: { 
  size?: number; 
  color?: string; 
  className?: string 
}) => {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <path d="M12 2L4 6V18L12 22L20 18V6L12 2Z" />
      <path d="M12 12L4 10V14L12 16L20 14V10L12 12Z" opacity="0.3" />
      <path d="M12 8L4 7V9L12 10L20 9V7L12 8Z" opacity="0.5" />
    </svg>
  );
};

export const IconLevel4 = ({ 
  size = 24, 
  color = 'currentColor', 
  className = '' 
}: { 
  size?: number; 
  color?: string; 
  className?: string 
}) => {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <path d="M12 2C12 2 8 6 8 12C8 18 12 22 12 22C12 22 16 18 16 12C16 6 12 2 12 2Z" />
      <path d="M12 6C12 6 14 8 14 12C14 16 12 18 12 18C12 18 10 16 10 12C10 8 12 6 12 6Z" opacity="0.5" />
    </svg>
  );
};

export const IconLevel5 = ({ 
  size = 24, 
  color = 'currentColor', 
  className = '' 
}: { 
  size?: number; 
  color?: string; 
  className?: string 
}) => {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <path d="M12 2C12 2 8 6 8 12C8 18 12 22 12 22C12 22 16 18 16 12C16 6 12 2 12 2Z" />
      <path d="M12 6C12 6 14 8 14 12C14 16 12 18 12 18C12 18 10 16 10 12C10 8 12 6 12 6Z" opacity="0.5" />
      <circle cx="12" cy="12" r="2" opacity="0.3" />
    </svg>
  );
};

export const IconAction = ({ 
  size = 24, 
  color = 'currentColor', 
  className = '' 
}: { 
  size?: number; 
  color?: string; 
  className?: string 
}) => {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <path d="M12 1L2 7L12 13L22 7L12 1Z" />
      <path d="M2 17L12 23L22 17" />
      <path d="M2 12L12 18L22 12" />
    </svg>
  );
};

export const IconCircle = ({ 
  size = 24, 
  color = 'currentColor', 
  className = '' 
}: { 
  size?: number; 
  color?: string; 
  className?: string 
}) => {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <circle cx="12" cy="12" r="10" />
      <circle cx="12" cy="12" r="4" />
      <line x1="12" y1="4" x2="12" y2="8" />
      <line x1="12" y1="16" x2="12" y2="20" />
      <line x1="4" y1="12" x2="8" y2="12" />
      <line x1="16" y1="12" x2="20" y2="12" />
    </svg>
  );
};

export const IconReport = ({ 
  size = 24, 
  color = 'currentColor', 
  className = '' 
}: { 
  size?: number; 
  color?: string; 
  className?: string 
}) => {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <path d="M14 2H6C5.46957 2 4.96086 2.21071 4.58579 2.58579C4.21071 2.96086 4 3.46957 4 4V20C4 20.5304 4.21071 21.0391 4.58579 21.4142C4.96086 21.7893 5.46957 22 6 22H18C18.5304 22 19.0391 21.7893 19.4142 21.4142C19.7893 21.0391 20 20.5304 20 20V8L14 2Z" />
      <polyline points="14 2 14 8 20 8" />
      <line x1="16" y1="13" x2="8" y2="13" />
      <line x1="16" y1="17" x2="8" y2="17" />
      <polyline points="10 9 9 9 8 9" />
    </svg>
  );
};

export const IconProfile = ({ 
  size = 24, 
  color = 'currentColor', 
  className = '' 
}: { 
  size?: number; 
  color?: string; 
  className?: string 
}) => {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <circle cx="12" cy="7" r="4" />
      <path d="M5 21V19C5 17.9391 5.42143 16.9217 6.17157 16.1716C6.92172 15.4214 7.93913 15 9 15H15C16.0609 15 17.0783 15.4214 17.8284 16.1716C18.5786 16.9217 19 17.9391 19 19V21" />
    </svg>
  );
};

export const IconMembership = ({ 
  size = 24, 
  color = 'currentColor', 
  className = '' 
}: { 
  size?: number; 
  color?: string; 
  className?: string 
}) => {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <path d="M12 2L2 7V17L12 22L22 17V7L12 2Z" />
      <circle cx="12" cy="12" r="3" />
    </svg>
  );
};

export const IconAlert = ({ 
  size = 24, 
  color = 'currentColor', 
  className = '' 
}: { 
  size?: number; 
  color?: string; 
  className?: string 
}) => {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <circle cx="12" cy="12" r="10" />
      <line x1="12" y1="8" x2="12" y2="12" />
      <line x1="12" y1="16" x2="12.01" y2="16" />
    </svg>
  );
};

export const IconCheck = ({ 
  size = 24, 
  color = 'currentColor', 
  className = '' 
}: { 
  size?: number; 
  color?: string; 
  className?: string 
}) => {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <polyline points="20 6 9 17 4 12" />
    </svg>
  );
};

export const IconX = ({ 
  size = 24, 
  color = 'currentColor', 
  className = '' 
}: { 
  size?: number; 
  color?: string; 
  className?: string 
}) => {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke={color} 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <line x1="18" y1="6" x2="6" y2="18" />
      <line x1="6" y1="6" x2="18" y2="18" />
    </svg>
  );
};