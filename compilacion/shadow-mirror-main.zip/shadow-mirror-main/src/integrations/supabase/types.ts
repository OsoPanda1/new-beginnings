export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      actions: {
        Row: {
          created_at: string
          deadline: string
          declared_at: string
          description: string
          executed_at: string | null
          id: string
          is_critical: boolean
          omitted_at: string | null
          pattern_key: string | null
          status: Database["public"]["Enums"]["action_status"]
          user_id: string
        }
        Insert: {
          created_at?: string
          deadline: string
          declared_at?: string
          description: string
          executed_at?: string | null
          id?: string
          is_critical?: boolean
          omitted_at?: string | null
          pattern_key?: string | null
          status?: Database["public"]["Enums"]["action_status"]
          user_id: string
        }
        Update: {
          created_at?: string
          deadline?: string
          declared_at?: string
          description?: string
          executed_at?: string | null
          id?: string
          is_critical?: boolean
          omitted_at?: string | null
          pattern_key?: string | null
          status?: Database["public"]["Enums"]["action_status"]
          user_id?: string
        }
        Relationships: []
      }
      legal_consents: {
        Row: {
          accepted_at: string
          checkboxes: Json
          created_at: string
          id: string
          ip_hash: string | null
          user_id: string
          version: string
        }
        Insert: {
          accepted_at?: string
          checkboxes?: Json
          created_at?: string
          id?: string
          ip_hash?: string | null
          user_id: string
          version?: string
        }
        Update: {
          accepted_at?: string
          checkboxes?: Json
          created_at?: string
          id?: string
          ip_hash?: string | null
          user_id?: string
          version?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          alias: string
          avatar_style: Database["public"]["Enums"]["avatar_style_type"]
          consecutive_shadow_days: number
          created_at: string
          current_level: number
          id: string
          legal_accepted_at: string | null
          legal_version: string | null
          membership: Database["public"]["Enums"]["membership_type"]
          shadow_score: number
          total_delta_s: number
          updated_at: string
          user_id: string
        }
        Insert: {
          alias: string
          avatar_style?: Database["public"]["Enums"]["avatar_style_type"]
          consecutive_shadow_days?: number
          created_at?: string
          current_level?: number
          id?: string
          legal_accepted_at?: string | null
          legal_version?: string | null
          membership?: Database["public"]["Enums"]["membership_type"]
          shadow_score?: number
          total_delta_s?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          alias?: string
          avatar_style?: Database["public"]["Enums"]["avatar_style_type"]
          consecutive_shadow_days?: number
          created_at?: string
          current_level?: number
          id?: string
          legal_accepted_at?: string | null
          legal_version?: string | null
          membership?: Database["public"]["Enums"]["membership_type"]
          shadow_score?: number
          total_delta_s?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      shadow_metrics: {
        Row: {
          created_at: string
          date: string
          delta_s_change: number
          engine_state: Database["public"]["Enums"]["engine_state"]
          executed_count: number
          id: string
          level: number
          omitted_count: number
          total_delta_s: number
          user_id: string
        }
        Insert: {
          created_at?: string
          date: string
          delta_s_change?: number
          engine_state?: Database["public"]["Enums"]["engine_state"]
          executed_count?: number
          id?: string
          level?: number
          omitted_count?: number
          total_delta_s?: number
          user_id: string
        }
        Update: {
          created_at?: string
          date?: string
          delta_s_change?: number
          engine_state?: Database["public"]["Enums"]["engine_state"]
          executed_count?: number
          id?: string
          level?: number
          omitted_count?: number
          total_delta_s?: number
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      action_status: "PENDING" | "EXECUTED" | "OMITTED"
      avatar_style_type: "emo" | "beetle" | "shadow-doll" | "void"
      engine_state:
        | "CAIDA"
        | "ESTANCAMIENTO"
        | "FALSA_MEJORA"
        | "SILENCIO"
        | "RECOMPOSICION"
      membership_type: "FREE" | "PREMIUM" | "VIP"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      action_status: ["PENDING", "EXECUTED", "OMITTED"],
      avatar_style_type: ["emo", "beetle", "shadow-doll", "void"],
      engine_state: [
        "CAIDA",
        "ESTANCAMIENTO",
        "FALSA_MEJORA",
        "SILENCIO",
        "RECOMPOSICION",
      ],
      membership_type: ["FREE", "PREMIUM", "VIP"],
    },
  },
} as const
