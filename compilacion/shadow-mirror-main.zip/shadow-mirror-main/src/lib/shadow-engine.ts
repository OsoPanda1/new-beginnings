export type ShadowLevel = -1 | -2 | -3 | -4 | -5;

export interface Action {
  id: string;
  description: string;
  declaredAt: Date;
  expectedDate: Date;
  status: "PENDING" | "EXECUTED" | "OMITTED";
}

export interface ShadowState {
  level: ShadowLevel;
  omissions: number;
  executions: number;
  deltaS: number;
  consecutiveShadowDays: number;
  trend: "ascending" | "descending" | "stable";
}

export function clampLevel(level: number): ShadowLevel {
  return Math.max(-5, Math.min(-1, level)) as ShadowLevel;
}

export function computeDeltaShadow(baseline: number, executedActions: number): number {
  return Math.max(0, parseFloat((baseline - executedActions).toFixed(2)));
}

export function descendLevel(currentLevel: ShadowLevel, levels: number): ShadowLevel {
  return clampLevel(currentLevel - levels);
}

export function ascendLevel(currentLevel: ShadowLevel): ShadowLevel {
  return clampLevel(currentLevel + 1);
}

export function omissionsToLevelDrop(totalOmissions: number): number {
  return Math.floor(totalOmissions / 3);
}

export function mapAvatarState(level: ShadowLevel): string {
  const map: Record<ShadowLevel, string> = {
    "-1": "SUSURRANTE",
    "-2": "POSTERGADO",
    "-3": "SOMBRIO",
    "-4": "ENTERRADO",
    "-5": "SOMBRA",
  };
  return map[level];
}

export function getShadowPhrase(level: ShadowLevel, trend: "ascending" | "descending" | "stable"): string {
  const base: Record<ShadowLevel, string[]> = {
    "-1": [
      "La sombra apenas existe. ¿La alimentarás?",
      "Todavía tienes tiempo de no tener nada que confesar.",
    ],
    "-2": [
      "Empezaste a posponer. La sombra lo registró.",
      "No hiciste lo que dijiste. Nadie te culpa. Solo la sombra sabe.",
    ],
    "-3": [
      "Evitas más de lo que admites.",
      "Tu sombra es más activa que tú.",
    ],
    "-4": [
      "La sombra ya te precede a donde vas.",
      "Lo que no haces define más que lo que haces.",
    ],
    "-5": [
      "Ya no estás fallando. Estás desapareciendo.",
      "La sombra no te persigue. Ella es lo que queda.",
    ],
  };

  const trendSuffix: Record<string, string> = {
    ascending: " Algo se mueve.",
    descending: " La caída continúa.",
    stable: " El silencio también es una respuesta.",
  };

  const phrases = base[level];
  return phrases[Math.floor(Math.random() * phrases.length)] + trendSuffix[trend];
}

export function getAlertMessage(type: "omission" | "silence" | "fall" | "existential"): string {
  const messages: Record<string, string[]> = {
    omission: [
      "No hiciste nada. La sombra lo notó.",
      "Declaraste. No ejecutaste. Eso tiene nombre.",
      "La acción murió en el intento de hacerla.",
    ],
    silence: [
      "Tu sombra creció en silencio.",
      "72 horas. Sin rastro. Solo ausencia.",
      "El silencio también es una decisión.",
    ],
    fall: [
      "Caíste un nivel. La sombra se hizo más densa.",
      "Un nivel menos. No es un error. Es un patrón.",
    ],
    existential: [
      "No estás fallando. Estás desapareciendo de tu propio plan.",
      "En este punto, la sombra ya no te sigue. Te lidera.",
    ],
  };

  const list = messages[type];
  return list[Math.floor(Math.random() * list.length)];
}

export function calculateShadowScore(level: ShadowLevel, omissions: number, executions: number): number {
  const baseScore = Math.abs(level) * 100;
  const omissionPenalty = omissions * 15;
  const executionBonus = executions * 5;
  return Math.max(0, baseScore + omissionPenalty - executionBonus);
}

export function predictLevel(level: ShadowLevel, omissionRate: number, consecutiveDays: number): ShadowLevel {
  const predictedDrop = Math.floor(omissionRate / 30) + Math.floor(consecutiveDays / 7);
  return clampLevel(level - predictedDrop);
}

export function getTimeToNextLevel(level: ShadowLevel, omissionRate: number): number {
  if (level === -5) return Infinity;
  const daysPerLevel = 14 - (omissionRate / 10);
  return Math.max(3, daysPerLevel);
}

export function analyzeBehaviorPattern(omissions: number, consecutiveDays: number): string {
  if (consecutiveDays >= 7) return "PATRON_DE_ABANDONO";
  if (omissions >= 5) return "PATRON_DE_OMISION";
  if (omissions === 0) return "PATRON_DE_EJECUCION";
  return "PATRON_INDETERMINADO";
}
