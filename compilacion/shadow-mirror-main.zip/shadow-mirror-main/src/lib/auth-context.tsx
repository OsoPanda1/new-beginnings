import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { User, Session } from "@supabase/supabase-js";

type MembershipTier = "FREE" | "PREMIUM" | "VIP";

interface AuthState {
  user: User | null;
  session: Session | null;
  loading: boolean;
  membership: MembershipTier;
  subscriptionEnd: string | null;
  checkSubscription: () => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthState | undefined>(undefined);

const STRIPE_TIERS: Record<string, { tier: MembershipTier }> = {
  "prod_U19ehM4TyuCiLu": { tier: "PREMIUM" },
  "prod_U19eEMEGARqYh6": { tier: "VIP" },
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [membership, setMembership] = useState<MembershipTier>("FREE");
  const [subscriptionEnd, setSubscriptionEnd] = useState<string | null>(null);

  const checkSubscription = async () => {
    try {
      const { data, error } = await supabase.functions.invoke("check-subscription");
      if (error) return;
      if (data?.subscribed && data?.product_id) {
        const tier = STRIPE_TIERS[data.product_id]?.tier || "FREE";
        setMembership(tier);
        setSubscriptionEnd(data.subscription_end || null);
        // Sync to DB
        await supabase.from("profiles").update({ membership: tier }).eq("user_id", user?.id);
      } else {
        setMembership("FREE");
        setSubscriptionEnd(null);
      }
    } catch {
      // silent
    }
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setSession(null);
    setMembership("FREE");
    setSubscriptionEnd(null);
  };

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      setUser(session?.user ?? null);
      setLoading(false);
    });

    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  // Check subscription when user logs in
  useEffect(() => {
    if (user) {
      checkSubscription();
      const interval = setInterval(checkSubscription, 60000);
      return () => clearInterval(interval);
    }
  }, [user?.id]);

  return (
    <AuthContext.Provider value={{ user, session, loading, membership, subscriptionEnd, checkSubscription, signOut }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
