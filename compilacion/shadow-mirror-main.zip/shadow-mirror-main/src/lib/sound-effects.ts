import { useState, useEffect } from 'react';

// Sound effects interface
interface SoundEffects {
  click: HTMLAudioElement | null;
  hover: HTMLAudioElement | null;
  success: HTMLAudioElement | null;
  error: HTMLAudioElement | null;
  notification: HTMLAudioElement | null;
  transition: HTMLAudioElement | null;
}

// Simple sound effect generator using Web Audio API
class SoundSystem {
  private audioContext: AudioContext | null = null;
  private sounds: Partial<SoundEffects> = {};
  private enabled: boolean = true;

  constructor() {
    try {
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    } catch (error) {
      console.error('Web Audio API not supported');
    }
  }

  // Generate a click sound
  playClick() {
    if (!this.enabled || !this.audioContext) return;
    this.playTone(800, 0.05, 'square');
  }

  // Generate a hover sound
  playHover() {
    if (!this.enabled || !this.audioContext) return;
    this.playTone(400, 0.02, 'sine');
  }

  // Generate a success sound
  playSuccess() {
    if (!this.enabled || !this.audioContext) return;
    this.playTone(600, 0.1, 'sine');
    setTimeout(() => this.playTone(800, 0.1, 'sine'), 50);
  }

  // Generate an error sound
  playError() {
    if (!this.enabled || !this.audioContext) return;
    this.playTone(200, 0.1, 'sawtooth');
    setTimeout(() => this.playTone(150, 0.1, 'sawtooth'), 50);
  }

  // Generate a notification sound
  playNotification() {
    if (!this.enabled || !this.audioContext) return;
    this.playTone(500, 0.05, 'sine');
    setTimeout(() => this.playTone(700, 0.05, 'sine'), 50);
    setTimeout(() => this.playTone(900, 0.1, 'sine'), 100);
  }

  // Generate a transition sound
  playTransition() {
    if (!this.enabled || !this.audioContext) return;
    this.playTone(300, 0.2, 'triangle');
  }

  // Play a single tone
  private playTone(frequency: number, duration: number, waveType: OscillatorType = 'sine') {
    if (!this.audioContext) return;

    const oscillator = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(this.audioContext.destination);

    oscillator.frequency.setValueAtTime(frequency, this.audioContext.currentTime);
    oscillator.type = waveType;

    gainNode.gain.setValueAtTime(0.1, this.audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + duration);

    oscillator.start(this.audioContext.currentTime);
    oscillator.stop(this.audioContext.currentTime + duration);
  }

  // Toggle sound enabled/disabled
  toggle() {
    this.enabled = !this.enabled;
  }

  // Check if sound is enabled
  isEnabled() {
    return this.enabled;
  }

  // Initialize audio context on user interaction
  initialize() {
    if (this.audioContext && this.audioContext.state === 'suspended') {
      this.audioContext.resume();
    }
  }
}

// Create global sound system instance
let soundSystemInstance: SoundSystem | null = null;

export const getSoundSystem = (): SoundSystem => {
  if (!soundSystemInstance) {
    soundSystemInstance = new SoundSystem();
  }
  return soundSystemInstance;
};

// React hook for sound effects
export const useSoundEffects = () => {
  const [soundSystem] = useState(() => getSoundSystem());

  useEffect(() => {
    // Initialize audio context on first user interaction
    const handleInteraction = () => {
      soundSystem.initialize();
      window.removeEventListener('click', handleInteraction);
    };
    
    window.addEventListener('click', handleInteraction);
    
    return () => {
      window.removeEventListener('click', handleInteraction);
    };
  }, [soundSystem]);

  return {
    click: () => soundSystem.playClick(),
    hover: () => soundSystem.playHover(),
    success: () => soundSystem.playSuccess(),
    error: () => soundSystem.playError(),
    notification: () => soundSystem.playNotification(),
    transition: () => soundSystem.playTransition(),
    toggle: () => soundSystem.toggle(),
    isEnabled: () => soundSystem.isEnabled(),
  };
};

// HOC to wrap components with sound effects
export const withSoundEffects = <P extends object>(Component: React.ComponentType<P>) => {
  return (props: P) => {
    const soundEffects = useSoundEffects();
    return <Component {...props} soundEffects={soundEffects} />;
  };
};