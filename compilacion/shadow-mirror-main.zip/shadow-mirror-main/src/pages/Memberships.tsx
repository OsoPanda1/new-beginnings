import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

const PLANS = [
  {
    id: "FREE",
    name: "FREE",
    price: "$0",
    priceId: null,
    features: [
      "Nivel actual",
      "Frase genérica",
      "Última omisión",
      "Registro de acciones",
    ],
  },
  {
    id: "PREMIUM",
    name: "PREMIUM",
    price: "$9.99/mes",
    priceId: "price_1T37LN2c9MT9LcDvykN37WcX",
    productId: "prod_U19ehM4TyuCiLu",
    features: [
      "Todo lo de FREE",
      "Tendencias de sombra",
      "Patrones de omisión",
      "Comparación anónima",
      "Proyección si sigues igual",
    ],
  },
  {
    id: "VIP",
    name: "VIP",
    price: "$19.99/mes",
    priceId: "price_1T37LP2c9MT9LcDvJXOSz8aa",
    productId: "prod_U19eEMEGARqYh6",
    features: [
      "Todo lo de PREMIUM",
      "Perfil completo de sombra",
      "Narrativa del sistema",
      "Proyección: si sigues igual",
      "Reporte de amigo ($5.99)",
    ],
  },
];

export default function Memberships() {
  const { user, membership } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [loading, setLoading] = useState<string | null>(null);

  const handleCheckout = async (priceId: string) => {
    if (!user) {
      navigate("/auth");
      return;
    }
    setLoading(priceId);
    try {
      const { data, error } = await supabase.functions.invoke("create-checkout", {
        body: { priceId },
      });
      if (error) throw error;
      if (data?.url) window.open(data.url, "_blank");
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    } finally {
      setLoading(null);
    }
  };

  const handlePortal = async () => {
    try {
      const { data, error } = await supabase.functions.invoke("customer-portal");
      if (error) throw error;
      if (data?.url) window.open(data.url, "_blank");
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  return (
    <div className="min-h-screen bg-background pt-14">
      <div className="max-w-5xl mx-auto px-6 py-12">
        <div className="mb-16">
          <p className="font-mono-sof text-muted-foreground mb-2">MONETIZACIÓN</p>
          <h1 className="font-display text-4xl md:text-5xl text-foreground">Membresías</h1>
          <p className="text-muted-foreground mt-4 max-w-xl">
            THE SOF no te vende mejoras. Te ofrece más espejo.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {PLANS.map((plan) => {
            const isCurrent = membership === plan.id;
            return (
              <div
                key={plan.id}
                className={`bg-card border p-8 flex flex-col relative ${
                  isCurrent ? "border-cherry" : "border-border"
                }`}
              >
                {isCurrent && (
                  <div className="absolute top-0 right-0 bg-cherry text-primary-foreground font-mono-sof text-xs px-3 py-1">
                    TU PLAN
                  </div>
                )}

                <p className="font-mono-sof text-cherry mb-2">{plan.name}</p>
                <p className="font-display text-4xl text-foreground mb-6">{plan.price}</p>

                <ul className="space-y-3 flex-1 mb-8">
                  {plan.features.map((f) => (
                    <li key={f} className="text-sm text-muted-foreground flex items-start gap-2">
                      <span className="w-1 h-1 rounded-full bg-cherry mt-2 flex-shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>

                {plan.priceId && !isCurrent && (
                  <button
                    onClick={() => handleCheckout(plan.priceId!)}
                    disabled={loading === plan.priceId}
                    className="font-mono-sof text-sm px-6 py-3 border border-cherry text-cherry hover:bg-cherry hover:text-primary-foreground transition-all duration-500 tracking-widest disabled:opacity-30"
                  >
                    {loading === plan.priceId ? "..." : "SUSCRIBIRSE"}
                  </button>
                )}

                {isCurrent && plan.priceId && (
                  <button
                    onClick={handlePortal}
                    className="font-mono-sof text-sm px-6 py-3 border border-border text-muted-foreground hover:text-foreground transition-all duration-300 tracking-widest"
                  >
                    GESTIONAR SUSCRIPCIÓN
                  </button>
                )}

                {plan.id === "FREE" && isCurrent && (
                  <p className="font-mono-sof text-muted-foreground text-xs text-center">PLAN ACTUAL</p>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
