import { useState, useEffect } from "react";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { Link } from "react-router-dom";
import type { Tables } from "@/integrations/supabase/types";

type DbAction = Tables<"actions">;

const STATUS_LABELS: Record<string, string> = {
  PENDING: "PENDIENTE",
  EXECUTED: "EJECUTADA",
  OMITTED: "OMITIDA",
};

const STATUS_COLORS: Record<string, string> = {
  PENDING: "hsl(0, 0%, 50%)",
  EXECUTED: "hsl(120, 30%, 35%)",
  OMITTED: "hsl(0, 65%, 38%)",
};

export default function Actions() {
  const { user } = useAuth();
  const [actions, setActions] = useState<DbAction[]>([]);
  const [loading, setLoading] = useState(true);
  const [newDesc, setNewDesc] = useState("");
  const [newDate, setNewDate] = useState("");
  const [filter, setFilter] = useState<"ALL" | "PENDING" | "EXECUTED" | "OMITTED">("ALL");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!user) { setLoading(false); return; }
    loadActions();
  }, [user?.id]);

  const loadActions = async () => {
    if (!user) return;
    setLoading(true);
    const { data } = await supabase
      .from("actions")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });
    setActions(data ?? []);
    setLoading(false);
  };

  const addAction = async () => {
    if (!newDesc.trim() || !newDate || !user) return;
    setSubmitting(true);
    const { data, error } = await supabase.from("actions").insert({
      user_id: user.id,
      description: newDesc.trim(),
      deadline: new Date(newDate).toISOString(),
    }).select().single();

    if (data && !error) {
      setActions((prev) => [data, ...prev]);
      setNewDesc("");
      setNewDate("");
    }
    setSubmitting(false);
  };

  const updateStatus = async (id: string, status: "EXECUTED" | "OMITTED") => {
    const updateData: any = { status };
    if (status === "EXECUTED") updateData.executed_at = new Date().toISOString();
    if (status === "OMITTED") updateData.omitted_at = new Date().toISOString();

    const { error } = await supabase.from("actions").update(updateData).eq("id", id);
    if (!error) {
      setActions((prev) => prev.map((a) => (a.id === id ? { ...a, ...updateData } : a)));
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background pt-14 flex items-center justify-center">
        <div className="text-center">
          <p className="font-display text-xl text-foreground mb-4">Debes entrar al sistema</p>
          <Link to="/auth" className="font-mono-sof text-cherry hover:underline">ENTRAR</Link>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background pt-14 flex items-center justify-center">
        <p className="font-mono-sof text-muted-foreground animate-pulse">CARGANDO ACCIONES...</p>
      </div>
    );
  }

  const filtered = filter === "ALL" ? actions : actions.filter((a) => a.status === filter);
  const omissions = actions.filter((a) => a.status === "OMITTED").length;
  const executions = actions.filter((a) => a.status === "EXECUTED").length;
  const pending = actions.filter((a) => a.status === "PENDING").length;

  return (
    <div className="min-h-screen bg-background pt-14">
      <div className="max-w-4xl mx-auto px-6 py-12">
        <div className="mb-16">
          <p className="font-mono-sof text-muted-foreground mb-2">REGISTRO</p>
          <h1 className="font-display text-4xl md:text-5xl text-foreground">Acciones Declaradas</h1>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-12">
          {[
            { label: "OMITIDAS", value: omissions, color: "hsl(0, 65%, 38%)" },
            { label: "PENDIENTES", value: pending, color: "hsl(0, 0%, 50%)" },
            { label: "EJECUTADAS", value: executions, color: "hsl(120, 30%, 35%)" },
          ].map((s) => (
            <div key={s.label} className="bg-card border border-border p-5">
              <p className="font-mono-sof text-muted-foreground mb-2 text-xs">{s.label}</p>
              <p className="font-display text-4xl" style={{ color: s.color }}>{s.value}</p>
            </div>
          ))}
        </div>

        {/* Declare new action */}
        <div className="bg-card border border-border p-6 mb-8">
          <p className="font-mono-sof text-muted-foreground mb-6">DECLARAR NUEVA ACCIÓN</p>
          <p className="text-sm text-muted-foreground mb-6 italic font-display">
            "Declara solo lo que realmente sabes que debes hacer.<br />
            La sombra registra todo."
          </p>
          <div className="space-y-4">
            <div>
              <label className="font-mono-sof text-muted-foreground text-xs block mb-2">¿QUÉ SABES QUE DEBES HACER?</label>
              <textarea
                value={newDesc}
                onChange={(e) => setNewDesc(e.target.value)}
                placeholder="Sé honesto. Nadie más leerá esto."
                rows={3}
                className="w-full bg-secondary border border-border text-foreground placeholder:text-muted-foreground/40 p-4 text-sm resize-none focus:outline-none focus:border-cherry/50 transition-colors duration-300"
              />
            </div>
            <div>
              <label className="font-mono-sof text-muted-foreground text-xs block mb-2">FECHA LÍMITE</label>
              <input
                type="date"
                value={newDate}
                onChange={(e) => setNewDate(e.target.value)}
                className="bg-secondary border border-border text-foreground p-3 text-sm focus:outline-none focus:border-cherry/50 transition-colors duration-300 font-mono-sof"
                style={{ colorScheme: "dark" }}
              />
            </div>
            <button
              onClick={addAction}
              disabled={!newDesc.trim() || !newDate || submitting}
              className="font-mono-sof text-sm px-8 py-3 border border-cherry text-cherry hover:bg-cherry hover:text-primary-foreground transition-all duration-500 tracking-widest disabled:opacity-30 disabled:cursor-not-allowed"
            >
              {submitting ? "REGISTRANDO..." : "DECLARAR"}
            </button>
          </div>
        </div>

        {/* Filter */}
        <div className="flex gap-2 mb-6 flex-wrap">
          {(["ALL", "PENDING", "EXECUTED", "OMITTED"] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`font-mono-sof px-4 py-1.5 border transition-all duration-300 text-xs ${
                filter === f
                  ? "border-cherry text-cherry"
                  : "border-border text-muted-foreground hover:border-foreground/30"
              }`}
            >
              {f === "ALL" ? "TODAS" : STATUS_LABELS[f]}
            </button>
          ))}
        </div>

        {/* Actions list */}
        <div className="space-y-0">
          {filtered.length === 0 && (
            <div className="border border-border p-12 text-center">
              <p className="font-display text-muted-foreground italic text-xl">
                Nada que mostrar. El vacío también dice algo.
              </p>
            </div>
          )}
          {filtered.map((action, i) => (
            <div
              key={action.id}
              className="border-b border-border py-5 flex items-start gap-4 group"
              style={{ borderTop: i === 0 ? "1px solid hsl(var(--border))" : undefined }}
            >
              <div
                className="w-2 h-2 rounded-full mt-2 flex-shrink-0 transition-colors duration-300"
                style={{ backgroundColor: STATUS_COLORS[action.status] }}
              />
              <div className="flex-1 min-w-0">
                <p
                  className="text-foreground mb-2 leading-relaxed"
                  style={{
                    opacity: action.status === "OMITTED" ? 0.45 : 1,
                    textDecoration: action.status === "OMITTED" ? "line-through" : "none",
                  }}
                >
                  {action.description}
                </p>
                <div className="flex items-center gap-4 flex-wrap">
                  <span className="font-mono-sof text-muted-foreground" style={{ fontSize: "0.6rem" }}>
                    DECLARADA {new Date(action.declared_at).toLocaleDateString("es-ES")}
                  </span>
                  <span className="font-mono-sof text-muted-foreground" style={{ fontSize: "0.6rem" }}>
                    LÍMITE {new Date(action.deadline).toLocaleDateString("es-ES")}
                  </span>
                  <span className="font-mono-sof" style={{ fontSize: "0.6rem", color: STATUS_COLORS[action.status] }}>
                    {STATUS_LABELS[action.status]}
                  </span>
                </div>
              </div>
              {action.status === "PENDING" && (
                <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex-shrink-0">
                  <button
                    onClick={() => updateStatus(action.id, "EXECUTED")}
                    className="font-mono-sof px-3 py-1 border border-border hover:border-foreground text-muted-foreground hover:text-foreground transition-all duration-300"
                    style={{ fontSize: "0.55rem" }}
                  >
                    EJECUTÉ
                  </button>
                  <button
                    onClick={() => updateStatus(action.id, "OMITTED")}
                    className="font-mono-sof px-3 py-1 border border-cherry/30 hover:border-cherry text-cherry/60 hover:text-cherry transition-all duration-300"
                    style={{ fontSize: "0.55rem" }}
                  >
                    OMITÍ
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Reflection */}
        {omissions > 0 && (
          <div className="mt-12 border-t border-border pt-8">
            <p className="font-display text-muted-foreground text-center italic text-lg">
              {omissions === 1
                ? "Una omisión. La sombra la registró."
                : `${omissions} omisiones. El patrón empieza a verse.`}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
