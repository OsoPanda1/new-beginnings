import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { useToast } from "@/hooks/use-toast";
import { Checkbox } from "@/components/ui/checkbox";

const CHECKBOXES = [
  {
    key: "age_18",
    label: "Declaro que tengo al menos 18 años de edad.",
  },
  {
    key: "no_clinical",
    label: "Comprendo que THE SOF no es un servicio de salud mental, no ofrece diagnóstico, tratamiento, terapia ni coaching, y no sustituye a profesionales.",
  },
  {
    key: "current_state",
    label: "Declaro que actualmente no me encuentro en crisis emocional ni en tratamiento psicológico o psiquiátrico que pudiera verse afectado por el uso de esta plataforma.",
  },
  {
    key: "voluntary_use",
    label: "Entiendo que el uso de THE SOF es voluntario, que puedo dejar de usarlo en cualquier momento y que soy responsable de cómo interpreto la información mostrada.",
  },
  {
    key: "data_automation",
    label: "Comprendo que THE SOF utiliza análisis automatizados descriptivos basados únicamente en datos que yo mismo declaro, sin generar decisiones legales ni efectos equivalentes sobre mí.",
  },
];

export default function Onboarding() {
  const [step, setStep] = useState(0);
  const [checks, setChecks] = useState<Record<string, boolean>>({
    age_18: false,
    no_clinical: false,
    current_state: false,
    voluntary_use: false,
    data_automation: false,
  });
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const allChecked = Object.values(checks).every(Boolean);

  const handleComplete = async () => {
    if (!user) return;
    setLoading(true);
    try {
      await supabase.from("legal_consents").insert({
        user_id: user.id,
        version: "v1.0",
        checkboxes: checks,
      });
      await supabase.from("profiles").update({
        legal_accepted_at: new Date().toISOString(),
        legal_version: "v1.0",
      }).eq("user_id", user.id);

      toast({ title: "Consentimiento registrado", description: "Bienvenido a THE SOF." });
      navigate("/dashboard");
    } catch {
      toast({ title: "Error", description: "No se pudo registrar.", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-6 py-12">
      <div className="w-full max-w-2xl">

        {/* Step 0: Warning */}
        {step === 0 && (
          <div className="bg-card border border-border p-8">
            <h1 className="font-display text-3xl text-foreground mb-8">Antes de entrar en THE SOF</h1>
            <div className="space-y-4 text-sm text-muted-foreground leading-relaxed max-h-[60vh] overflow-y-auto pr-2">
              <p>THE SOF (The Shadow of Failure) es una plataforma digital de auto-observación conductual diseñada exclusivamente para personas adultas (18+).</p>
              <p>THE SOF registra únicamente información que tú decides declarar voluntariamente (acciones, plazos, áreas de interés) y muestra representaciones descriptivas sobre si dichas acciones fueron ejecutadas u omitidas en el tiempo.</p>
              <p>THE SOF no es un servicio médico, psicológico, psiquiátrico, terapéutico ni de emergencia. No diagnostica, no trata, no aconseja, no motiva, no promete resultados ni garantiza mejoras personales, profesionales, económicas o de salud.</p>
              <p>La información mostrada por THE SOF tiene carácter informativo y reflexivo. Puede resultar incómoda o emocionalmente desafiante. El uso de la plataforma es completamente voluntario y puedes dejar de utilizarla en cualquier momento.</p>

              <div className="border-t border-border my-6" />
              <p className="text-cherry font-mono-sof text-xs">⚠️ USO NO PERMITIDO</p>
              <p>THE SOF no está diseñado para personas que:</p>
              <ul className="list-disc pl-6 space-y-1">
                <li>se encuentren en crisis emocional,</li>
                <li>presenten ideación suicida o conductas de autolesión,</li>
                <li>tengan trastornos mentales diagnosticados, o</li>
                <li>se encuentren actualmente en tratamiento psicológico o psiquiátrico.</li>
              </ul>
              <p>Si te encuentras en alguna de estas situaciones, no debes utilizar esta plataforma. Busca ayuda profesional o recursos de emergencia disponibles en tu país.</p>
            </div>

            <button
              onClick={() => setStep(1)}
              className="mt-8 w-full font-mono-sof text-sm px-8 py-3 border border-border text-foreground hover:border-cherry hover:text-cherry transition-all duration-500 tracking-widest"
            >
              HE LEÍDO Y COMPRENDO
            </button>
          </div>
        )}

        {/* Step 1: Checkboxes */}
        {step === 1 && (
          <div className="bg-card border border-border p-8">
            <h1 className="font-display text-3xl text-foreground mb-2">Confirmación de uso responsable</h1>
            <p className="font-mono-sof text-muted-foreground mb-8 text-xs">TODOS LOS CAMPOS SON OBLIGATORIOS</p>

            <div className="space-y-6">
              {CHECKBOXES.map((cb) => (
                <label key={cb.key} className="flex items-start gap-3 cursor-pointer group">
                  <Checkbox
                    checked={checks[cb.key]}
                    onCheckedChange={(v) => setChecks({ ...checks, [cb.key]: !!v })}
                    className="mt-0.5 border-border data-[state=checked]:bg-cherry data-[state=checked]:border-cherry"
                  />
                  <span className="text-sm text-muted-foreground group-hover:text-foreground transition-colors leading-relaxed">
                    {cb.label}
                  </span>
                </label>
              ))}
            </div>

            <button
              onClick={() => setStep(2)}
              disabled={!allChecked}
              className="mt-8 w-full font-mono-sof text-sm px-8 py-3 border border-cherry text-cherry hover:bg-cherry hover:text-primary-foreground transition-all duration-500 tracking-widest disabled:opacity-20 disabled:cursor-not-allowed"
            >
              CONFIRMAR
            </button>
          </div>
        )}

        {/* Step 2: Legal acceptance */}
        {step === 2 && (
          <div className="bg-card border border-border p-8">
            <h1 className="font-display text-3xl text-foreground mb-8">Aceptación legal</h1>

            <p className="text-sm text-muted-foreground mb-6 leading-relaxed">
              Al continuar, confirmo que he leído y acepto:
            </p>
            <ul className="list-disc pl-6 text-sm text-muted-foreground space-y-2 mb-8">
              <li>los <span className="text-foreground">Términos y Condiciones</span>,</li>
              <li>la <span className="text-foreground">Política de Privacidad</span>, y</li>
              <li>las <span className="text-foreground">Políticas de Uso Responsable</span> de THE SOF.</li>
            </ul>

            <label className="flex items-start gap-3 cursor-pointer group mb-8">
              <Checkbox
                checked={termsAccepted}
                onCheckedChange={(v) => setTermsAccepted(!!v)}
                className="mt-0.5 border-border data-[state=checked]:bg-cherry data-[state=checked]:border-cherry"
              />
              <span className="text-sm text-muted-foreground group-hover:text-foreground transition-colors">
                Acepto todos los documentos legales mencionados
              </span>
            </label>

            <div className="flex gap-4">
              <button
                onClick={handleComplete}
                disabled={!termsAccepted || loading}
                className="flex-1 font-mono-sof text-sm px-8 py-3 border border-cherry text-cherry hover:bg-cherry hover:text-primary-foreground transition-all duration-500 tracking-widest disabled:opacity-20 disabled:cursor-not-allowed"
              >
                {loading ? "REGISTRANDO..." : "ENTRAR AL SISTEMA"}
              </button>
              <button
                onClick={() => navigate("/")}
                className="font-mono-sof text-sm px-6 py-3 border border-border text-muted-foreground hover:text-foreground transition-all duration-300 tracking-widest"
              >
                SALIR
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
