import { ShadowAvatar, LEVEL_CONFIG } from "@/components/ShadowAvatar";
import type { ShadowLevel } from "@/lib/shadow-engine";

const MOCK_CIRCLE = [
  { alias: "el_postergado_3", level: -3 as ShadowLevel, trend: "descending" as const },
  { alias: "sombra_activa_7", level: -2 as ShadowLevel, trend: "stable" as const },
  { alias: "voidwalker", level: -5 as ShadowLevel, trend: "descending" as const },
  { alias: "el_susurrante", level: -1 as ShadowLevel, trend: "ascending" as const },
  { alias: "buried_deep", level: -4 as ShadowLevel, trend: "stable" as const },
  { alias: "observer_x", level: -3 as ShadowLevel, trend: "ascending" as const },
];

const TREND_SYMBOLS: Record<string, string> = {
  ascending: "↑",
  descending: "↓",
  stable: "—",
};

const TREND_COLORS: Record<string, string> = {
  ascending: "hsl(120, 25%, 35%)",
  descending: "hsl(0, 65%, 38%)",
  stable: "hsl(0, 0%, 45%)",
};

export default function Circle() {
  const sortedByLevel = [...MOCK_CIRCLE].sort((a, b) => a.level - b.level);

  return (
    <div className="min-h-screen bg-background pt-14">
      <div className="max-w-5xl mx-auto px-6 py-12">

        <div className="mb-16">
          <p className="font-mono-sof text-muted-foreground mb-2">SOF CIRCLE</p>
          <h1 className="font-display text-4xl md:text-5xl text-foreground">Comparación Ética</h1>
        </div>

        {/* Ethics notice */}
        <div className="bg-card border border-border p-6 mb-12 relative">
          <div className="absolute left-0 top-0 bottom-0 w-0.5 bg-muted-foreground/30" />
          <p className="font-mono-sof text-muted-foreground mb-3 pl-4">PRINCIPIO DE CÍRCULO</p>
          <p className="font-display text-xl text-foreground italic pl-4 mb-3">
            "No compitan. Obsérvense."
          </p>
          <div className="pl-4 flex flex-wrap gap-4 mt-4">
            {[
              "Sin rankings públicos",
              "Sin números exactos",
              "Solo tendencias anónimas",
              "Solo con consentimiento",
            ].map((rule) => (
              <span key={rule} className="font-mono-sof text-muted-foreground text-xs border border-border px-3 py-1">
                {rule}
              </span>
            ))}
          </div>
        </div>

        {/* Avatar grid */}
        <div className="mb-12">
          <p className="font-mono-sof text-muted-foreground mb-8">TU CÍRCULO PRIVADO</p>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-6">
            {sortedByLevel.map((member) => {
              const config = LEVEL_CONFIG[member.level];
              return (
                <div
                  key={member.alias}
                  className="flex flex-col items-center gap-3 group cursor-default"
                >
                  <div className="relative">
                    <ShadowAvatar level={member.level} size="sm" animated />
                    <span
                      className="absolute -top-1 -right-1 font-mono-sof text-xs"
                      style={{ color: TREND_COLORS[member.trend], fontSize: "0.8rem" }}
                    >
                      {TREND_SYMBOLS[member.trend]}
                    </span>
                  </div>
                  <div className="text-center">
                    <p className="font-mono-sof text-muted-foreground group-hover:text-foreground transition-colors duration-300" style={{ fontSize: "0.6rem" }}>
                      @{member.alias.slice(0, 8)}…
                    </p>
                    <p className="font-mono-sof text-cherry mt-0.5" style={{ fontSize: "0.55rem" }}>
                      {config.label.split(" ")[1]}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Level distribution */}
        <div className="bg-card border border-border p-6 mb-6">
          <p className="font-mono-sof text-muted-foreground mb-6">DISTRIBUCIÓN EN EL CÍRCULO</p>
          <div className="space-y-3">
            {([-1, -2, -3, -4, -5] as ShadowLevel[]).map((level) => {
              const count = MOCK_CIRCLE.filter((m) => m.level === level).length;
              const percent = (count / MOCK_CIRCLE.length) * 100;
              const config = LEVEL_CONFIG[level];
              return (
                <div key={level} className="flex items-center gap-4">
                  <span className="font-mono-sof text-muted-foreground w-4 text-right flex-shrink-0" style={{ fontSize: "0.6rem" }}>
                    {level}
                  </span>
                  <div className="flex-1 h-1 bg-secondary relative overflow-hidden">
                    <div
                      className="absolute left-0 top-0 bottom-0 transition-all duration-1000"
                      style={{
                        width: `${percent}%`,
                        backgroundColor: `hsl(0, ${20 + Math.abs(level) * 8}%, ${20 + Math.abs(level) * 3}%)`,
                      }}
                    />
                  </div>
                  <span className="font-mono-sof text-muted-foreground w-8 flex-shrink-0" style={{ fontSize: "0.6rem" }}>
                    {count}
                  </span>
                  <span className="font-mono-sof text-muted-foreground/50 hidden sm:block" style={{ fontSize: "0.55rem" }}>
                    {config.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Collective state */}
        <div className="bg-card border border-border p-6 text-center relative overflow-hidden">
          <div
            className="absolute inset-0 opacity-5"
            style={{ background: "var(--gradient-cherry-glow)" }}
          />
          <p className="font-mono-sof text-muted-foreground mb-4 relative z-10">ESTADO COLECTIVO</p>
          <p className="font-display text-5xl text-cherry mb-2 relative z-10">
            {(MOCK_CIRCLE.reduce((sum, m) => sum + m.level, 0) / MOCK_CIRCLE.length).toFixed(1)}
          </p>
          <p className="font-mono-sof text-muted-foreground relative z-10 text-xs mb-6">
            NIVEL PROMEDIO DEL CÍRCULO
          </p>
          <p className="font-display text-muted-foreground italic relative z-10">
            "Nadie está solo en la oscuridad."
          </p>
        </div>

        {/* Invite */}
        <div className="mt-6 border border-border p-6">
          <p className="font-mono-sof text-muted-foreground mb-4">INVITAR AL CÍRCULO</p>
          <p className="text-sm text-muted-foreground mb-6 font-display italic">
            Solo puedes invitar a quien confíes con tu sombra.<br />
            El consentimiento es obligatorio.
          </p>
          <div className="flex gap-3">
            <input
              type="text"
              placeholder="alias o email"
              className="flex-1 bg-secondary border border-border text-foreground placeholder:text-muted-foreground/40 px-4 py-2.5 text-sm focus:outline-none focus:border-cherry/50 transition-colors duration-300 font-sans"
            />
            <button className="font-mono-sof px-6 py-2.5 border border-border text-muted-foreground hover:border-cherry hover:text-cherry transition-all duration-300 text-xs tracking-widest">
              INVITAR
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
