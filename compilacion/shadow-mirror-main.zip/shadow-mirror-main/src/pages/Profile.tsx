import { useEffect, useState } from "react";
import { ShadowAvatar, LEVEL_CONFIG } from "@/components/ShadowAvatar";
import { mapAvatarState } from "@/lib/shadow-engine";
import type { ShadowLevel } from "@/lib/shadow-engine";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { Link } from "react-router-dom";

const AVATAR_STYLES = ["emo", "beetle", "shadow-doll", "void"] as const;

export default function Profile() {
  const { user, membership } = useAuth();
  const [profile, setProfile] = useState<any>(null);
  const [actionStats, setActionStats] = useState({ omissions: 0, executions: 0 });
  const [loading, setLoading] = useState(true);
  const [selectedStyle, setSelectedStyle] = useState<(typeof AVATAR_STYLES)[number]>("shadow-doll");

  useEffect(() => {
    if (!user) return;
    loadProfile();
  }, [user?.id]);

  const loadProfile = async () => {
    if (!user) return;
    setLoading(true);
    const [profileRes, actionsRes] = await Promise.all([
      supabase.from("profiles").select("*").eq("user_id", user.id).single(),
      supabase.from("actions").select("status").eq("user_id", user.id),
    ]);

    if (profileRes.data) {
      setProfile(profileRes.data);
      setSelectedStyle(profileRes.data.avatar_style || "shadow-doll");
    }
    if (actionsRes.data) {
      const actions = actionsRes.data as any[];
      setActionStats({
        omissions: actions.filter((a) => a.status === "OMITTED").length,
        executions: actions.filter((a) => a.status === "EXECUTED").length,
      });
    }
    setLoading(false);
  };

  const updateAvatar = async (style: (typeof AVATAR_STYLES)[number]) => {
    setSelectedStyle(style);
    if (user) {
      await supabase.from("profiles").update({ avatar_style: style }).eq("user_id", user.id);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background pt-14 flex items-center justify-center">
        <div className="text-center">
          <p className="font-display text-xl text-foreground mb-4">Debes entrar al sistema</p>
          <Link to="/auth" className="font-mono-sof text-cherry hover:underline">ENTRAR</Link>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background pt-14 flex items-center justify-center">
        <p className="font-mono-sof text-muted-foreground animate-pulse">CARGANDO PERFIL...</p>
      </div>
    );
  }

  const level = (profile?.current_level ?? -1) as ShadowLevel;
  const config = LEVEL_CONFIG[level];
  const daysSinceJoin = profile
    ? Math.floor((Date.now() - new Date(profile.created_at).getTime()) / (1000 * 60 * 60 * 24))
    : 0;

  return (
    <div className="min-h-screen bg-background pt-14">
      <div className="max-w-5xl mx-auto px-6 py-12">
        <div className="mb-16">
          <p className="font-mono-sof text-muted-foreground mb-2">IDENTIDAD</p>
          <h1 className="font-display text-4xl md:text-5xl text-foreground">Perfil de Sombra</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Avatar Panel */}
          <div className="lg:col-span-1 space-y-4">
            <div className="bg-card border border-border p-8 flex flex-col items-center gap-6 relative overflow-hidden">
              <div className="absolute inset-0 opacity-8" style={{ background: "var(--gradient-cherry-glow)" }} />
              <ShadowAvatar level={level} size="lg" animated />
              <div className="text-center relative z-10 w-full">
                <p className="font-display text-xl text-foreground mb-1">@{profile?.alias}</p>
                <p className="font-mono-sof text-cherry">{config.label}</p>
                <div className="w-12 h-px bg-border mx-auto my-4" />
                <p className="font-display text-5xl text-foreground">{level}</p>
                <p className="font-mono-sof text-muted-foreground text-xs mt-1">NIVEL ACTUAL</p>
              </div>
            </div>

            <div className="bg-card border border-cherry/20 p-5 relative">
              <div className="absolute left-0 top-0 bottom-0 w-0.5 bg-cherry opacity-40" />
              <p className="font-display text-sm italic text-foreground/70 leading-relaxed pl-2">
                "{config.phrase}"
              </p>
            </div>

            <div className="bg-secondary border border-border p-4 flex items-center justify-between">
              <span className="font-mono-sof text-muted-foreground">MEMBRESÍA</span>
              <span className="font-mono-sof text-foreground">{membership}</span>
            </div>
          </div>

          {/* Stats + Settings */}
          <div className="lg:col-span-2 space-y-6">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {[
                { label: "SHADOW SCORE", value: profile?.shadow_score ?? 0 },
                { label: "OMISIONES", value: actionStats.omissions },
                { label: "EJECUCIONES", value: actionStats.executions },
                { label: "DÍAS EN SOMBRA", value: profile?.consecutive_shadow_days ?? 0 },
                { label: "DÍAS EN SISTEMA", value: daysSinceJoin },
                { label: "AVATAR", value: mapAvatarState(level) },
              ].map((stat) => (
                <div key={stat.label} className="bg-card border border-border p-5">
                  <p className="font-mono-sof text-muted-foreground mb-2 text-xs">{stat.label}</p>
                  <p className="font-display text-2xl md:text-3xl text-foreground">{stat.value}</p>
                </div>
              ))}
            </div>

            {/* Avatar style selector */}
            <div className="bg-card border border-border p-6">
              <p className="font-mono-sof text-muted-foreground mb-6">ESTILO DE AVATAR</p>
              <div className="grid grid-cols-4 gap-3">
                {AVATAR_STYLES.map((style) => (
                  <button
                    key={style}
                    onClick={() => updateAvatar(style)}
                    className={`border p-4 flex flex-col items-center gap-2 transition-all duration-300 ${
                      selectedStyle === style
                        ? "border-cherry bg-cherry/10"
                        : "border-border hover:border-foreground/30"
                    }`}
                  >
                    <ShadowAvatar level={level} size="sm" animated={false} />
                    <span className="font-mono-sof text-muted-foreground" style={{ fontSize: "0.55rem" }}>
                      {style.toUpperCase()}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Upgrade teaser */}
            {membership === "FREE" && (
              <div className="bg-card border border-cherry/20 p-6 relative overflow-hidden">
                <div className="absolute right-0 top-0 bottom-0 w-1 bg-gradient-to-b from-cherry/60 to-transparent" />
                <p className="font-mono-sof text-cherry mb-3">PREMIUM — $9.99</p>
                <p className="font-display text-lg text-foreground mb-2">
                  Desbloquea el perfil completo de sombra
                </p>
                <p className="text-sm text-muted-foreground mb-4">
                  Tendencias · Patrones de omisión · Comparación anónima · Proyección si sigues igual
                </p>
                <Link
                  to="/memberships"
                  className="font-mono-sof text-foreground border border-border px-6 py-2 hover:border-cherry hover:text-cherry transition-all duration-300 text-xs tracking-widest inline-block"
                >
                  VER PLANES
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
