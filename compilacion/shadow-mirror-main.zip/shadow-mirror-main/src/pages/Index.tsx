import { useState } from "react";
import heroImage from "@/assets/hero-shadow.jpg";
import { Link } from "react-router-dom";
import { ShadowAvatar } from "@/components/ShadowAvatar";
import { CinematicIntro } from "@/components/CinematicIntro";
import { useSoundEffects } from "@/lib/sound-effects";

const PRINCIPLES = [
  "El fracaso no es fallar.",
  "Es postergar lo que sabes que debes hacer.",
  "THE SOF no te motiva.",
  "THE SOF te muestra lo que evitas.",
];

const LEVELS_PREVIEW = [
  { level: -1 as const, label: "-1" },
  { level: -2 as const, label: "-2" },
  { level: -3 as const, label: "-3" },
  { level: -4 as const, label: "-4" },
  { level: -5 as const, label: "-5" },
];

const Index = () => {
  const [introSeen, setIntroSeen] = useState(() => {
    return sessionStorage.getItem("sof-intro-seen") === "true";
  });
  const soundEffects = useSoundEffects();

  const handleIntroComplete = () => {
    sessionStorage.setItem("sof-intro-seen", "true");
    setIntroSeen(true);
  };

  const handleButtonClick = () => {
    soundEffects.click();
  };

  const handleButtonHover = () => {
    soundEffects.hover();
  };

  if (!introSeen) {
    return <CinematicIntro onComplete={handleIntroComplete} />;
  }

  return (
    <div className="min-h-screen bg-background">

      {/* HERO */}
      <section className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden scanlines">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${heroImage})`, opacity: 0.45 }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-transparent to-background" />
        <div className="absolute inset-0 bg-gradient-to-r from-background/40 via-transparent to-background/40" />

        <div className="relative z-10 text-center px-6 max-w-4xl mx-auto">
          <p className="font-mono-sof text-muted-foreground mb-8 animate-appear">
            SISTEMA DIGITAL DE AUTOCONFRONTACIÓN
          </p>
          <h1 className="font-display text-6xl md:text-8xl lg:text-9xl text-foreground mb-6 animate-appear delay-200 leading-none tracking-tight">
            THE SOF
          </h1>
          <p className="font-display text-xl md:text-2xl text-muted-foreground italic mb-12 animate-appear delay-400">
            The Shadow of Failure
          </p>

          <div className="w-16 h-px bg-cherry mx-auto mb-12 animate-appear delay-600" />

          <p className="text-lg md:text-xl text-foreground/70 max-w-xl mx-auto mb-16 leading-relaxed animate-appear delay-800">
            No es coaching. No es terapia.<br />
            La sombra no se corrige: <span className="text-foreground">se observa.</span>
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center animate-appear delay-1000">
            <Link
              to="/dashboard"
              onClick={handleButtonClick}
              onMouseEnter={handleButtonHover}
              className="group px-8 py-3 border border-cherry text-cherry font-mono-sof hover:bg-cherry hover:text-primary-foreground transition-all duration-500 tracking-widest glow-cherry hover:glow-cherry"
            >
              VER MI SOMBRA
            </Link>
            <Link
              to="/auth"
              onClick={handleButtonClick}
              onMouseEnter={handleButtonHover}
              className="px-8 py-3 border border-border text-muted-foreground font-mono-sof hover:border-foreground hover:text-foreground transition-all duration-500 tracking-widest"
            >
              CREAR PERFIL
            </Link>
          </div>
        </div>

        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-drift opacity-40">
          <div className="w-px h-12 bg-gradient-to-b from-transparent to-cherry mx-auto" />
        </div>
      </section>

      {/* PRINCIPIOS */}
      <section className="py-32 px-6 max-w-4xl mx-auto">
        <p className="font-mono-sof text-muted-foreground mb-16 text-center">PRINCIPIOS RECTORES</p>
        <div className="space-y-0">
          {PRINCIPLES.map((p, i) => (
            <div key={i} className="border-t border-border py-8 flex items-center gap-6 group">
              <span className="font-mono-sof text-muted-foreground/40 w-8 flex-shrink-0">
                {String(i + 1).padStart(2, "0")}
              </span>
              <p className="font-display text-2xl md:text-3xl text-foreground/80 group-hover:text-foreground transition-colors duration-500">
                {p}
              </p>
            </div>
          ))}
          <div className="border-t border-border" />
        </div>
      </section>

      {/* NIVELES */}
      <section className="py-24 px-6 bg-secondary/30">
        <div className="max-w-5xl mx-auto">
          <p className="font-mono-sof text-muted-foreground mb-4 text-center">LOS CINCO NIVELES</p>
          <p className="font-display text-3xl md:text-4xl text-foreground text-center mb-16">
            ¿Qué tan oscuro eres?
          </p>
          <div className="grid grid-cols-5 gap-4 md:gap-8">
            {LEVELS_PREVIEW.map(({ level, label }, i) => (
              <div key={level} className="flex flex-col items-center gap-4 group" style={{ animationDelay: `${i * 0.2}s` }}>
                <ShadowAvatar level={level} size="sm" animated />
                <span className="font-mono-sof text-muted-foreground group-hover:text-cherry transition-colors duration-500">{label}</span>
              </div>
            ))}
          </div>
          <p className="text-center text-muted-foreground text-sm mt-12 italic font-display">"No compitan. Obsérvense."</p>
        </div>
      </section>

      {/* CTA FINAL */}
      <section className="py-40 px-6 text-center relative overflow-hidden">
        <div className="absolute inset-0 opacity-20" style={{ background: "var(--gradient-cherry-glow)" }} />
        <div className="relative z-10 max-w-2xl mx-auto">
          <p className="font-mono-sof text-muted-foreground mb-8">COMIENZA AHORA</p>
          <h2 className="font-display text-4xl md:text-6xl text-foreground mb-8 leading-tight">
            Tu sombra ya existe.<br />
            <span className="text-cherry">¿La ves o la evitas?</span>
          </h2>
          <Link
            to="/dashboard"
            className="inline-block px-12 py-4 bg-cherry text-primary-foreground font-mono-sof hover:bg-accent transition-all duration-500 tracking-widest glow-cherry"
          >
            ENTRAR AL SISTEMA
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 px-6">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
          <span className="font-mono-sof text-muted-foreground">THE SOF · THE SHADOW OF FAILURE</span>
          <div className="flex items-center gap-8">
            <span className="font-mono-sof text-muted-foreground/50">NO ES COACHING</span>
            <span className="font-mono-sof text-muted-foreground/50">NO ES TERAPIA</span>
            <span className="font-mono-sof text-muted-foreground/50">NO HAY RANKINGS</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
