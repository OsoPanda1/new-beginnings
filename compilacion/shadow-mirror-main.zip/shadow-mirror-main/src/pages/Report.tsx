import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { ShadowAvatar, LEVEL_CONFIG } from "@/components/ShadowAvatar";
import { mapAvatarState } from "@/lib/shadow-engine";
import type { ShadowLevel } from "@/lib/shadow-engine";
import { Link } from "react-router-dom";

interface ProfileData {
  alias: string;
  current_level: number;
  total_delta_s: number;
  shadow_score: number;
  consecutive_shadow_days: number;
  membership: string;
  created_at: string;
}

interface ActionStats {
  total: number;
  executed: number;
  omitted: number;
  pending: number;
}

interface MetricEntry {
  date: string;
  level: number;
  total_delta_s: number;
  engine_state: string;
  executed_count: number;
  omitted_count: number;
}

export default function Report() {
  const { user, membership } = useAuth();
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [actionStats, setActionStats] = useState<ActionStats>({ total: 0, executed: 0, omitted: 0, pending: 0 });
  const [metrics, setMetrics] = useState<MetricEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    loadData();
  }, [user?.id]);

  const loadData = async () => {
    if (!user) return;
    setLoading(true);

    const [profileRes, actionsRes, metricsRes] = await Promise.all([
      supabase.from("profiles").select("*").eq("user_id", user.id).single(),
      supabase.from("actions").select("status").eq("user_id", user.id),
      supabase.from("shadow_metrics").select("*").eq("user_id", user.id).order("date", { ascending: false }).limit(30),
    ]);

    if (profileRes.data) setProfile(profileRes.data as any);

    if (actionsRes.data) {
      const actions = actionsRes.data as any[];
      setActionStats({
        total: actions.length,
        executed: actions.filter((a) => a.status === "EXECUTED").length,
        omitted: actions.filter((a) => a.status === "OMITTED").length,
        pending: actions.filter((a) => a.status === "PENDING").length,
      });
    }

    if (metricsRes.data) setMetrics(metricsRes.data as any[]);
    setLoading(false);
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background pt-14 flex items-center justify-center">
        <div className="text-center">
          <p className="font-display text-xl text-foreground mb-4">Debes entrar al sistema</p>
          <Link to="/auth" className="font-mono-sof text-cherry hover:underline">ENTRAR</Link>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background pt-14 flex items-center justify-center">
        <p className="font-mono-sof text-muted-foreground animate-pulse">CARGANDO REPORTE...</p>
      </div>
    );
  }

  const level = (profile?.current_level ?? -1) as ShadowLevel;
  const config = LEVEL_CONFIG[level];
  const daysSinceJoin = profile ? Math.floor((Date.now() - new Date(profile.created_at).getTime()) / (1000 * 60 * 60 * 24)) : 0;
  const omissionRate = actionStats.total > 0 ? Math.round((actionStats.omitted / actionStats.total) * 100) : 0;

  return (
    <div className="min-h-screen bg-background pt-14">
      <div className="max-w-4xl mx-auto px-6 py-12">

        {/* Header */}
        <div className="mb-16 text-center">
          <p className="font-mono-sof text-muted-foreground mb-2">REPORTE FINAL</p>
          <h1 className="font-display text-4xl md:text-5xl text-foreground">THE SOF</h1>
          <p className="font-display text-lg text-muted-foreground mt-2 italic">Avance real del sistema</p>
          <div className="w-16 h-px bg-cherry mx-auto mt-6" />
        </div>

        {/* Identity Card */}
        <div className="bg-card border border-border p-8 mb-8 flex flex-col md:flex-row items-center gap-8">
          <ShadowAvatar level={level} size="lg" animated />
          <div className="text-center md:text-left flex-1">
            <p className="font-display text-2xl text-foreground">@{profile?.alias}</p>
            <p className="font-mono-sof text-cherry mt-1">{config?.label}</p>
            <p className="font-mono-sof text-muted-foreground text-xs mt-2">
              MEMBRESÍA: {profile?.membership} · {daysSinceJoin} días en el sistema
            </p>
          </div>
          <div className="text-center">
            <p className="font-display text-6xl text-foreground">{level}</p>
            <p className="font-mono-sof text-muted-foreground text-xs mt-1">NIVEL</p>
          </div>
        </div>

        {/* Core Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: "ΔS TOTAL", value: profile?.total_delta_s ?? 0 },
            { label: "SHADOW SCORE", value: profile?.shadow_score ?? 0 },
            { label: "DÍAS EN SOMBRA", value: profile?.consecutive_shadow_days ?? 0 },
            { label: "AVATAR", value: mapAvatarState(level) },
          ].map((s) => (
            <div key={s.label} className="bg-card border border-border p-5">
              <p className="font-mono-sof text-muted-foreground mb-2 text-xs">{s.label}</p>
              <p className="font-display text-2xl text-foreground">{s.value}</p>
            </div>
          ))}
        </div>

        {/* Actions Summary */}
        <div className="bg-card border border-border p-6 mb-8">
          <p className="font-mono-sof text-muted-foreground mb-6">RESUMEN DE ACCIONES</p>
          <div className="grid grid-cols-4 gap-4">
            {[
              { label: "TOTAL", value: actionStats.total },
              { label: "EJECUTADAS", value: actionStats.executed, color: "hsl(120, 30%, 35%)" },
              { label: "OMITIDAS", value: actionStats.omitted, color: "hsl(var(--cherry))" },
              { label: "PENDIENTES", value: actionStats.pending },
            ].map((s) => (
              <div key={s.label} className="text-center">
                <p className="font-display text-3xl" style={{ color: s.color }}>{s.value}</p>
                <p className="font-mono-sof text-muted-foreground text-xs mt-1">{s.label}</p>
              </div>
            ))}
          </div>
          <div className="mt-6 border-t border-border pt-4">
            <p className="font-mono-sof text-muted-foreground text-xs">
              TASA DE OMISIÓN: <span className="text-cherry">{omissionRate}%</span>
            </p>
          </div>
        </div>

        {/* System phrase */}
        <div className="bg-card border border-cherry/20 p-6 mb-8 relative">
          <div className="absolute left-0 top-0 bottom-0 w-0.5 bg-cherry opacity-40" />
          <p className="font-mono-sof text-cherry mb-3 text-xs">EL SISTEMA REGISTRA</p>
          <p className="font-display text-lg text-foreground italic pl-2">
            "{config?.phrase}"
          </p>
        </div>

        {/* PREMIUM+ Content */}
        {(membership === "PREMIUM" || membership === "VIP") && metrics.length > 0 && (
          <div className="bg-card border border-border p-6 mb-8">
            <p className="font-mono-sof text-muted-foreground mb-6">TENDENCIA DE SOMBRA (ÚLTIMOS 7 DÍAS)</p>
            <div className="flex items-end gap-2 h-28">
              {metrics.slice(0, 7).reverse().map((m, i) => {
                const height = Math.min(100, Math.max(10, (Math.abs(m.level) / 5) * 100));
                return (
                  <div key={i} className="flex-1 flex flex-col items-center gap-2 group">
                    <div
                      className="w-full rounded-t-sm transition-all duration-1000 ease-out group-hover:opacity-80"
                      style={{
                        height: `${height}%`,
                        background: `hsl(0, ${20 + Math.abs(m.level) * 10}%, ${15 + Math.abs(m.level) * 4}%)`,
                        minHeight: 8,
                        boxShadow: `0 0 ${Math.abs(m.level) * 2}px hsl(0, ${20 + Math.abs(m.level) * 10}%, ${15 + Math.abs(m.level) * 4}%)`,
                      }}
                    />
                    <span className="font-mono-sof text-muted-foreground" style={{ fontSize: "0.6rem" }}>
                      {m.level}
                    </span>
                  </div>
                );
              })}
            </div>
            <div className="flex justify-between mt-4">
              {["L", "M", "X", "J", "V", "S", "D"].slice(0, Math.min(metrics.length, 7)).map((d, i) => (
                <span key={i} className="font-mono-sof text-muted-foreground flex-1 text-center" style={{ fontSize: "0.6rem" }}>{d}</span>
              ))}
            </div>
          </div>
        )}

        {/* VIP: Projection */}
        {membership === "VIP" && (
          <div className="bg-card border border-cherry/30 p-6 mb-8">
            <p className="font-mono-sof text-cherry mb-3 text-xs">PROYECCIÓN · SOLO VIP</p>
            <p className="font-display text-lg text-foreground mb-2">Si sigues igual</p>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Con una tasa de omisión del {omissionRate}% y {profile?.consecutive_shadow_days ?? 0} días consecutivos
              en sombra, el sistema proyecta que alcanzarás el nivel {Math.max(-5, level - 1)} en aproximadamente{" "}
              {Math.max(3, 14 - (profile?.consecutive_shadow_days ?? 0))} días si el patrón actual se mantiene.
            </p>
            <p className="text-sm text-muted-foreground mt-3 italic">
              Esto no es una predicción. Es un cálculo basado en datos que tú mismo declaraste.
            </p>
          </div>
        )}

        {/* Locked content for FREE */}
        {membership === "FREE" && (
          <div className="bg-card border border-border p-8 text-center">
            <p className="font-mono-sof text-muted-foreground mb-4">CONTENIDO BLOQUEADO</p>
            <p className="font-display text-xl text-foreground mb-2">
              Tendencias · Patrones · Proyección
            </p>
            <p className="text-sm text-muted-foreground mb-6">
              Disponible en PREMIUM ($9.99) y VIP ($19.99)
            </p>
            <Link
              to="/memberships"
              className="inline-block font-mono-sof text-sm px-8 py-3 border border-cherry text-cherry hover:bg-cherry hover:text-primary-foreground transition-all duration-500 tracking-widest"
            >
              VER PLANES
            </Link>
          </div>
        )}

        {/* Footer note */}
        <div className="mt-12 text-center">
          <p className="font-mono-sof text-muted-foreground text-xs">
            THE SOF no te juzga. No te diagnostica. No te promete nada.
          </p>
          <p className="font-mono-sof text-muted-foreground text-xs mt-1">
            Solo registra lo que declaraste y te muestra el patrón.
          </p>
        </div>
      </div>
    </div>
  );
}
