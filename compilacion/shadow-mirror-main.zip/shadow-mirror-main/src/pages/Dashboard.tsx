import { useState, useEffect } from "react";
import { ShadowAvatar, LEVEL_CONFIG } from "@/components/ShadowAvatar";
import { getShadowPhrase, getAlertMessage } from "@/lib/shadow-engine";
import type { ShadowLevel } from "@/lib/shadow-engine";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { Link } from "react-router-dom";

interface DashboardData {
  level: ShadowLevel;
  omissions: number;
  executions: number;
  deltaS: number;
  consecutiveShadowDays: number;
  trend: "ascending" | "descending" | "stable";
}

export default function Dashboard() {
  const { user } = useAuth();
  const [state, setState] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [dismissed, setDismissed] = useState<string[]>([]);
  const [weeklyLevels, setWeeklyLevels] = useState<number[]>([]);
  const [recentActions, setRecentActions] = useState<any[]>([]);

  useEffect(() => {
    if (!user) { setLoading(false); return; }
    loadDashboard();
  }, [user?.id]);

  const loadDashboard = async () => {
    if (!user) return;
    setLoading(true);

    const [profileRes, actionsRes, metricsRes] = await Promise.all([
      supabase.from("profiles").select("*").eq("user_id", user.id).single(),
      supabase.from("actions").select("*").eq("user_id", user.id).order("created_at", { ascending: false }).limit(4),
      supabase.from("shadow_metrics").select("level, date, total_delta_s").eq("user_id", user.id).order("date", { ascending: false }).limit(7),
    ]);

    // Get action counts
    const [execRes, omitRes] = await Promise.all([
      supabase.from("actions").select("id", { count: "exact", head: true }).eq("user_id", user.id).eq("status", "EXECUTED"),
      supabase.from("actions").select("id", { count: "exact", head: true }).eq("user_id", user.id).eq("status", "OMITTED"),
    ]);

    const profile = profileRes.data;
    const executions = execRes.count ?? 0;
    const omissions = omitRes.count ?? 0;

    const levels = (metricsRes.data ?? []).map((m: any) => m.level).reverse();
    setWeeklyLevels(levels.length > 0 ? levels : [-1]);
    setRecentActions(actionsRes.data ?? []);

    // Determine trend from metrics
    let trend: "ascending" | "descending" | "stable" = "stable";
    if (levels.length >= 2) {
      const last = levels[levels.length - 1];
      const prev = levels[levels.length - 2];
      if (last < prev) trend = "descending";
      else if (last > prev) trend = "ascending";
    }

    setState({
      level: (profile?.current_level ?? -1) as ShadowLevel,
      omissions,
      executions,
      deltaS: profile?.total_delta_s ?? 0,
      consecutiveShadowDays: profile?.consecutive_shadow_days ?? 0,
      trend,
    });
    setLoading(false);
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background pt-14 flex items-center justify-center">
        <div className="text-center">
          <p className="font-display text-xl text-foreground mb-4">Debes entrar al sistema</p>
          <Link to="/auth" className="font-mono-sof text-cherry hover:underline">ENTRAR</Link>
        </div>
      </div>
    );
  }

  if (loading || !state) {
    return (
      <div className="min-h-screen bg-background pt-14 flex items-center justify-center">
        <p className="font-mono-sof text-muted-foreground animate-pulse">CARGANDO SOMBRA...</p>
      </div>
    );
  }

  const config = LEVEL_CONFIG[state.level];
  const phrase = getShadowPhrase(state.level, state.trend);

  const alerts = [
    ...(state.omissions > 0 ? [{ id: "1", type: "omission" as const, message: getAlertMessage("omission"), time: "reciente" }] : []),
    ...(state.consecutiveShadowDays >= 3 ? [{ id: "2", type: "silence" as const, message: getAlertMessage("silence"), time: `${state.consecutiveShadowDays} días` }] : []),
    ...(state.level <= -3 ? [{ id: "3", type: "fall" as const, message: getAlertMessage("fall"), time: "nivel actual" }] : []),
  ];
  const visibleAlerts = alerts.filter((a) => !dismissed.includes(a.id));

  return (
    <div className="min-h-screen bg-background pt-14">
      <div className="max-w-6xl mx-auto px-6 py-12">
        <div className="mb-16">
          <p className="font-mono-sof text-muted-foreground mb-2">ESTADO ACTUAL</p>
          <h1 className="font-display text-4xl md:text-5xl text-foreground">Dashboard de Sombra</h1>
        </div>

        {/* Main grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Avatar + Level */}
          <div className="lg:col-span-1 bg-card border border-border p-8 flex flex-col items-center justify-center gap-6 relative overflow-hidden">
            <div className="absolute inset-0 opacity-10" style={{ background: "var(--gradient-cherry-glow)" }} />
            <ShadowAvatar level={state.level} size="xl" animated />
            <div className="text-center relative z-10">
              <p className="font-mono-sof text-muted-foreground mb-1">NIVEL ACTUAL</p>
              <p className="font-display text-6xl text-cherry mb-2">{state.level}</p>
              <p className="font-mono-sof text-foreground">{config.label}</p>
            </div>
          </div>

          {/* Metrics */}
          <div className="lg:col-span-2 grid grid-cols-2 gap-6">
            {[
              { label: "OMISIONES", value: state.omissions, sub: "acciones no ejecutadas" },
              { label: "EJECUCIONES", value: state.executions, sub: "acciones cumplidas" },
              { label: "DELTA S", value: `+${state.deltaS}`, sub: "diferencia sombra/real" },
              { label: "DÍAS EN SOMBRA", value: state.consecutiveShadowDays, sub: "consecutivos sin acción" },
            ].map((m) => (
              <div key={m.label} className="bg-card border border-border p-6">
                <p className="font-mono-sof text-muted-foreground mb-3">{m.label}</p>
                <p className="font-display text-4xl md:text-5xl text-foreground mb-2">{m.value}</p>
                <p className="text-xs text-muted-foreground">{m.sub}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Phrase */}
        <div className="bg-card border border-cherry/30 p-8 mb-8 relative overflow-hidden animate-pulse-cherry">
          <div className="absolute left-0 top-0 bottom-0 w-0.5 bg-cherry" />
          <p className="font-mono-sof text-cherry mb-3">EL SISTEMA DICE</p>
          <p className="font-display text-xl md:text-2xl text-foreground italic leading-relaxed">"{phrase}"</p>
        </div>

        {/* Two columns: Actions + Alerts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Recent Actions */}
          <div className="bg-card border border-border p-6">
            <div className="flex items-center justify-between mb-6">
              <p className="font-mono-sof text-muted-foreground">ACCIONES RECIENTES</p>
              <Link to="/actions" className="font-mono-sof text-cherry hover:text-foreground transition-colors text-xs">VER TODAS →</Link>
            </div>
            <div className="space-y-3">
              {recentActions.length === 0 ? (
                <p className="font-display text-muted-foreground italic">No hay acciones declaradas.</p>
              ) : recentActions.map((action: any) => (
                <div key={action.id} className="flex items-start gap-3 py-3 border-b border-border last:border-0">
                  <span
                    className="w-2 h-2 rounded-full mt-1.5 flex-shrink-0"
                    style={{
                      backgroundColor:
                        action.status === "EXECUTED" ? "hsl(120, 30%, 35%)"
                        : action.status === "OMITTED" ? "hsl(0, 65%, 38%)"
                        : "hsl(0, 0%, 35%)",
                    }}
                  />
                  <div className="flex-1 min-w-0">
                    <p
                      className="text-sm text-foreground leading-snug truncate"
                      style={{
                        opacity: action.status === "OMITTED" ? 0.5 : 1,
                        textDecoration: action.status === "OMITTED" ? "line-through" : "none",
                      }}
                    >
                      {action.description}
                    </p>
                    <p className="font-mono-sof text-muted-foreground mt-1" style={{ fontSize: "0.6rem" }}>{action.status}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Alerts */}
          <div className="bg-card border border-border p-6">
            <p className="font-mono-sof text-muted-foreground mb-6">ALERTAS DE SOMBRA</p>
            {visibleAlerts.length === 0 ? (
              <div className="flex items-center justify-center h-32">
                <p className="font-display text-muted-foreground italic text-lg">Silencio total.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {visibleAlerts.map((alert) => (
                  <div key={alert.id} className="bg-secondary border border-border p-4 relative group">
                    <div className="absolute left-0 top-0 bottom-0 w-0.5 bg-cherry opacity-60" />
                    <p className="text-sm text-foreground mb-2 pl-2">{alert.message}</p>
                    <div className="flex items-center justify-between pl-2">
                      <span className="font-mono-sof text-muted-foreground" style={{ fontSize: "0.6rem" }}>{alert.time}</span>
                      <button
                        onClick={() => setDismissed((d) => [...d, alert.id])}
                        className="font-mono-sof text-muted-foreground hover:text-foreground transition-colors"
                        style={{ fontSize: "0.6rem" }}
                      >
                        OBSERVADO
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Trend Bar */}
        <div className="mt-6 bg-card border border-border p-6">
          <p className="font-mono-sof text-muted-foreground mb-6">TENDENCIA SEMANAL</p>
          <div className="flex items-end gap-2 h-24">
            {(weeklyLevels.length > 0 ? weeklyLevels : [-1]).map((level, i) => {
              const height = ((Math.abs(level) / 5) * 100);
              return (
                <div key={i} className="flex-1 flex flex-col items-center gap-2 group">
                  <div
                    className="w-full rounded-t-sm transition-all duration-1000 ease-out group-hover:opacity-80"
                    style={{
                      height: `${height}%`,
                      background: `hsl(0, ${20 + Math.abs(level) * 10}%, ${15 + Math.abs(level) * 4}%)`,
                      minHeight: 8,
                      boxShadow: `0 0 ${Math.abs(level) * 2}px hsl(0, ${20 + Math.abs(level) * 10}%, ${15 + Math.abs(level) * 4}%)`,
                    }}
                  />
                  <span className="font-mono-sof text-muted-foreground" style={{ fontSize: "0.6rem" }}>{level}</span>
                </div>
              );
            })}
          </div>
          <div className="flex justify-between mt-4">
            {["L", "M", "X", "J", "V", "S", "D"].slice(0, Math.max(weeklyLevels.length, 1)).map((d, i) => (
              <span key={i} className="font-mono-sof text-muted-foreground flex-1 text-center" style={{ fontSize: "0.6rem" }}>{d}</span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
