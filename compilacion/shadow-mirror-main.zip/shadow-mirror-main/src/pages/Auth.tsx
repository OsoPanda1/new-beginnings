import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/auth-context";
import { useToast } from "@/hooks/use-toast";

export default function Auth() {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [alias, setAlias] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();

  if (user) {
    navigate("/dashboard");
    return null;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (mode === "register") {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: { alias: alias || email.split("@")[0] },
            emailRedirectTo: window.location.origin,
          },
        });
        if (error) throw error;
        toast({ title: "Cuenta creada", description: "Bienvenido al sistema." });
        navigate("/onboarding");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        navigate("/dashboard");
      }
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-6">
      <div className="w-full max-w-md">
        <div className="text-center mb-12">
          <p className="font-mono-sof text-muted-foreground mb-4">THE SOF</p>
          <h1 className="font-display text-4xl text-foreground">
            {mode === "login" ? "Entrar al Sistema" : "Registro"}
          </h1>
        </div>

        <form onSubmit={handleSubmit} className="bg-card border border-border p-8 space-y-6">
          {mode === "register" && (
            <div>
              <label className="font-mono-sof text-muted-foreground text-xs block mb-2">ALIAS</label>
              <input
                type="text"
                value={alias}
                onChange={(e) => setAlias(e.target.value)}
                placeholder="tu_alias_de_sombra"
                className="w-full bg-secondary border border-border text-foreground p-3 text-sm focus:outline-none focus:border-cherry/50 transition-colors"
              />
            </div>
          )}

          <div>
            <label className="font-mono-sof text-muted-foreground text-xs block mb-2">EMAIL</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-secondary border border-border text-foreground p-3 text-sm focus:outline-none focus:border-cherry/50 transition-colors"
            />
          </div>

          <div>
            <label className="font-mono-sof text-muted-foreground text-xs block mb-2">CONTRASEÑA</label>
            <input
              type="password"
              required
              minLength={6}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-secondary border border-border text-foreground p-3 text-sm focus:outline-none focus:border-cherry/50 transition-colors"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full font-mono-sof text-sm px-8 py-3 border border-cherry text-cherry hover:bg-cherry hover:text-primary-foreground transition-all duration-500 tracking-widest disabled:opacity-30"
          >
            {loading ? "..." : mode === "login" ? "ENTRAR" : "CREAR CUENTA"}
          </button>

          <button
            type="button"
            onClick={() => setMode(mode === "login" ? "register" : "login")}
            className="w-full font-mono-sof text-xs text-muted-foreground hover:text-foreground transition-colors text-center"
          >
            {mode === "login" ? "¿No tienes cuenta? Regístrate" : "¿Ya tienes cuenta? Entra"}
          </button>
        </form>
      </div>
    </div>
  );
}
