import { Helmet } from 'react-helmet';
import Navigation from '@/components/Navigation';
import HeroSection from '@/components/HeroSection';
import DocumentationSection from '@/components/DocumentationSection';
import PlatformSection from '@/components/PlatformSection';

const Index = () => {
  return (
    <>
      <Helmet>
        <title>TAMV MD-X4™ - Nación Digital Soberana | Ecosistema Tecnológico Avanzado</title>
        <meta 
          name="description" 
          content="La primera nación-estado digital completamente soberana del mundo. Ecosistema tecnológico revolucionario con IA soberana, blockchain nativo y seguridad cuántica para redefinir la gobernanza digital." 
        />
        <meta name="keywords" content="nación digital, TAMV, MD-X4, soberanía digital, blockchain, IA soberana, seguridad cuántica, gobernanza digital, tokenomics, criptografía post-cuántica" />
        <meta name="author" content="TAMV MD-X4™" />
        <meta property="og:title" content="TAMV MD-X4™ - Nación Digital Soberana" />
        <meta property="og:description" content="La primera nación-estado digital completamente soberana. Infraestructura tecnológica avanzada para la gobernanza del futuro." />
        <meta property="og:type" content="website" />
        <link rel="canonical" href="https://tamv.lovable.app" />
      </Helmet>
      
      <div className="min-h-screen bg-background">
        <Navigation />
        <main className="pt-20">
          <HeroSection />
          <DocumentationSection />
          <PlatformSection />
        </main>
      </div>
    </>
  );
};

export default Index;
