import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

interface CNOptions {
  mode?: "default" | "zen" | "tech" | "futuristic" | "immersive";
  accessibilityLevel?: "standard" | "highContrast" | "reducedMotion";
  contextFilters?: (className: string) => boolean;
  performanceHints?: boolean; // hints for performance tuning
}

/**
 * cn - Función avanzada de combinación y filtrado inteligente de clases CSS para Tailwind,
 * optimizada para ecosistemas híbridos cuántico/clásico con enfoque en latencia baja,
 * fluidez visual, experiencia inmersiva sensorial y accesibilidad máxima.
 */
export function cn(...inputs: ClassValue[]): string {
  // Extraer última opción si es CNOptions
  let options: CNOptions = {};
  if (inputs.length && typeof inputs[inputs.length - 1] === "object" && !Array.isArray(inputs[inputs.length - 1])) {
    const last = inputs.pop();
    if (last) options = last as CNOptions;
  }

  let classes = clsx(inputs);

  // Aplicar filtrado contextual para evitar clases visualmente contradictorias o pesadas
  if (options.contextFilters) {
    classes = classes
      .split(/\s+/)
      .filter((cls) => options.contextFilters!(cls))
      .join(" ");
  }

  // Aplicar modo visual adaptativo con transformaciones semánticas ricas
  switch (options.mode) {
    case "zen":
      // Modo zen: máximo relajamiento visual, menos brillo y animaciones, contraste medio
      classes = classes.replace(/\b(bg-(primary|secondary|accent)(\/\d{2})?)\b/g, "bg-muted");
      classes = classes.replace(/\banimate-\w+/g, "");
      break;

    case "tech":
      // Modo técnico: enfasis en nitidez, sombras técnicas y estados activos definidos
      classes += " shadow-lg shadow-primary transition-shadow duration-250 ease-in-out";
      classes = classes.replace(/\bg-(primary|secondary)-foreground\b/g, "text-white");
      break;

    case "futuristic":
      // Modo futurista: añade pulsos suaves y escalamiento para profundidad sensorial
      classes += " scale-[1.05] animate-pulse-slow";
      break;

    case "immersive":
      // Modo inmersivo: integración de efectos lumínicos y vibraciones visuales sutiles
      classes += " animate-glow animate-flicker-slow shadow-elegant shadow-cyan-600/75";
      break;

    default:
      // Default safe fallback, limpiando clases no soportadas
      break;
  }

  // Manejo avanzado de accesibilidad con modos de alto contraste o animaciones reducidas
  if (options.accessibilityLevel === "highContrast") {
    // Textos claros y sin sombras
    classes = classes.replace(/\btext-[a-zA-Z-]+\b/g, "text-white");
    classes = classes.replace(/\bshadow(-\w+)?\b/g, "");
    classes = classes.replace(/\b(bg-[a-zA-Z0-9/-]+)\b/g, "bg-black");
  }

  if (options.accessibilityLevel === "reducedMotion") {
    // Remover animaciones para preferencias de usuario
    classes = classes.replace(/\banimate-[a-zA-Z-]+\b/g, "");
    classes = classes.replace(/\btransition[-\w]*\b/g, "");
  }

  // Ajustes fintos para optimización basada en hints de performance
  if (options.performanceHints) {
    // Reducir clases no críticas y priorizar suavidad
    // ejemplo: eliminar box-shadow si exceso impacta
    classes = classes.replace(/\bshadow(-\w+)?\b/g, "");
    // prefijo 'will-change' para anticipar cambios GPU
    classes += " will-change-transform will-change-opacity";
  }

  // Merge para resolver conflictos específicos Tailwind y limpiar redundancias
  return twMerge(classes);
}
