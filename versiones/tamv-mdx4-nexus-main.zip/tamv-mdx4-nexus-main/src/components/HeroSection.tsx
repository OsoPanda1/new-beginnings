import { Button } from '@/components/ui/button';
import { ArrowRight, Globe, Shield, Zap } from 'lucide-react';
import heroImage from '@/assets/hero-tamv-bg.jpg';

const HeroSection = () => {
  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: `url(${heroImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: 'fixed'
        }}
      >
        <div className="absolute inset-0 bg-background/40 backdrop-blur-[2px]" />
        <div className="absolute inset-0 bg-gradient-mesh opacity-60" />
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 text-center">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Badge */}
          <div className="inline-flex items-center px-4 py-2 rounded-full bg-white/5 backdrop-blur-sm border border-primary/20">
            <Globe className="w-4 h-4 mr-2 text-primary" />
            <span className="text-sm font-medium">Nación Digital Soberana</span>
          </div>

          {/* Main Heading */}
          <h1 className="text-5xl md:text-7xl font-bold leading-tight">
            <span className="bg-gradient-hero bg-clip-text text-transparent">
              TAMV MD-X4™
            </span>
            <br />
            <span className="text-foreground">
              Ecosistema Digital
            </span>
            <br />
            <span className="text-2xl md:text-4xl font-normal text-foreground/80">
              del Futuro
            </span>
          </h1>

          {/* Description */}
          <p className="text-xl md:text-2xl text-foreground/80 max-w-3xl mx-auto leading-relaxed">
            La primera nación-estado digital completamente soberana. 
            Un ecosistema tecnológico revolucionario que redefine la 
            gobernanza, economía y sociedad digital.
          </p>

          {/* Feature Pills */}
          <div className="flex flex-wrap justify-center gap-4 pt-4">
            <div className="flex items-center px-4 py-2 rounded-full bg-white/5 backdrop-blur-sm border border-primary/20">
              <Shield className="w-4 h-4 mr-2 text-primary" />
              <span className="text-sm">Soberanía Digital</span>
            </div>
            <div className="flex items-center px-4 py-2 rounded-full bg-white/5 backdrop-blur-sm border border-secondary/20">
              <Zap className="w-4 h-4 mr-2 text-secondary" />
              <span className="text-sm">Tecnología Avanzada</span>
            </div>
            <div className="flex items-center px-4 py-2 rounded-full bg-white/5 backdrop-blur-sm border border-accent/20">
              <Globe className="w-4 h-4 mr-2 text-accent" />
              <span className="text-sm">Alcance Global</span>
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-8">
            <Button variant="hero" size="lg" className="group">
              Acceder a la Plataforma
              <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button variant="glass" size="lg">
              Ver Documentación
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 pt-16 max-w-2xl mx-auto">
            <div className="text-center space-y-2">
              <div className="text-3xl font-bold text-primary">100+</div>
              <div className="text-sm text-foreground/60">Tecnologías Integradas</div>
            </div>
            <div className="text-center space-y-2">
              <div className="text-3xl font-bold text-secondary">∞</div>
              <div className="text-sm text-foreground/60">Escalabilidad</div>
            </div>
            <div className="text-center space-y-2">
              <div className="text-3xl font-bold text-accent">24/7</div>
              <div className="text-sm text-foreground/60">Operación Global</div>
            </div>
          </div>
        </div>
      </div>

      {/* Animated Elements */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-primary rounded-full flex justify-center">
          <div className="w-1 h-3 bg-primary rounded-full mt-2 animate-pulse" />
        </div>
      </div>
    </section>
  );
};

export default HeroSection;