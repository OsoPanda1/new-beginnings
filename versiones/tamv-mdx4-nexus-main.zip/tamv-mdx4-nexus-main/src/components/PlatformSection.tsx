import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Brain, 
  Shield, 
  Zap, 
  Globe, 
  Database, 
  Code, 
  Users, 
  TrendingUp,
  Lock,
  Cpu,
  Network,
  Sparkles
} from 'lucide-react';

const PlatformSection = () => {
  const platformFeatures = [
    {
      icon: Brain,
      title: "IA Soberana",
      description: "Sistema de inteligencia artificial nativo completamente autónomo",
      capabilities: ["Machine Learning Avanzado", "Procesamiento de Lenguaje Natural", "Análisis Predictivo", "Toma de Decisiones Automatizada"]
    },
    {
      icon: Shield,
      title: "Seguridad Cuántica",
      description: "Criptografía post-cuántica para máxima seguridad",
      capabilities: ["Encriptación Cuántica", "Autenticación Biométrica", "Zero-Knowledge Proofs", "Infraestructura Inmutable"]
    },
    {
      icon: Database,
      title: "Blockchain Nativo",
      description: "Red blockchain optimizada para gobernanza digital",
      capabilities: ["Consenso Híbrido", "Smart Contracts Avanzados", "DeFi Integrado", "NFTs Institucionales"]
    },
    {
      icon: Network,
      title: "Interoperabilidad",
      description: "Conexión con ecosistemas globales",
      capabilities: ["Cross-Chain Bridges", "API Universal", "Estándares Abiertos", "Integración Legacy"]
    }
  ];

  const technicalSpecs = [
    { label: "Throughput", value: "1M+ TPS", colorClass: "text-primary" },
    { label: "Latencia", value: "<50ms", colorClass: "text-secondary" },
    { label: "Uptime", value: "99.99%", colorClass: "text-success" },
    { label: "Nodes", value: "Global", colorClass: "text-accent" }
  ];

  return (
    <section id="platform" className="py-24 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 mesh-gradient opacity-20" />
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="bg-gradient-hero bg-clip-text text-transparent">
              Plataforma TAMV MD-X4™
            </span>
          </h2>
          <p className="text-xl text-foreground/80 max-w-3xl mx-auto">
            La infraestructura tecnológica más avanzada para la primera 
            nación digital completamente soberana del mundo.
          </p>
        </div>

        {/* Technical Specifications */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          {technicalSpecs.map((spec, index) => (
            <div key={index} className="text-center space-y-2">
              <div className={`text-3xl md:text-4xl font-bold ${spec.colorClass}`}>
                {spec.value}
              </div>
              <div className="text-sm text-foreground/60">{spec.label}</div>
            </div>
          ))}
        </div>

        {/* Platform Features */}
        <Tabs defaultValue="overview" className="mb-16">
          <TabsList className="grid w-full grid-cols-1 md:grid-cols-4 mb-8 bg-white/5 backdrop-blur-sm">
            <TabsTrigger value="overview" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              Visión General
            </TabsTrigger>
            <TabsTrigger value="architecture" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              Arquitectura
            </TabsTrigger>
            <TabsTrigger value="governance" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              Gobernanza
            </TabsTrigger>
            <TabsTrigger value="economics" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              Economía
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {platformFeatures.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <Card key={index} className="bg-white/5 backdrop-blur-sm border border-primary/20 hover:border-primary/40 transition-all duration-300 group">
                    <CardHeader>
                      <div className="flex items-center space-x-3">
                        <div className="p-3 rounded-lg bg-primary/10 group-hover:bg-primary/20 transition-colors">
                          <Icon className="w-6 h-6 text-primary" />
                        </div>
                        <div>
                          <CardTitle className="text-xl">{feature.title}</CardTitle>
                          <CardDescription className="text-foreground/60">
                            {feature.description}
                          </CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-2">
                        {feature.capabilities.map((capability, capIndex) => (
                          <div key={capIndex} className="flex items-center space-x-2 p-2 rounded bg-white/5">
                            <Sparkles className="w-3 h-3 text-accent" />
                            <span className="text-sm text-foreground/80">{capability}</span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="architecture" className="space-y-6">
            <Card className="bg-white/5 backdrop-blur-sm border border-primary/20">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Cpu className="w-5 h-5 text-primary" />
                  <span>Arquitectura del Sistema</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 rounded-lg bg-primary/10 border border-primary/20">
                    <h4 className="font-semibold mb-2">Capa de Presentación</h4>
                    <p className="text-sm text-foreground/70">Interfaces de usuario adaptativas y personalizables</p>
                  </div>
                  <div className="p-4 rounded-lg bg-secondary/10 border border-secondary/20">
                    <h4 className="font-semibold mb-2">Capa de Lógica</h4>
                    <p className="text-sm text-foreground/70">Motor de reglas de negocio y procesamiento distribuido</p>
                  </div>
                  <div className="p-4 rounded-lg bg-accent/10 border border-accent/20">
                    <h4 className="font-semibold mb-2">Capa de Datos</h4>
                    <p className="text-sm text-foreground/70">Almacenamiento distribuido y bases de datos cuánticas</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="governance" className="space-y-6">
            <Card className="bg-white/5 backdrop-blur-sm border border-primary/20">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Users className="w-5 h-5 text-primary" />
                  <span>Sistema de Gobernanza Digital</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 rounded-lg bg-primary/10">
                    <div>
                      <h4 className="font-semibold">Democracia Líquida</h4>
                      <p className="text-sm text-foreground/70">Votación directa y delegación flexible</p>
                    </div>
                    <Lock className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex items-center justify-between p-4 rounded-lg bg-secondary/10">
                    <div>
                      <h4 className="font-semibold">Consenso Híbrido</h4>
                      <p className="text-sm text-foreground/70">Algoritmos adaptativos de toma de decisiones</p>
                    </div>
                    <Brain className="w-5 h-5 text-secondary" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="economics" className="space-y-6">
            <Card className="bg-white/5 backdrop-blur-sm border border-primary/20">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <TrendingUp className="w-5 h-5 text-primary" />
                  <span>Modelo Económico Digital</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <h4 className="font-semibold text-accent">Tokenomics Nativo</h4>
                    <ul className="space-y-2 text-sm text-foreground/70">
                      <li>• Token de utilidad multifuncional</li>
                      <li>• Staking y rewards automáticos</li>
                      <li>• Deflación controlada algorítmicamente</li>
                      <li>• Integración DeFi nativa</li>
                    </ul>
                  </div>
                  <div className="space-y-3">
                    <h4 className="font-semibold text-secondary">Economía Circular</h4>
                    <ul className="space-y-2 text-sm text-foreground/70">
                      <li>• Recursos computacionales compartidos</li>
                      <li>• Incentivos por participación</li>
                      <li>• Redistribución automática de valor</li>
                      <li>• Sostenibilidad económica garantizada</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* CTA Section */}
        <div className="text-center space-y-6">
          <h3 className="text-2xl font-semibold">Únete al Futuro Digital</h3>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button variant="hero" size="lg">
              <Code className="w-5 h-5 mr-2" />
              Acceder a Beta
            </Button>
            <Button variant="tech" size="lg">
              <Globe className="w-5 h-5 mr-2" />
              Explorar Demo
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PlatformSection;