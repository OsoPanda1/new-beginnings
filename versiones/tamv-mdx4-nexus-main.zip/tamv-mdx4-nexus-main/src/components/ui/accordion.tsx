import * as React from "react";
import * as AccordionPrimitive from "@radix-ui/react-accordion";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";

const Accordion = AccordionPrimitive.Root;

const AccordionItem = React.forwardRef<
  React.ElementRef<typeof AccordionPrimitive.Item>,
  React.ComponentPropsWithoutRef<typeof AccordionPrimitive.Item>
>(({ className, ...props }, ref) => (
  <AccordionPrimitive.Item
    ref={ref}
    className={cn(
      "border-b border-gray-700 last:border-0 dark:border-gray-600",
      className,
    )}
    {...props}
  />
));
AccordionItem.displayName = "AccordionItem";

const AccordionTrigger = React.forwardRef<
  React.ElementRef<typeof AccordionPrimitive.Trigger>,
  React.ComponentPropsWithoutRef<typeof AccordionPrimitive.Trigger>
>(({ className, children, ...props }, ref) => (
  <AccordionPrimitive.Header className="flex w-full">
    <AccordionPrimitive.Trigger
      ref={ref}
      className={cn(
        "flex flex-1 items-center justify-between rounded-md bg-gray-800 dark:bg-gray-900 px-5 py-4 text-lg font-semibold text-gray-200 hover:bg-gray-700 dark:hover:bg-gray-800 focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 transition-all shadow-md",
        className,
      )}
      {...props}
    >
      {children}
      <motion.span
        animate={{
          rotate: props["data-state"] === "open" ? 180 : 0,
        }}
        transition={{ duration: 0.3, ease: "easeInOut" }}
        className="ml-2 flex shrink-0"
        aria-hidden="true"
      >
        <ChevronDown className="h-5 w-5 text-indigo-400" />
      </motion.span>
    </AccordionPrimitive.Trigger>
  </AccordionPrimitive.Header>
));
AccordionTrigger.displayName = AccordionPrimitive.Trigger.displayName;

const collapseVariants = {
  open: {
    opacity: 1,
    height: "auto",
  },
  collapsed: {
    opacity: 0,
    height: 0,
  },
};

const AccordionContent = React.forwardRef<
  React.ElementRef<typeof AccordionPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof AccordionPrimitive.Content>
>(({ className, children, ...props }, ref) => {
  // We read data-state from props or use opened as fallback
  const isOpen = (props as any)["data-state"] === "open";

  return (
    <AccordionPrimitive.Content ref={ref} {...props} asChild>
      <AnimatePresence initial={false}>
        {isOpen && (
          <motion.div
            key="content"
            className={cn("overflow-hidden text-sm text-gray-300 dark:text-gray-400 px-5", className)}
            initial="collapsed"
            animate="open"
            exit="collapsed"
            variants={collapseVariants}
            transition={{ duration: 0.3 }}
          >
            <div className="py-4">{children}</div>
          </motion.div>
        )}
      </AnimatePresence>
    </AccordionPrimitive.Content>
  );
});

AccordionContent.displayName = AccordionPrimitive.Content.displayName;

export { Accordion, AccordionItem, AccordionTrigger, AccordionContent };
