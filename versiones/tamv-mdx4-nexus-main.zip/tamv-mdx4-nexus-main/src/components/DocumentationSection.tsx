import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { FileText, Book, Code, Users, Shield, Globe, Download, ExternalLink } from 'lucide-react';

const DocumentationSection = () => {
  const documentCategories = [
    {
      icon: FileText,
      title: "Memorándum Fundacional",
      description: "Documento arquitectónico base del ecosistema TAMV MD-X4™",
      items: [
        "Filosofía y Principios Fundamentales",
        "Arquitectura del Sistema",
        "Marco Legal y Regulatorio",
        "Modelo Económico Digital"
      ],
      color: "primary"
    },
    {
      icon: Code,
      title: "Documentación Técnica",
      description: "Especificaciones completas para desarrolladores",
      items: [
        "APIs y Protocolos",
        "Infraestructura Blockchain",
        "Seguridad y Criptografía",
        "Integración de Sistemas"
      ],
      color: "secondary"
    },
    {
      icon: Users,
      title: "Para Inversionistas",
      description: "Información financiera y oportunidades de inversión",
      items: [
        "Plan de Negocio",
        "Modelo de Tokenomics",
        "Proyecciones Financieras",
        "Roadmap de Desarrollo"
      ],
      color: "accent"
    },
    {
      icon: Shield,
      title: "Marco Legal",
      description: "Documentación jurídica y de compliance",
      items: [
        "Términos y Condiciones",
        "Política de Privacidad",
        "Marco Regulatorio",
        "Derechos de Propiedad Intelectual"
      ],
      color: "success"
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      primary: "border-primary/20 hover:border-primary/40",
      secondary: "border-secondary/20 hover:border-secondary/40",
      accent: "border-accent/20 hover:border-accent/40",
      success: "border-success/20 hover:border-success/40"
    };
    return colors[color as keyof typeof colors] || colors.primary;
  };

  const getIconColorClasses = (color: string) => {
    const colors = {
      primary: "bg-primary/10 text-primary",
      secondary: "bg-secondary/10 text-secondary",
      accent: "bg-accent/10 text-accent",
      success: "bg-success/10 text-success"
    };
    return colors[color as keyof typeof colors] || colors.primary;
  };

  const getDotColorClasses = (color: string) => {
    const colors = {
      primary: "bg-primary",
      secondary: "bg-secondary",
      accent: "bg-accent",
      success: "bg-success"
    };
    return colors[color as keyof typeof colors] || colors.primary;
  };

  return (
    <section id="documentation" className="py-24 bg-gradient-card">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="bg-gradient-primary bg-clip-text text-transparent">
              Documentación Oficial
            </span>
          </h2>
          <p className="text-xl text-foreground/80 max-w-3xl mx-auto">
            Accede a toda la documentación legal, técnica e institucional del 
            ecosistema TAMV MD-X4™. Información completa para todos los stakeholders.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {documentCategories.map((category, index) => {
            const Icon = category.icon;
            return (
              <Card 
                key={index} 
                className={`bg-white/5 backdrop-blur-sm border ${getColorClasses(category.color)} 
                          hover:bg-white/10 transition-all duration-300 group`}
              >
                <CardHeader>
                  <div className="flex items-center space-x-3 mb-4">
                    <div className={`p-3 rounded-lg ${getIconColorClasses(category.color)}`}>
                      <Icon className="w-6 h-6" />
                    </div>
                    <div>
                      <CardTitle className="text-xl text-foreground">{category.title}</CardTitle>
                      <CardDescription className="text-foreground/60">
                        {category.description}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 mb-6">
                    {category.items.map((item, itemIndex) => (
                      <li key={itemIndex} className="flex items-center space-x-2">
                        <div className={`w-1.5 h-1.5 rounded-full ${getDotColorClasses(category.color)}`} />
                        <span className="text-foreground/80">{item}</span>
                      </li>
                    ))}
                  </ul>
                  <div className="flex space-x-3">
                    <Button variant="outline" size="sm" className="group">
                      <Download className="w-4 h-4 mr-2 group-hover:translate-y-0.5 transition-transform" />
                      Descargar
                    </Button>
                    <Button variant="ghost" size="sm" className="group">
                      <ExternalLink className="w-4 h-4 mr-2 group-hover:translate-x-0.5 transition-transform" />
                      Ver Online
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Quick Access */}
        <div className="text-center space-y-6">
          <h3 className="text-2xl font-semibold text-foreground">Acceso Rápido</h3>
          <div className="flex flex-wrap justify-center gap-4">
            <Button variant="hero">
              <Book className="w-4 h-4 mr-2" />
              Memorándum Completo
            </Button>
            <Button variant="tech">
              <Code className="w-4 h-4 mr-2" />
              API Reference
            </Button>
            <Button variant="glass">
              <Globe className="w-4 h-4 mr-2" />
              Presentación Ejecutiva
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DocumentationSection;