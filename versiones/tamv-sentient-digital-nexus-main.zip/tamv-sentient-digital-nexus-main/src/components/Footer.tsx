import { Button } from "@/components/ui/button";
import { Github, Twitter, Linkedin, Mail, Globe } from "lucide-react";

const Footer = () => {
  return (
    <footer className="relative border-t border-border/50 mt-24">
      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <h3 className="text-2xl font-bold text-gradient">TAMV MD-X4™</h3>
            <p className="text-sm text-muted-foreground">
              Arquitectura de Civilización Digital para la Web 4.0
            </p>
            <div className="flex gap-2">
              <Button variant="ghost" size="icon" className="hover:text-primary">
                <Github className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon" className="hover:text-primary">
                <Twitter className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon" className="hover:text-primary">
                <Linkedin className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon" className="hover:text-primary">
                <Mail className="w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* Ecosystem */}
          <div className="space-y-4">
            <h4 className="font-bold">Ecosistema</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="#" className="hover:text-primary transition-colors">Isabella AI</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">ID-NVIDA</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">DEKATEOTL</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Anubis Sentinel</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">HyperRender 4D</a></li>
            </ul>
          </div>

          {/* Resources */}
          <div className="space-y-4">
            <h4 className="font-bold">Recursos</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="#" className="hover:text-primary transition-colors">Documentación</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Whitepaper</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">API Docs</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">GitHub</a></li>
              <li>
                <a 
                  href="https://tamvonlinenetwork.blogspot.com" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="hover:text-primary transition-colors flex items-center gap-1"
                >
                  Blog del Proyecto <Globe className="w-3 h-3" />
                </a>
              </li>
            </ul>
          </div>

          {/* Company */}
          <div className="space-y-4">
            <h4 className="font-bold">Organización</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="#" className="hover:text-primary transition-colors">Sobre Nosotros</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Equipo</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Carreras</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Contacto</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Privacidad</a></li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-border/50 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-muted-foreground text-center md:text-left">
            © 2025 TAMV MD-X4™. Real del Monte, Hidalgo, México.
          </p>
          <p className="text-xs text-muted-foreground text-center md:text-right">
            Fundador: Edwin Anubis Villaseñor | Versión 4.0 - Integral Completa
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
