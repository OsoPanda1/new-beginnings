// components/Hero.tsx
import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";

const Hero = () => {
  const [currentScene, setCurrentScene] = useState(0);
  const [isabellaMessage, setIsabellaMessage] = useState("");
  const [particleCount, setParticleCount] = useState(0);
  const [energyLevel, setEnergyLevel] = useState(0);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const audioRef = useRef<HTMLAudioElement>(null);

  // Escenas narrativas del Hero
  const scenes = [
    {
      title: "TAMV MD-X4",
      subtitle: "Civilización Digital Mexicana",
      message: "Isabella: Bienvenido al amanecer de una nueva era digital...",
      bg: "cosmic",
      energy: 30
    },
    {
      title: "Web 4.0 Cuántica",
      subtitle: "Más Allá de lo Imaginable",
      message: "Isabella: Donde cada interacción dignifica y empodera...",
      bg: "quantum",
      energy: 60
    },
    {
      title: "IA Ética Consciente",
      subtitle: "Tecnología con Alma Humana",
      message: "Isabella: Creada para cuidar, proteger y guiar...",
      bg: "neural",
      energy: 85
    },
    {
      title: "Real del Monte",
      subtitle: "Corazón de la Innovación Mexicana",
      message: "Isabella: Desde las montañas de Hidalgo hacia el cosmos digital...",
      bg: "mexican",
      energy: 70
    }
  ];

  // Efecto para cambiar escenas automáticamente
  useEffect(() => {
    const sceneInterval = setInterval(() => {
      setCurrentScene((prev) => (prev + 1) % scenes.length);
    }, 8000);

    return () => clearInterval(sceneInterval);
  }, []);

  // Efecto para mensajes de Isabella
  useEffect(() => {
    const messages = [
      "Sistema TAMV MD-X4 operativo y consciente...",
      "19,000 horas de desarrollo culminan en este momento...",
      "Tu presencia activa el ecosistema multidimensional...",
      "Cada interacción aquí crea un futuro más humano...",
      "La tecnología ética comienza con una conexión auténtica...",
      "Bienvenido a donde la innovación abraza la tradición..."
    ];

    const messageInterval = setInterval(() => {
      const randomMessage = messages[Math.floor(Math.random() * messages.length)];
      setIsabellaMessage(randomMessage);
      
      // Limpiar mensaje después de 5 segundos
      setTimeout(() => setIsabellaMessage(""), 5000);
    }, 10000);

    return () => clearInterval(messageInterval);
  }, []);

  // Efecto para el canvas de partículas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Ajustar canvas al tamaño de la ventana
    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Sistema de partículas
    const particles: Array<{
      x: number;
      y: number;
      vx: number;
      vy: number;
      size: number;
      color: string;
      life: number;
    }> = [];

    // Crear partículas iniciales
    for (let i = 0; i < 50; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 2,
        vy: (Math.random() - 0.5) * 2,
        size: Math.random() * 3 + 1,
        color: `hsl(${Math.random() * 60 + 180}, 70%, 60%)`,
        life: 1
      });
    }

    const animate = () => {
      // Limpiar canvas con un fade sutil
      ctx.fillStyle = 'rgba(15, 11, 31, 0.1)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Actualizar y dibujar partículas
      particles.forEach((particle, index) => {
        particle.x += particle.vx;
        particle.y += particle.vy;
        particle.life -= 0.002;

        // Rebote en los bordes
        if (particle.x <= 0 || particle.x >= canvas.width) particle.vx *= -1;
        if (particle.y <= 0 || particle.y >= canvas.height) particle.vy *= -1;

        // Dibujar partícula
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
        ctx.fillStyle = particle.color;
        ctx.globalAlpha = particle.life;
        ctx.fill();

        // Reemplazar partículas que murieron
        if (particle.life <= 0) {
          particles[index] = {
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            vx: (Math.random() - 0.5) * 2,
            vy: (Math.random() - 0.5) * 2,
            size: Math.random() * 3 + 1,
            color: `hsl(${Math.random() * 60 + 180}, 70%, 60%)`,
            life: 1
          };
        }
      });

      // Conexiones entre partículas
      ctx.strokeStyle = 'rgba(180, 60, 85, 0.1)';
      ctx.lineWidth = 0.5;
      
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const distance = Math.sqrt(dx * dx + dy * dy);

          if (distance < 100) {
            ctx.globalAlpha = (1 - distance / 100) * particles[i].life * particles[j].life;
            ctx.beginPath();
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.stroke();
          }
        }
      }

      ctx.globalAlpha = 1;
      requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
    };
  }, []);

  // Efecto para la energía del sistema
  useEffect(() => {
    const targetEnergy = scenes[currentScene].energy;
    const interval = setInterval(() => {
      setEnergyLevel(prev => {
        const diff = targetEnergy - prev;
        return prev + (diff * 0.1);
      });
    }, 100);

    return () => clearInterval(interval);
  }, [currentScene]);

  return (
    <div className="relative min-h-screen overflow-hidden bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Canvas de Partículas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 pointer-events-none"
      />

      {/* Audio Ambiental */}
      <audio
        ref={audioRef}
        src="/audio/hero-ambient.mp3"
        loop
        muted={false}
        className="hidden"
      />

      {/* Fondo Dinámico */}
      <div className="absolute inset-0">
        <div className={`absolute inset-0 transition-all duration-2000 ${
          scenes[currentScene].bg === 'cosmic' ? 'bg-cosmic' :
          scenes[currentScene].bg === 'quantum' ? 'bg-quantum' :
          scenes[currentScene].bg === 'neural' ? 'bg-neural' : 'bg-mexican'
        }`} />
        
        {/* Efectos de Luz Dinámicos */}
        <div className="absolute inset-0">
          <motion.div
            className="absolute top-1/4 left-1/4 w-96 h-96 bg-crystal-glow/10 rounded-full blur-3xl"
            animate={{
              scale: [1, 1.2, 1],
              opacity: [0.3, 0.6, 0.3]
            }}
            transition={{
              duration: 8,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
          <motion.div
            className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-crystal-lowgreen/10 rounded-full blur-3xl"
            animate={{
              scale: [1.2, 1, 1.2],
              opacity: [0.4, 0.7, 0.4]
            }}
            transition={{
              duration: 6,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
        </div>
      </div>

      {/* Contenido Principal */}
      <div className="relative z-10 container mx-auto px-4 min-h-screen flex items-center justify-center">
        <div className="text-center max-w-6xl mx-auto">
          {/* Indicador de Escena */}
          <div className="flex justify-center mb-8 space-x-2">
            {scenes.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentScene(index)}
                className={`w-3 h-3 rounded-full transition-all duration-300 ${
                  index === currentScene
                    ? 'bg-crystal-glow scale-125'
                    : 'bg-crystal-glow/30 hover:bg-crystal-glow/50'
                }`}
              />
            ))}
          </div>

          {/* Título Principal */}
          <AnimatePresence mode="wait">
            <motion.div
              key={currentScene}
              initial={{ opacity: 0, y: 50, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -50, scale: 1.1 }}
              transition={{ duration: 1, ease: "easeInOut" }}
              className="mb-8"
            >
              <h1 className="text-6xl md:text-8xl lg:text-9xl font-bold mb-6">
                <span className="text-gradient-crystal block">
                  {scenes[currentScene].title.split(' ')[0]}
                </span>
                <span className="text-gradient-crystal-lowgreen block">
                  {scenes[currentScene].title.split(' ').slice(1).join(' ')}
                </span>
              </h1>
              
              <motion.p
                className="text-2xl md:text-3xl lg:text-4xl text-crystal-lowgreen/80 font-light mb-8"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
              >
                {scenes[currentScene].subtitle}
              </motion.p>
            </motion.div>
          </AnimatePresence>

          {/* Mensaje de Isabella */}
          <AnimatePresence>
            {isabellaMessage && (
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                className="bg-black/40 backdrop-blur-md border border-crystal-glow/30 rounded-2xl p-6 mb-8 max-w-2xl mx-auto"
              >
                <div className="flex items-center space-x-3">
                  <div className="w-3 h-3 bg-crystal-glow rounded-full animate-pulse" />
                  <p className="text-crystal-glow text-lg font-light">
                    {isabellaMessage}
                  </p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Indicador de Energía del Sistema */}
          <motion.div
            className="max-w-md mx-auto mb-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
          >
            <div className="flex justify-between text-crystal-lowgreen text-sm mb-2">
              <span>Energía del Sistema:</span>
              <span>{Math.round(energyLevel)}%</span>
            </div>
            <div className="w-full bg-crystal-glow/20 rounded-full h-3 overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-crystal-lowgreen to-crystal-glow rounded-full"
                initial={{ width: "0%" }}
                animate={{ width: `${energyLevel}%` }}
                transition={{ duration: 1, ease: "easeOut" }}
              />
            </div>
          </motion.div>

          {/* Botones de Acción */}
          <motion.div
            className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.2 }}
          >
            <Button className="bg-crystal-glow/20 border-crystal-glow/40 text-crystal-glow hover:bg-crystal-glow/30 px-8 py-3 text-lg rounded-xl transition-all duration-300 group">
              <span className="flex items-center space-x-2">
                <span>🚀 Explorar Ecosistema</span>
                <motion.span
                  animate={{ x: [0, 5, 0] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  →
                </motion.span>
              </span>
            </Button>

            <Button variant="outline" className="border-crystal-lowgreen/40 text-crystal-lowgreen hover:bg-crystal-lowgreen/10 px-8 py-3 text-lg rounded-xl transition-all duration-300">
              <span className="flex items-center space-x-2">
                <span>🎵 KAOS Audio</span>
                <span className="text-xs bg-crystal-lowgreen/20 px-2 py-1 rounded">Nuevo</span>
              </span>
            </Button>

            <Button variant="outline" className="border-crystal-glow/20 text-crystal-glow/80 hover:bg-crystal-glow/10 px-8 py-3 text-lg rounded-xl transition-all duration-300">
              Conectar ID-NVIDA
            </Button>
          </motion.div>

          {/* Stats del Ecosistema */}
          <motion.div
            className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.5 }}
          >
            {[
              { label: "Usuarios Activos", value: "47.3K", icon: "👥" },
              { label: "Horas de Desarrollo", value: "19K+", icon: "⏱️" },
              { label: "Transacciones Éticas", value: "2.1M", icon: "⚡" },
              { label: "Satisfacción", value: "99.8%", icon: "⭐" }
            ].map((stat, index) => (
              <motion.div
                key={stat.label}
                className="bg-black/30 backdrop-blur-sm border border-crystal-glow/20 rounded-xl p-4 text-center"
                whileHover={{ 
                  scale: 1.05,
                  borderColor: "rgba(180, 60, 85, 0.5)",
                  transition: { duration: 0.2 }
                }}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.7 + index * 0.1 }}
              >
                <div className="text-2xl mb-2">{stat.icon}</div>
                <div className="text-crystal-glow text-2xl font-bold mb-1">{stat.value}</div>
                <div className="text-crystal-lowgreen text-sm">{stat.label}</div>
              </motion.div>
            ))}
          </motion.div>

          {/* Scroll Indicator */}
          <motion.div
            className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 2 }}
          >
            <motion.div
              animate={{ y: [0, 10, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="text-crystal-glow/60"
            >
              <div className="flex flex-col items-center space-y-2">
                <span className="text-sm">Explorar más</span>
                <div className="w-6 h-10 border-2 border-crystal-glow/40 rounded-full flex justify-center">
                  <motion.div
                    animate={{ y: [0, 12, 0] }}
                    transition={{ duration: 2, repeat: Infinity }}
                    className="w-1 h-3 bg-crystal-glow rounded-full mt-2"
                  />
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>

      {/* Orbe Flotante de Isabella */}
      <motion.div
        className="absolute top-1/4 right-8 w-24 h-24 md:w-32 md:h-32"
        animate={{
          y: [0, -20, 0],
          rotate: 360
        }}
        transition={{
          y: { duration: 4, repeat: Infinity, ease: "easeInOut" },
          rotate: { duration: 20, repeat: Infinity, ease: "linear" }
        }}
      >
        <div className="relative w-full h-full">
          <div className="absolute inset-0 border-2 border-crystal-glow/50 rounded-full" />
          <div className="absolute inset-4 bg-gradient-to-r from-crystal-glow/20 to-crystal-lowgreen/20 rounded-full" />
          <div className="absolute inset-8 bg-crystal-glow/10 rounded-full backdrop-blur-sm" />
        </div>
      </motion.div>

      {/* Efectos de Partículas Adicionales */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-crystal-glow rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -100, 0],
              opacity: [0, 1, 0],
              scale: [0, 1, 0]
            }}
            transition={{
              duration: Math.random() * 10 + 10,
              repeat: Infinity,
              delay: Math.random() * 5,
              ease: "easeInOut"
            }}
          />
        ))}
      </div>

      {/* Estilos CSS personalizados */}
      <style>{`
        .bg-cosmic {
          background: 
            radial-gradient(ellipse at 20% 50%, rgba(56, 189, 248, 0.15) 0%, transparent 50%),
            radial-gradient(ellipse at 80% 20%, rgba(139, 92, 246, 0.1) 0%, transparent 50%),
            radial-gradient(ellipse at 40% 80%, rgba(236, 72, 153, 0.08) 0%, transparent 50%),
            linear-gradient(135deg, #0F0B1F 0%, #1A1540 50%, #1E3A5F 100%);
        }
        
        .bg-quantum {
          background: 
            radial-gradient(ellipse at 50% 50%, rgba(180, 60, 85, 0.2) 0%, transparent 70%),
            radial-gradient(ellipse at 30% 70%, rgba(160, 50, 75, 0.15) 0%, transparent 60%),
            linear-gradient(135deg, #0F0B1F 0%, #2A2255 50%, #1E3A5F 100%);
        }
        
        .bg-neural {
          background: 
            radial-gradient(ellipse at 60% 40%, rgba(34, 211, 238, 0.1) 0%, transparent 50%),
            radial-gradient(ellipse at 40% 60%, rgba(139, 92, 246, 0.1) 0%, transparent 50%),
            linear-gradient(135deg, #0F0B1F 0%, #1A1540 50%, #164E63 100%);
        }
        
        .bg-mexican {
          background: 
            radial-gradient(ellipse at 20% 30%, rgba(206, 17, 38, 0.1) 0%, transparent 50%),
            radial-gradient(ellipse at 80% 70%, rgba(0, 104, 71, 0.1) 0%, transparent 50%),
            radial-gradient(ellipse at 50% 50%, rgba(255, 255, 255, 0.05) 0%, transparent 50%),
            linear-gradient(135deg, #0F0B1F 0%, #1A1540 50%, #006847 100%);
        }

        .text-gradient-crystal {
          background: linear-gradient(135deg, hsl(180, 60%, 85%) 0%, hsl(160, 50%, 75%) 50%, hsl(170, 70%, 80%) 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          text-shadow: 0 0 30px rgba(180, 60, 85, 0.5);
        }

        .text-gradient-crystal-lowgreen {
          background: linear-gradient(135deg, hsl(160, 50%, 75%) 0%, hsl(170, 70%, 80%) 50%, hsl(180, 60%, 85%) 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }
      `}</style>
    </div>
  );
};

export default Hero;
