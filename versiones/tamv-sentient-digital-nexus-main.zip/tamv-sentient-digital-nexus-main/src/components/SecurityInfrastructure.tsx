import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Shield, Lock, Eye, AlertTriangle, Key, Zap } from "lucide-react";

const securityLayers = [
  {
    layer: "Perímetro",
    icon: Shield,
    color: "destructive",
    components: [
      { name: "WAF Enterprise", tech: "Cloudflare Advanced", protection: "OWASP Top 10, Zero-Day" },
      { name: "DDoS Protection", tech: "Always-On 100+ Tbps", protection: "L3/L4/L7 Attacks" },
      { name: "Bot Management", tech: "Advanced Challenge", protection: "Credential Stuffing, Scraping" }
    ]
  },
  {
    layer: "Red",
    icon: Lock,
    color: "primary",
    components: [
      { name: "Zero Trust Architecture", tech: "BeyondCorp Implementation", protection: "Never Trust, Always Verify" },
      { name: "Microsegmentación", tech: "Calico Network Policies", protection: "Lateral Movement Prevention" },
      { name: "TLS 1.3 Only", tech: "Perfect Forward Secrecy", protection: "Man-in-the-Middle Prevention" }
    ]
  },
  {
    layer: "Aplicación",
    icon: Eye,
    color: "secondary",
    components: [
      { name: "Input Validation", tech: "OWASP ASVS Level 2", protection: "Injection Attacks" },
      { name: "Rate Limiting", tech: "Dynamic Behavioral", protection: "API Abuse, Brute Force" },
      { name: "SAST/DAST", tech: "GitLab SAST + OWASP ZAP", protection: "Code Vulnerabilities" }
    ]
  },
  {
    layer: "Datos",
    icon: Key,
    color: "accent",
    components: [
      { name: "Encryption at Rest", tech: "AES-256-GCM", protection: "Data Breach Mitigation" },
      { name: "Encryption in Transit", tech: "TLS 1.3 + HSTS", protection: "Interception Prevention" },
      { name: "Key Management", tech: "Hashicorp Vault + HSM", protection: "Key Compromise Prevention" },
      { name: "Tokenization", tech: "PII Never Plaintext", protection: "Data Minimization" }
    ]
  },
  {
    layer: "Identidad",
    icon: Zap,
    color: "quantum",
    components: [
      { name: "MFA Obligatorio", tech: "WebAuthn + TOTP", protection: "Account Takeover Prevention" },
      { name: "Biometría Cancelable", tech: "ID-NVIDA™ Protocol", protection: "Biometric Theft Resilience" },
      { name: "Behavioral Auth", tech: "Continuous Authentication", protection: "Session Hijacking Prevention" }
    ]
  }
];

const threatIntelligence = [
  {
    category: "Identidad Digital",
    monitoring: ["Behavioral Biometrics", "Transaction Patterns", "Social Graph Analysis"],
    response: ["Adaptive Authentication", "Temporary Quarantine", "Guardian Notification"],
    aiPowered: true
  },
  {
    category: "Integridad de Contenido",
    monitoring: ["Deepfake Detection", "Misinformation Analysis", "Hate Speech Detection"],
    response: ["Content Flagging", "Contextual Education", "Community Moderation"],
    aiPowered: true
  },
  {
    category: "Seguridad Económica",
    monitoring: ["Transaction Anomalies", "Market Manipulation", "Wash Trading"],
    response: ["Transaction Review", "Temporary Holds", "Regulatory Reporting"],
    aiPowered: true
  },
  {
    category: "Seguridad Emocional",
    monitoring: ["Emotional Distress Patterns", "Harassment Detection", "Mental Health Indicators"],
    response: ["Support Resources", "Community Intervention", "Professional Referral"],
    aiPowered: true
  }
];

const incidentResponse = [
  {
    phase: "Detección",
    timeframe: "< 1 minuto",
    actions: ["SIEM Correlation", "Anomaly Detection", "Threat Intelligence Feed"],
    automation: "95%"
  },
  {
    phase: "Análisis",
    timeframe: "< 5 minutos",
    actions: ["Root Cause Analysis", "Impact Assessment", "Attack Vector Identification"],
    automation: "80%"
  },
  {
    phase: "Contención",
    timeframe: "< 15 minutos",
    actions: ["Network Isolation", "Account Suspension", "Service Degradation"],
    automation: "70%"
  },
  {
    phase: "Erradicación",
    timeframe: "< 2 horas",
    actions: ["Malware Removal", "Vulnerability Patching", "Access Revocation"],
    automation: "60%"
  },
  {
    phase: "Recuperación",
    timeframe: "< 24 horas",
    actions: ["Service Restoration", "Data Recovery", "System Hardening"],
    automation: "50%"
  },
  {
    phase: "Post-Incident",
    timeframe: "< 1 semana",
    actions: ["Lessons Learned", "Process Improvement", "Communication"],
    automation: "30%"
  }
];

const SecurityInfrastructure = () => {
  return (
    <section className="relative py-24 overflow-hidden" id="seguridad">
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 rounded-full bg-destructive blur-3xl animate-pulse" />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center space-y-4 mb-16">
          <Badge variant="outline" className="text-destructive border-destructive/50">
            Defense in Depth Architecture
          </Badge>
          <h2 className="text-gradient">Infraestructura de Seguridad Multicapa</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Arquitectura defensiva en profundidad con protección proactiva, 
            detección temprana y respuesta automatizada ante amenazas
          </p>
        </div>

        {/* Security Layers */}
        <div className="space-y-6 mb-16">
          {securityLayers.map((layer, index) => {
            const Icon = layer.icon;
            return (
              <Card 
                key={layer.layer}
                className="glass-effect border-border/50 overflow-hidden hover:glow-quantum transition-all duration-500"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <div className="p-6">
                  <div className="flex items-center gap-4 mb-6">
                    <div 
                      className="w-10 h-10 rounded-xl flex items-center justify-center"
                      style={{ backgroundColor: `hsl(var(--${layer.color}) / 0.2)` }}
                    >
                      <Icon 
                        className="w-5 h-5"
                        style={{ color: `hsl(var(--${layer.color}))` }}
                      />
                    </div>
                    <h3 className="text-xl font-bold">Capa {index + 1}: {layer.layer}</h3>
                  </div>

                  <div className="grid md:grid-cols-3 gap-4">
                    {layer.components.map((component) => (
                      <div 
                        key={component.name}
                        className="bg-card/30 rounded-lg p-4 border border-border/30 hover:border-primary/30 transition-colors duration-300"
                      >
                        <h4 className="font-bold text-sm mb-2">{component.name}</h4>
                        <p className="text-xs text-muted-foreground mb-1">
                          <strong>Tech:</strong> {component.tech}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          <strong>Protection:</strong> {component.protection}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              </Card>
            );
          })}
        </div>

        {/* Threat Intelligence */}
        <Card className="glass-effect p-8 mb-16 border-primary/30 glow-quantum">
          <div className="space-y-8">
            <div className="text-center">
              <Badge variant="outline" className="mb-4 text-primary border-primary/50">
                ANUBIS SENTINEL™ AI-Powered
              </Badge>
              <h3 className="text-3xl font-bold mb-4 text-gradient">
                Sistema de Inteligencia de Amenazas
              </h3>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Monitoreo continuo multisensorial con correlación de amenazas 
                y respuesta adaptativa proporcional
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              {threatIntelligence.map((threat) => (
                <div 
                  key={threat.category}
                  className="bg-card/40 rounded-xl p-6 border border-border/30 hover:border-primary/50 transition-colors duration-300"
                >
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h4 className="font-bold text-lg">{threat.category}</h4>
                      {threat.aiPowered && (
                        <Badge variant="outline" className="text-quantum border-quantum/50">
                          AI-Powered
                        </Badge>
                      )}
                    </div>

                    <div>
                      <p className="text-xs text-muted-foreground mb-2">Monitoreo:</p>
                      <div className="space-y-1">
                        {threat.monitoring.map((item) => (
                          <div key={item} className="flex items-start gap-2 text-sm">
                            <Eye className="w-3 h-3 text-primary mt-1 flex-shrink-0" />
                            <span className="text-muted-foreground">{item}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <p className="text-xs text-muted-foreground mb-2">Respuesta:</p>
                      <div className="space-y-1">
                        {threat.response.map((item) => (
                          <div key={item} className="flex items-start gap-2 text-sm">
                            <AlertTriangle className="w-3 h-3 text-destructive mt-1 flex-shrink-0" />
                            <span className="text-muted-foreground">{item}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Card>

        {/* Incident Response */}
        <Card className="glass-effect p-8 border-destructive/30 glow-quantum">
          <div className="space-y-8">
            <div className="text-center">
              <h3 className="text-3xl font-bold mb-4 text-gradient">
                Plan de Respuesta a Incidentes
              </h3>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Protocolo automatizado de 6 fases con tiempos de respuesta garantizados
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-4">
              {incidentResponse.map((phase, index) => (
                <div 
                  key={phase.phase}
                  className="bg-card/40 rounded-xl p-5 border border-border/30 hover:border-destructive/50 transition-colors duration-300"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Badge variant="outline" className="text-destructive border-destructive/50">
                        Fase {index + 1}
                      </Badge>
                      <Badge variant="secondary" className="text-xs">
                        {phase.automation} Auto
                      </Badge>
                    </div>

                    <h4 className="font-bold text-lg">{phase.phase}</h4>
                    <p className="text-sm text-quantum font-semibold">SLA: {phase.timeframe}</p>

                    <div className="space-y-1">
                      {phase.actions.map((action) => (
                        <div key={action} className="flex items-start gap-2 text-xs">
                          <span className="w-1 h-1 rounded-full bg-primary mt-1.5 flex-shrink-0" />
                          <span className="text-muted-foreground">{action}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-8 p-6 bg-destructive/10 rounded-lg border border-destructive/30">
              <p className="text-center text-sm text-muted-foreground">
                <strong className="text-destructive">Garantía de Seguridad:</strong> Monitoreo 24/7/365 
                con equipos SOC distribuidos globalmente, tiempo de respuesta promedio &lt; 3 minutos, 
                y recuperación ante desastres con RPO &lt; 1 hora y RTO &lt; 4 horas.
              </p>
            </div>
          </div>
        </Card>
      </div>
    </section>
  );
};

export default SecurityInfrastructure;
