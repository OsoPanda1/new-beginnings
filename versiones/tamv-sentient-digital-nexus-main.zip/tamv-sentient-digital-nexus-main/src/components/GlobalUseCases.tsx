import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Building2, GraduationCap, Landmark, Globe2, Heart, Palette, Factory } from "lucide-react";

const useCases = [
  {
    sector: "Gobierno y Sector Público",
    icon: Landmark,
    color: "primary",
    implementations: [
      {
        name: "Identidad Digital Soberana",
        description: "Sistema de identidad nacional con ID-NVIDA™ integrado",
        impact: "Reducción de fraude 95%, inclusión digital universal",
        deployments: ["México (INE Digital)", "Brasil (Gov.br)", "Colombia (Digital ID)"]
      },
      {
        name: "Votación Digital Segura",
        description: "Sistema electoral con blockchain y autenticación biométrica",
        impact: "Participación +40%, costos -60%, resultados en tiempo real",
        deployments: ["Piloto Hidalgo, México", "Estonia (referencia)", "Chile (plebiscitos)"]
      },
      {
        name: "Registros Públicos Inmutables",
        description: "Títulos de propiedad, actas, certificados en blockchain",
        impact: "Corrupción -80%, transparencia total, eficiencia +300%",
        deployments: ["Catastro Hidalgo", "Georgia (land registry)", "Suecia (property)"]
      }
    ]
  },
  {
    sector: "Educación y Conocimiento",
    icon: GraduationCap,
    color: "secondary",
    implementations: [
      {
        name: "TAMV University Campus 4D",
        description: "Campus virtual inmersivo con HyperRender 4D™",
        impact: "Acceso global, aprendizaje adaptativo, colaboración sin fronteras",
        deployments: ["UNAM México", "MIT OpenCourseWare", "Stanford Online"]
      },
      {
        name: "Credenciales Académicas Blockchain",
        description: "Diplomas y certificados verificables W3C estándar",
        impact: "Verificación instantánea, reconocimiento global, fraude cero",
        deployments: ["SEP México", "MIT Media Lab", "European Blockchain Partnership"]
      },
      {
        name: "Investigación Colaborativa IA",
        description: "Plataforma global con Isabella AI™ para investigación",
        impact: "Descubrimiento científico acelerado, acceso a computación cuántica",
        deployments: ["CONACYT México", "CERN", "NASA Open Science"]
      }
    ]
  },
  {
    sector: "Empresarial y Corporativo",
    icon: Building2,
    color: "accent",
    implementations: [
      {
        name: "Identidad de Empleados y Partners",
        description: "SSO empresarial con ID-NVIDA™ y zero trust",
        impact: "Seguridad +95%, productividad +30%, experiencia mejorada",
        deployments: ["Empresas Fortune 500", "Bancos", "Telecomunicaciones"]
      },
      {
        name: "Supply Chain Transparente",
        description: "Trazabilidad blockchain con IoT y sensores",
        impact: "Visibilidad total, compliance automático, fraude -100%",
        deployments: ["Walmart", "Maersk", "Pemex (piloto)"]
      },
      {
        name: "IA Ética para Atención al Cliente",
        description: "Chatbots con Isabella AI™ y comprensión emocional",
        impact: "Satisfacción +40%, costos -50%, disponibilidad 24/7",
        deployments: ["Bancos mexicanos", "Telcel", "América Móvil"]
      }
    ]
  },
  {
    sector: "Salud y Bienestar",
    icon: Heart,
    color: "quantum",
    implementations: [
      {
        name: "Historia Clínica Digital Soberana",
        description: "Expediente médico portátil propiedad del paciente",
        impact: "Interoperabilidad total, privacidad garantizada, emergencias salvadas",
        deployments: ["IMSS Digital", "NHS UK", "Kaiser Permanente"]
      },
      {
        name: "Telemedicina con IA Empática",
        description: "Consultas virtuales con Isabella AI™ triaje emocional",
        impact: "Acceso rural +200%, diagnóstico temprano +60%",
        deployments: ["Secretaría de Salud México", "Teladoc", "Babylon Health"]
      },
      {
        name: "Investigación Médica Federated",
        description: "Análisis de datos sin exponer información personal",
        impact: "Descubrimiento de tratamientos acelerado, privacidad preservada",
        deployments: ["COFEPRIS", "FDA", "EMA"]
      }
    ]
  },
  {
    sector: "Arte y Cultura",
    icon: Palette,
    color: "primary",
    implementations: [
      {
        name: "Preservación Cultural Indígena",
        description: "Digitalización 3D de artefactos y tradiciones orales",
        impact: "Patrimonio preservado permanentemente, acceso educativo global",
        deployments: ["Culturas Maya, Azteca, Zapoteca", "Smithsonian", "Louvre"]
      },
      {
        name: "Marketplace NFT para Artistas",
        description: "Plataforma con royalties automáticos y protección de derechos",
        impact: "Ingresos artistas +150%, mercado transparente, economía sostenible",
        deployments: ["Art Gallery TAMV", "SuperRare", "Foundation"]
      },
      {
        name: "Museos Virtuales 4D",
        description: "Galerías inmersivas con HyperRender™ y KAOS Audio",
        impact: "Visitantes globales ilimitados, experiencias multisensoriales",
        deployments: ["Museo Nacional de Antropología", "Hermitage", "MoMA"]
      }
    ]
  },
  {
    sector: "Infraestructura Crítica",
    icon: Factory,
    color: "secondary",
    implementations: [
      {
        name: "Smart Grid con Blockchain",
        description: "Red eléctrica descentralizada con energía tokenizada",
        impact: "Eficiencia +35%, renovables integradas, resiliencia mejorada",
        deployments: ["CFE México", "Brooklyn Microgrid", "Power Ledger"]
      },
      {
        name: "Gestión de Agua Inteligente",
        description: "IoT + IA para optimización de recursos hídricos",
        impact: "Desperdicio -40%, predicción de escasez, calidad monitoreada",
        deployments: ["CONAGUA", "Singapore PUB", "Copenhagen"]
      },
      {
        name: "Transporte Público Tokenizado",
        description: "Movilidad como servicio con TAMV Coins",
        impact: "Interoperabilidad total, tarifa justa dinámica, CO₂ -30%",
        deployments: ["Metro CDMX (piloto)", "Helsinki MaaS", "Singapore"]
      }
    ]
  }
];

const internationalExpansion = [
  {
    region: "México",
    status: "Implementación Nacional",
    timeline: "2025-2026",
    targets: "1M+ usuarios, 10+ estados, 100+ empresas"
  },
  {
    region: "Latinoamérica",
    status: "Expansión Regional",
    timeline: "2027-2028",
    targets: "50M+ usuarios, 5+ países, alianzas bancarias"
  },
  {
    region: "Global",
    status: "Incursión Selectiva",
    timeline: "2029-2030",
    targets: "500M+ usuarios, 3+ continentes, $1B+ ingresos"
  },
  {
    region: "Liderazgo Web 4.0",
    status: "Estándar Civilizatorio",
    timeline: "2031+",
    targets: "1B+ usuarios, $10B+ economía, estándares internacionales"
  }
];

const GlobalUseCases = () => {
  return (
    <section className="relative py-24 overflow-hidden" id="casos-uso">
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-1/4 right-1/4 w-96 h-96 rounded-full bg-accent blur-3xl animate-pulse" />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center space-y-4 mb-16">
          <Badge variant="outline" className="text-accent border-accent/50">
            Global Deployment Strategy
          </Badge>
          <h2 className="text-gradient">Casos de Uso e Implementaciones Globales</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Aplicaciones estratégicas en sectores críticos con impacto medible 
            y despliegues validados en múltiples jurisdicciones
          </p>
        </div>

        {/* Use Cases by Sector */}
        <div className="space-y-8 mb-16">
          {useCases.map((sector, index) => {
            const Icon = sector.icon;
            return (
              <Card 
                key={sector.sector}
                className="glass-effect border-border/50 overflow-hidden hover:glow-quantum transition-all duration-500"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="p-6 space-y-6">
                  <div className="flex items-center gap-4">
                    <div 
                      className="w-12 h-12 rounded-xl flex items-center justify-center"
                      style={{ backgroundColor: `hsl(var(--${sector.color}) / 0.2)` }}
                    >
                      <Icon 
                        className="w-6 h-6"
                        style={{ color: `hsl(var(--${sector.color}))` }}
                      />
                    </div>
                    <h3 className="text-2xl font-bold">{sector.sector}</h3>
                  </div>

                  <div className="grid gap-4">
                    {sector.implementations.map((impl) => (
                      <div 
                        key={impl.name}
                        className="bg-card/30 rounded-lg p-5 border border-border/30 hover:border-primary/50 transition-colors duration-300"
                      >
                        <div className="space-y-3">
                          <h4 className="font-bold text-lg text-primary">{impl.name}</h4>
                          <p className="text-sm text-muted-foreground">{impl.description}</p>
                          
                          <div className="flex flex-wrap gap-2 pt-2">
                            <Badge variant="outline" className="text-green-500 border-green-500/50">
                              Impacto: {impl.impact}
                            </Badge>
                          </div>

                          <div className="pt-2">
                            <p className="text-xs text-muted-foreground mb-2">Despliegues:</p>
                            <div className="flex flex-wrap gap-2">
                              {impl.deployments.map((deployment) => (
                                <Badge key={deployment} variant="secondary" className="text-xs">
                                  {deployment}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </Card>
            );
          })}
        </div>

        {/* International Expansion Timeline */}
        <Card className="glass-effect p-8 border-accent/30 glow-quantum">
          <div className="space-y-8">
            <div className="text-center">
              <h3 className="text-3xl font-bold mb-4 text-gradient">
                Estrategia de Expansión Internacional
              </h3>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Roadmap de crecimiento desde dominio nacional hasta liderazgo civilizatorio global
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {internationalExpansion.map((phase, index) => (
                <div 
                  key={phase.region}
                  className="bg-card/40 rounded-xl p-6 border border-border/30 hover:border-accent/50 transition-all duration-300 relative"
                >
                  <div className="absolute -top-3 -left-3 w-8 h-8 rounded-full bg-accent flex items-center justify-center text-background font-bold text-sm">
                    {index + 1}
                  </div>

                  <div className="space-y-3">
                    <Globe2 className="w-8 h-8 text-accent" />
                    <h4 className="text-xl font-bold">{phase.region}</h4>
                    
                    <Badge variant="outline" className="text-accent border-accent/50">
                      {phase.status}
                    </Badge>

                    <div className="space-y-2 text-sm">
                      <div className="flex items-start gap-2 text-muted-foreground">
                        <span className="text-accent">▸</span>
                        <span><strong>Timeline:</strong> {phase.timeline}</span>
                      </div>
                      <div className="flex items-start gap-2 text-muted-foreground">
                        <span className="text-accent">▸</span>
                        <span><strong>Targets:</strong> {phase.targets}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-8 p-6 bg-accent/10 rounded-lg border border-accent/30">
              <p className="text-center text-sm text-muted-foreground">
                <strong className="text-accent">Estrategia de Partners:</strong> TAMV busca reconocimiento 
                institucional, alianzas estratégicas y compradores corporativos/gubernamentales para 
                desplegar la arquitectura en ecosistemas públicos, privados y multilaterales.
              </p>
            </div>
          </div>
        </Card>
      </div>
    </section>
  );
};

export default GlobalUseCases;
