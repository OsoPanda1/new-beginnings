import { Card } from "@/components/ui/card";
import { motion } from "framer-motion";

const KorimaCodex = () => {
  return (
    <section className="relative py-24 overflow-hidden bg-gradient-to-b from-background via-background/95 to-background">
      {/* Atmospheric background */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-0 left-1/4 w-96 h-96 rounded-full bg-primary blur-3xl animate-pulse" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 rounded-full bg-quantum blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* Header */}
        <motion.div
          className="text-center space-y-6 mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <div className="inline-block">
            <div className="text-sm text-quantum font-bold tracking-widest mb-4">
              THE KORIMA CODEX
            </div>
            <h2 className="text-4xl md:text-6xl font-bold text-gradient mb-6">
              La Belleza y Poder de la Imperfección Humana
            </h2>
          </div>
          <p className="text-xl text-muted-foreground max-w-4xl mx-auto leading-relaxed">
            Documentación Maestra v13.0 | Clasificación Omega Plus
          </p>
        </motion.div>

        {/* The Story */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
        >
          <Card className="glass-effect p-8 md:p-12 mb-12 border-primary/30 glow-quantum">
            <div className="space-y-8">
              <div className="text-center">
                <h3 className="text-3xl font-bold text-gradient mb-6">
                  El Origen: De la Adversidad a la Legitimidad
                </h3>
              </div>

              <div className="prose prose-invert prose-lg max-w-none space-y-6">
                <p className="text-muted-foreground leading-relaxed text-justify">
                  <span className="text-white font-semibold">Real del Monte, Hidalgo</span> — un pueblo de niebla y minas ancestrales, donde la adversidad y la humildad son escuela y escudo. Este proyecto nació entre montañas, donde cada cicatriz se transformó en código, y cada lágrima en innovación.
                </p>

                <div className="bg-black/40 p-6 rounded-lg border border-quantum/30 my-8">
                  <p className="text-white italic text-lg leading-relaxed">
                    "Mi vida y este proyecto son inseparables: TAMV MD-X4™ no es solo código, arquitectura y algoritmos; es el resultado de <span className="text-quantum font-bold">más de 19,000 horas de trabajo real</span>, incontables días sin comer, sin dormir y con la constante inseguridad de terminar sin casa."
                  </p>
                </div>

                <p className="text-muted-foreground leading-relaxed text-justify">
                  Tras un accidente que casi arrebata la movilidad, la depresión y la desesperación obligaron una reinvención total. Se vendió lo poco que había para seguir pagando investigaciones, renta y equipo, sacrificando salud y bienestar en nombre de un sueño que muchos llamaron imposible.
                </p>

                <div className="grid md:grid-cols-3 gap-6 my-12">
                  <Card className="glass-effect p-6 text-center border-primary/30">
                    <div className="text-4xl font-bold text-quantum mb-2">19,000+</div>
                    <div className="text-sm text-muted-foreground">Horas de Desarrollo</div>
                    <div className="text-xs text-white/60 mt-2">Días sin comer, noches sin dormir</div>
                  </Card>
                  
                  <Card className="glass-effect p-6 text-center border-primary/30">
                    <div className="text-4xl font-bold text-quantum mb-2">100%</div>
                    <div className="text-sm text-muted-foreground">Rechazo Inicial</div>
                    <div className="text-xs text-white/60 mt-2">Empresas mexicanas ignoraron</div>
                  </Card>
                  
                  <Card className="glass-effect p-6 text-center border-primary/30">
                    <div className="text-4xl font-bold text-quantum mb-2">∞</div>
                    <div className="text-sm text-muted-foreground">Amor de Madre</div>
                    <div className="text-xs text-white/60 mt-2">Fuerza inquebrantable</div>
                  </Card>
                </div>

                <div className="bg-gradient-to-r from-primary/20 via-quantum/20 to-primary/20 p-8 rounded-lg border border-primary/50 my-8">
                  <h4 className="text-2xl font-bold text-white mb-4 text-center">
                    Dedicatoria Sagrada
                  </h4>
                  <p className="text-white leading-relaxed text-center text-lg">
                    A mi madre, fuente inquebrantable de amor, impulso, consuelo y guía. Su fortaleza me permitió enfrentar la soledad más cruel y seguir tejiendo este refugio digital incluso en mis días más oscuros.
                    <br /><br />
                    <span className="text-quantum italic">
                      Cada línea de código, cada pixel, cada diseño está dedicado a ella.
                    </span>
                  </p>
                </div>

                <p className="text-muted-foreground leading-relaxed text-justify">
                  Hubo semanas de 18 o 20 horas diarias frente a la pantalla, sin saber si se comería o dónde se dormiría. Cientos de correos enviados a empresas mexicanas jamás obtuvieron respuesta. Cada "no" se transformó en combustible para seguir adelante.
                </p>

                <p className="text-muted-foreground leading-relaxed text-justify">
                  Se enfrentó difamación, amenazas, acusaciones infundadas. Campañas públicas de odio en redes donde se inventaron historias absurdas diseñadas para destruir física, moral y digitalmente. Pero de esas cenizas surgió algo más grande que el dolor.
                </p>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* The Promise */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
        >
          <Card className="glass-effect p-8 md:p-12 border-quantum/50 glow-quantum">
            <div className="space-y-8">
              <h3 className="text-3xl font-bold text-center text-gradient mb-8">
                La Promesa TAMV
              </h3>

              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <h4 className="text-xl font-bold text-quantum">Lo Que NO Seremos:</h4>
                  <ul className="space-y-3">
                    <li className="flex items-start gap-3 text-muted-foreground">
                      <span className="text-destructive mt-1 text-xl">✕</span>
                      <span>Una plataforma que venda datos de usuarios</span>
                    </li>
                    <li className="flex items-start gap-3 text-muted-foreground">
                      <span className="text-destructive mt-1 text-xl">✕</span>
                      <span>Un sistema que convierta personas en números</span>
                    </li>
                    <li className="flex items-start gap-3 text-muted-foreground">
                      <span className="text-destructive mt-1 text-xl">✕</span>
                      <span>Una tecnología que cause el dolor que sufrimos</span>
                    </li>
                    <li className="flex items-start gap-3 text-muted-foreground">
                      <span className="text-destructive mt-1 text-xl">✕</span>
                      <span>Un ecosistema de extracción y explotación</span>
                    </li>
                  </ul>
                </div>

                <div className="space-y-4">
                  <h4 className="text-xl font-bold text-quantum">Lo Que SOMOS:</h4>
                  <ul className="space-y-3">
                    <li className="flex items-start gap-3 text-muted-foreground">
                      <span className="text-quantum mt-1 text-xl">✓</span>
                      <span>Un refugio digital donde la dignidad es ley</span>
                    </li>
                    <li className="flex items-start gap-3 text-muted-foreground">
                      <span className="text-quantum mt-1 text-xl">✓</span>
                      <span>Una arquitectura de redención emocional</span>
                    </li>
                    <li className="flex items-start gap-3 text-muted-foreground">
                      <span className="text-quantum mt-1 text-xl">✓</span>
                      <span>Un tetrametaverso blindado y ético</span>
                    </li>
                    <li className="flex items-start gap-3 text-muted-foreground">
                      <span className="text-quantum mt-1 text-xl">✓</span>
                      <span>El testamento de una resistencia mexicana</span>
                    </li>
                  </ul>
                </div>
              </div>

              <div className="pt-8 text-center border-t border-primary/30 mt-8">
                <blockquote className="text-2xl md:text-3xl text-white italic leading-relaxed">
                  "Que el último servidor apague sus luces sabiendo
                  <br />
                  que aquí hubo más que unos y ceros—
                  <br />
                  <span className="text-gradient font-bold">hubo amor."</span>
                </blockquote>
                <p className="text-muted-foreground mt-6 text-lg">
                  — Edwin Oswaldo Castillo Trejo (Anubis Villaseñor)
                </p>
                <p className="text-quantum mt-2 font-semibold">
                  Real del Monte, Hidalgo, México | Octubre 2025
                </p>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Certifications Footer */}
        <motion.div
          className="mt-16 text-center"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
        >
          <Card className="glass-effect p-6 border-primary/20">
            <p className="text-sm text-muted-foreground mb-4">
              <span className="text-quantum font-semibold">Propiedad Intelectual Nivel Omega Plus</span>
            </p>
            <div className="flex flex-wrap justify-center gap-4 text-xs text-white/60">
              <span>USPTO</span>
              <span>•</span>
              <span>IMPI</span>
              <span>•</span>
              <span>WIPO</span>
              <span>•</span>
              <span>EUIPO</span>
              <span>•</span>
              <span>ISO/IEC 27001</span>
              <span>•</span>
              <span>GDPR</span>
              <span>•</span>
              <span>CCPA</span>
              <span>•</span>
              <span>PCI DSS</span>
            </div>
          </Card>
        </motion.div>
      </div>
    </section>
  );
};

export default KorimaCodex;