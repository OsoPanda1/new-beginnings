import { Card } from "@/components/ui/card";
import { Code, Database, Shield, Zap } from "lucide-react";

const techCategories = [
  {
    title: "Frontend",
    icon: Code,
    technologies: [
      "React 18 + TypeScript",
      "Redux Toolkit + RTK Query",
      "TailwindCSS + Framer Motion",
      "Three.js + React Three Fiber",
    ],
  },
  {
    title: "Backend",
    icon: Database,
    technologies: [
      "Rust, Go, Python",
      "RESTful + gRPC + GraphQL",
      "Apache Kafka + Redis Streams",
      "Kubernetes 1.28",
    ],
  },
  {
    title: "Blockchain",
    icon: Zap,
    technologies: [
      "Hyperledger Fabric 2.5+",
      "Arbitrum/OP Stack (L2)",
      "20,000 TPS (L1) + 100,000 TPS (L2)",
      "Solidity + Go Smart Contracts",
    ],
  },
  {
    title: "Seguridad",
    icon: Shield,
    technologies: [
      "Criptografía Post-Cuántica",
      "Zero Trust Architecture",
      "ISO 27001 + SOC 2 Type II",
      "Biometría Cancelable",
    ],
  },
];

const TechStack = () => {
  return (
    <section className="relative py-24">
      <div className="container mx-auto px-4">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-gradient">Stack Tecnológico</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Arquitectura de vanguardia con resistencia cuántica y escalabilidad enterprise
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {techCategories.map((category, index) => {
            const Icon = category.icon;
            return (
              <Card
                key={category.title}
                className="glass-effect p-6 space-y-4 hover:glow-quantum transition-all duration-300 border-border/50"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <h3 className="text-xl font-bold">{category.title}</h3>
                </div>

                <ul className="space-y-2">
                  {category.technologies.map((tech) => (
                    <li
                      key={tech}
                      className="text-sm text-muted-foreground flex items-start gap-2"
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 flex-shrink-0" />
                      <span>{tech}</span>
                    </li>
                  ))}
                </ul>
              </Card>
            );
          })}
        </div>

        {/* Architecture Diagram */}
        <div className="mt-16 glass-effect rounded-2xl p-8 border-border/50">
          <h3 className="text-2xl font-bold mb-6 text-center">Arquitectura de Capas</h3>
          <div className="grid gap-4">
            {[
              { layer: "Presentación", items: ["Web App", "Mobile", "API Gateway", "HyperRender Viewer"] },
              { layer: "Aplicación", items: ["Microservicios K8s", "Auth Service", "Identity Service", "Blockchain Gateway"] },
              { layer: "Lógica de Negocio", items: ["Isabella AI", "TAMV Economic Engine", "Governance Service", "CDN"] },
              { layer: "Datos", items: ["PostgreSQL Cluster", "MongoDB Sharded", "Redis Cache", "IPFS/Arweave"] },
              { layer: "Blockchain", items: ["Hyperledger Fabric", "Ethereum L2", "ID-NVIDA Registry", "TAMV Ledger"] },
            ].map((layer, index) => (
              <div
                key={layer.layer}
                className="bg-card/30 rounded-xl p-4 border border-border/30 hover:border-primary/50 transition-colors duration-300"
              >
                <div className="flex items-center gap-4">
                  <div className="font-bold text-primary min-w-[140px]">{layer.layer}</div>
                  <div className="flex-1 flex flex-wrap gap-2">
                    {layer.items.map((item) => (
                      <span
                        key={item}
                        className="px-3 py-1 bg-muted/30 rounded-full text-xs text-muted-foreground"
                      >
                        {item}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default TechStack;
