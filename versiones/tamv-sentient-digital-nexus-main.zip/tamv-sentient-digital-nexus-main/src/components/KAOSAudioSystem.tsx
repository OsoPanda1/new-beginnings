// components/KAOSAudioSystem.tsx
import { useState } from "react";
import ConciertosHolograficos from "./KAOS/ConciertosHolograficos";
import BibliotecaSonora from "./KAOS/BibliotecaSonora";
import CreacionMusical from "./KAOS/CreacionMusical";
import ArbolSaber from "./KAOS/ArbolSaber";
import MarketplaceSabiduria from "./KAOS/MarketplaceSabiduria";
import SalasSabiduria from "./KAOS/SalasSabiduria";
import CertificacionesBlockchain from "./KAOS/CertificacionesBlockchain";
import EstudioMultidimensional from "./KAOS/EstudioMultidimensional";
import CompositorSinaptico from "./KAOS/CompositorSinaptico";
import IAColaborativa from "./KAOS/IAColaborativa";
import FlujoUniversal from "./KAOS/FlujoUniversal";
import NexoOnirico from "./KAOS/NexoOnirico";

const KAOSAudioSystem = () => {
  const [activeModule, setActiveModule] = useState("conciertos");

  const modules = [
    { id: "conciertos", name: "🎭 Conciertos Holográficos", icon: "🎭" },
    { id: "biblioteca", name: "📚 Biblioteca Sonora", icon: "📚" },
    { id: "creacion", name: "🎼 Creación Musical", icon: "🎼" },
    { id: "arbol", name: "🌌 Árbol del Saber", icon: "🌌" },
    { id: "marketplace", name: "🌉 Marketplace Sabiduría", icon: "🌉" },
    { id: "salas", name: "📚 Salas de Sabiduría", icon: "📚" },
    { id: "certificaciones", name: "🎓 Certificaciones", icon: "🎓" },
    { id: "estudio", name: "🎨 Estudio Multidimensional", icon: "🎨" },
    { id: "compositor", name: "🧠 Compositor Sináptico", icon: "🧠" },
    { id: "ia", name: "👻 IA Colaborativa", icon: "👻" },
    { id: "flujo", name: "🌊 Flujo Universal", icon: "🌊" },
    { id: "onirico", name: "💫 Nexo Onírico", icon: "💫" }
  ];

  const renderActiveModule = () => {
    switch (activeModule) {
      case "conciertos": return <ConciertosHolograficos />;
      case "biblioteca": return <BibliotecaSonora />;
      case "creacion": return <CreacionMusical />;
      case "arbol": return <ArbolSaber />;
      case "marketplace": return <MarketplaceSabiduria />;
      case "salas": return <SalasSabiduria />;
      case "certificaciones": return <CertificacionesBlockchain />;
      case "estudio": return <EstudioMultidimensional />;
      case "compositor": return <CompositorSinaptico />;
      case "ia": return <IAColaborativa />;
      case "flujo": return <FlujoUniversal />;
      case "onirico": return <NexoOnirico />;
      default: return <ConciertosHolograficos />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header KAOS */}
      <div className="text-center py-8">
        <h1 className="text-5xl font-bold text-crystal-glow mb-4">
          🎵 KAOS Audio System
        </h1>
        <p className="text-xl text-crystal-lowgreen">
          Plataforma de Audio Multidimensional - TAMV MD-X4
        </p>
      </div>

      {/* Navegación de Módulos */}
      <div className="flex overflow-x-auto space-x-2 px-4 py-4 mb-8">
        {modules.map((module) => (
          <button
            key={module.id}
            onClick={() => setActiveModule(module.id)}
            className={`flex items-center space-x-2 px-4 py-3 rounded-xl transition-all duration-300 whitespace-nowrap ${
              activeModule === module.id
                ? "bg-crystal-glow/20 border border-crystal-glow/40 text-crystal-glow"
                : "bg-black/30 border border-crystal-glow/20 text-crystal-lowgreen hover:bg-crystal-glow/10"
            }`}
          >
            <span className="text-xl">{module.icon}</span>
            <span className="font-medium">{module.name}</span>
          </button>
        ))}
      </div>

      {/* Contenido del Módulo Activo */}
      <div className="container mx-auto px-4 pb-16">
        {renderActiveModule()}
      </div>
    </div>
  );
};

export default KAOSAudioSystem;
