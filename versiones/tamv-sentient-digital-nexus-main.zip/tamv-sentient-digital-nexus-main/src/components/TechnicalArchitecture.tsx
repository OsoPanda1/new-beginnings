import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Shield, Cpu, Network, Lock, Brain, Zap } from "lucide-react";

const architectureLayers = [
  {
    name: "Capa de Identidad Soberana",
    icon: Shield,
    color: "quantum",
    components: [
      {
        name: "ID-NVIDA™ Protocol",
        specs: "Biometría Cancelable + Post-Quantum Crypto",
        throughput: "100,000 auth/sec",
        security: "CRYSTALS-Dilithium + Kyber-1024"
      },
      {
        name: "DID Registry",
        specs: "W3C Compliant + Blockchain Anchoring",
        throughput: "50,000 DIDs/sec",
        security: "Hybrid ECDSA + PQC"
      }
    ]
  },
  {
    name: "Capa de Inteligencia Sentiente",
    icon: Brain,
    color: "primary",
    components: [
      {
        name: "ISABELLA AI™ Core",
        specs: "Emotional Intelligence + Ethical Validation",
        throughput: "10,000 interactions/sec",
        security: "Federated Learning + Differential Privacy"
      },
      {
        name: "DEKATEOTL Governance",
        specs: "4-Layer Ethical Decision System",
        throughput: "5,000 proposals/hour",
        security: "Immutable Audit Trail"
      }
    ]
  },
  {
    name: "Capa de Seguridad Multisensorial",
    icon: Lock,
    color: "accent",
    components: [
      {
        name: "ANUBIS SENTINEL™",
        specs: "Quantum Hybrid Security + Zero Trust",
        throughput: "1M+ events/sec monitored",
        security: "AES-256-GCM + Post-Quantum KEM"
      },
      {
        name: "Threat Intelligence",
        specs: "AI-Powered Anomaly Detection",
        throughput: "Real-time correlation",
        security: "Homomorphic Encryption"
      }
    ]
  },
  {
    name: "Capa Económica Ética",
    icon: Zap,
    color: "secondary",
    components: [
      {
        name: "CATTLEYA™ Engine",
        specs: "4D Economic Modeling + DAO Governance",
        throughput: "20,000 TPS (L1) + 100,000 TPS (L2)",
        security: "Byzantine Fault Tolerance"
      },
      {
        name: "TAMV Coins",
        specs: "Utility + Governance + Fair Valuation",
        throughput: "Cross-chain Interoperability",
        security: "Multi-Sig + Time-Locks"
      }
    ]
  },
  {
    name: "Capa de Renderizado Inmersivo",
    icon: Cpu,
    color: "quantum",
    components: [
      {
        name: "HyperRender 4D™",
        specs: "Quantum-Enhanced Ray Tracing",
        throughput: "8K @ 120fps + Temporal AA",
        security: "Deepfake Detection + Content Integrity"
      },
      {
        name: "KAOS™ Audio 3D",
        specs: "Spatial Audio + Emotional Resonance",
        throughput: "512 audio objects simultaneous",
        security: "Audio Watermarking"
      }
    ]
  },
  {
    name: "Capa de Interoperabilidad",
    icon: Network,
    color: "primary",
    components: [
      {
        name: "API Gateway Mesh",
        specs: "REST + gRPC + GraphQL + WebSocket",
        throughput: "50,000 req/sec sustained",
        security: "OAuth 2.1 + OIDC + SIWE"
      },
      {
        name: "Blockchain Bridge",
        specs: "Multi-Chain Relay Network",
        throughput: "Cross-chain atomic swaps",
        security: "Merkle Proof Verification"
      }
    ]
  }
];

const quantumSpecs = {
  current: {
    title: "Criptografía Clásica (2025)",
    algorithms: ["ECDSA P-384", "RSA-4096", "AES-256-GCM", "X25519"]
  },
  hybrid: {
    title: "Fase Híbrida (Q2 2026)",
    algorithms: ["ECDSA + Dilithium", "AES-256 + Kyber-1024", "X25519 + Kyber KEM"]
  },
  postQuantum: {
    title: "Post-Cuántico Completo (2027+)",
    algorithms: ["CRYSTALS-Dilithium", "Kyber-1024", "SPHINCS+", "NTRU Prime"]
  }
};

const TechnicalArchitecture = () => {
  return (
    <section className="relative py-24 overflow-hidden" id="arquitectura-tecnica">
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-0 left-1/4 w-96 h-96 rounded-full bg-quantum blur-3xl animate-pulse" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 rounded-full bg-primary blur-3xl animate-pulse" style={{ animationDelay: '2s' }} />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center space-y-4 mb-16">
          <Badge variant="outline" className="text-quantum border-quantum/50">
            World Economic Forum Validated Architecture
          </Badge>
          <h2 className="text-gradient">Arquitectura Técnica Modular</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Infraestructura soberana certificada para interacción humano-máquina ética, 
            con resiliencia cuántica y gobernanza institucional
          </p>
        </div>

        {/* Architecture Layers */}
        <div className="space-y-8 mb-16">
          {architectureLayers.map((layer, index) => {
            const Icon = layer.icon;
            return (
              <Card 
                key={layer.name}
                className="glass-effect border-border/50 overflow-hidden hover:glow-quantum transition-all duration-500"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="p-6 space-y-6">
                  {/* Layer Header */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div 
                        className="w-12 h-12 rounded-xl flex items-center justify-center"
                        style={{ backgroundColor: `hsl(var(--${layer.color}) / 0.2)` }}
                      >
                        <Icon 
                          className="w-6 h-6"
                          style={{ color: `hsl(var(--${layer.color}))` }}
                        />
                      </div>
                      <h3 className="text-2xl font-bold">{layer.name}</h3>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      Layer {index + 1}/6
                    </Badge>
                  </div>

                  {/* Components Grid */}
                  <div className="grid md:grid-cols-2 gap-4">
                    {layer.components.map((component) => (
                      <div 
                        key={component.name}
                        className="bg-card/30 rounded-lg p-4 border border-border/30 hover:border-primary/50 transition-colors duration-300"
                      >
                        <h4 className="font-bold text-lg mb-2 text-primary">{component.name}</h4>
                        <div className="space-y-2 text-sm text-muted-foreground">
                          <div className="flex items-start gap-2">
                            <span className="text-quantum">▸</span>
                            <span><strong>Specs:</strong> {component.specs}</span>
                          </div>
                          <div className="flex items-start gap-2">
                            <span className="text-quantum">▸</span>
                            <span><strong>Performance:</strong> {component.throughput}</span>
                          </div>
                          <div className="flex items-start gap-2">
                            <span className="text-quantum">▸</span>
                            <span><strong>Security:</strong> {component.security}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </Card>
            );
          })}
        </div>

        {/* Quantum Resistance Evolution */}
        <Card className="glass-effect p-8 border-quantum/30 glow-quantum">
          <h3 className="text-3xl font-bold mb-8 text-center text-gradient">
            Evolución de Resistencia Cuántica
          </h3>
          
          <div className="grid md:grid-cols-3 gap-6">
            {Object.entries(quantumSpecs).map(([key, phase], index) => (
              <div 
                key={key}
                className="bg-card/40 rounded-xl p-6 border border-border/30 hover:border-quantum/50 transition-all duration-300"
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Badge variant="outline" className="text-quantum border-quantum/50">
                      Fase {index + 1}
                    </Badge>
                    {index === 2 && (
                      <Badge className="bg-quantum text-background">
                        Objetivo
                      </Badge>
                    )}
                  </div>
                  
                  <h4 className="text-xl font-bold">{phase.title}</h4>
                  
                  <ul className="space-y-2">
                    {phase.algorithms.map((algo) => (
                      <li key={algo} className="flex items-start gap-2 text-sm text-muted-foreground">
                        <span className="w-1.5 h-1.5 rounded-full bg-quantum mt-1.5 flex-shrink-0" />
                        <span>{algo}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-8 p-6 bg-quantum/10 rounded-lg border border-quantum/30">
            <p className="text-center text-sm text-muted-foreground">
              <strong className="text-quantum">Resistencia Cuántica Gradual:</strong> Migración progresiva 
              desde criptografía clásica hacia algoritmos post-cuánticos certificados por NIST, 
              garantizando seguridad a largo plazo contra computadoras cuánticas.
            </p>
          </div>
        </Card>
      </div>
    </section>
  );
};

export default TechnicalArchitecture;
