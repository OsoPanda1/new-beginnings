// tamv-icons.tsx
import * as React from "react";

// Iconos: cada uno puede recibir color, tamaño y props

export const IconProfile = (props) => (
  <svg viewBox="0 0 24 24" width={props.size||24} height={props.size||24} {...props}>
    <circle cx="12" cy="8" r="5" fill="#32eaf8"/>
    <ellipse cx="12" cy="17" rx="8" ry="5" fill="#adefff"/>
    <circle cx="12" cy="12" r="10" stroke="#32eaf8" fill="none"/>
  </svg>
);

export const IconUniversity = (props) => (
  <svg viewBox="0 0 24 24" width={props.size||24} height={props.size||24} {...props}>
    <rect x="3" y="7" width="18" height="10" rx="3" fill="#fff"/>
    <polygon points="12,3 2,7 22,7" fill="#48fff2"/>
    <rect x="8" y="11" width="8" height="2" fill="#b7afff"/>
  </svg>
);

export const IconMenu = (props) => (
  <svg width={props.size||24} height={props.size||24} viewBox="0 0 24 24" {...props}>
    <rect x="3" y="6" width="18" height="2" fill="#a1f8fc"/>
    <rect x="3" y="11" width="18" height="2" fill="#28eaf8"/>
    <rect x="3" y="16" width="18" height="2" fill="#b7afff"/>
  </svg>
);

export const IconDreamSpaces = (props) => (
  <svg width={props.size||24} height={props.size||24} viewBox="0 0 24 24" {...props}>
    <ellipse cx="12" cy="12" rx="9" ry="6" fill="#ebdafd"/>
    <ellipse cx="12" cy="14" rx="5" ry="2" fill="#bc7afe"/>
    <path d="M6,18 Q12,22 18,18" stroke="#48fff2" fill="none"/>
  </svg>
);

export const IconMembership = (props) => (
  <svg width={props.size||24} height={props.size||24} viewBox="0 0 24 24" {...props}>
    <circle cx="12" cy="12" r="10" fill="#fff1e4"/>
    <path d="M7,12 Q12,18 17,12" stroke="#ffb3fa" strokeWidth="2" fill="none"/>
    <rect x="9" y="6" width="6" height="4" fill="#bc7afe"/>
  </svg>
);

export const IconSettings = (props) => (
  <svg width={props.size||24} height={props.size||24} viewBox="0 0 24 24" {...props}>
    <circle cx="12" cy="12" r="10" stroke="#48fff2" fill="none"/>
    <path d="M8,12 a4,4 0 1,0 8,0 a4,4 0 1,0 -8,0" fill="#bc7afe"/>
    <circle cx="12" cy="12" r="2" fill="#fff"/>
  </svg>
);

export const IconAnubisSentinel = (props) => (
  <svg width={props.size||24} height={props.size||24} viewBox="0 0 24 24" {...props}>
    <ellipse cx="12" cy="14" rx="8" ry="3" fill="#bc7afe"/>
    <polygon points="7,7 12,2 17,7" fill="#48fff2"/>
    <rect x="10" y="7" width="4" height="7" fill="#a1f8fc"/>
    <ellipse cx="12" cy="19" rx="4" ry="1.5" fill="#e8d7ff"/>
  </svg>
);

export const IconMarketplace = (props) => (
  <svg width={props.size||24} height={props.size||24} viewBox="0 0 24 24" {...props}>
    <rect x="3" y="8" width="18" height="8" rx="3" fill="#b7afff"/>
    <ellipse cx="12" cy="10" rx="9" ry="3" fill="#32eaf8"/>
    <rect x="9" y="16" width="6" height="2" fill="#28eaf8"/>
  </svg>
);

export const IconChats = (props) => (
  <svg width={props.size||24} height={props.size||24} viewBox="0 0 24 24" {...props}>
    <ellipse cx="12" cy="15" rx="9" ry="6" fill="#fff"/>
    <rect x="7" y="8" width="10" height="5" rx="2" fill="#48fff2"/>
    <ellipse cx="12" cy="12" rx="8" ry="5" fill="none" stroke="#bc7afe"/>
  </svg>
);

export const IconGroups = (props) => (
  <svg width={props.size||24} height={props.size||24} viewBox="0 0 24 24" {...props}>
    <ellipse cx="7" cy="17" rx="3" ry="2" fill="#48fff2"/>
    <ellipse cx="17" cy="17" rx="3" ry="2" fill="#a1f8fc"/>
    <ellipse cx="12" cy="13" rx="5" ry="3" fill="#bc7afe"/>
    <ellipse cx="12" cy="8" rx="2" ry="2" fill="#fff"/>
  </svg>
);

export const IconChannels = (props) => (
  <svg width={props.size||24} height={props.size||24} viewBox="0 0 24 24" {...props}>
    <rect x="5" y="7" width="14" height="3" fill="#bc7afe"/>
    <rect x="8" y="12" width="8" height="3" fill="#48fff2"/>
    <rect x="10" y="17" width="4" height="2" fill="#b7afff"/>
  </svg>
);

export const IconPosts = (props) => (
  <svg width={props.size||24} height={props.size||24} viewBox="0 0 24 24" {...props}>
    <rect x="4" y="5" width="16" height="4" fill="#32eaf8"/>
    <rect x="4" y="11" width="16" height="4" fill="#b7afff"/>
    <rect x="4" y="17" width="10" height="2" fill="#bc7afe"/>
  </svg>
);

export const IconVideocall = (props) => (
  <svg width={props.size||24} height={props.size||24} viewBox="0 0 24 24" {...props}>
    <rect x="4" y="8" width="12" height="8" rx="3" fill="#fff"/>
    <polygon points="16,8 20,12 16,16" fill="#48fff2"/>
    <ellipse cx="10" cy="13" rx="2" ry="2" fill="#bc7afe"/>
  </svg>
);

export const IconVideos = (props) => (
  <svg width={props.size||24} height={props.size||24} viewBox="0 0 24 24" {...props}>
    <rect x="6" y="6" width="12" height="12" rx="4" fill="#b7afff"/>
    <polygon points="11,10 16,12 11,14" fill="#32eaf8"/>
  </svg>
);

export const IconGallery = (props) => (
  <svg width={props.size||24} height={props.size||24} viewBox="0 0 24 24" {...props}>
    <rect x="3" y="7" width="18" height="10" rx="3" fill="#e8d7ff"/>
    <circle cx="8" cy="12" r="2" fill="#48fff2"/>
    <ellipse cx="16" cy="14" rx="3" ry="2" fill="#bc7afe"/>
  </svg>
);

export const IconWishlist = (props) => (
  <svg width={props.size||24} height={props.size||24} viewBox="0 0 24 24" {...props}>
    <path d="M12 19 Q8 15 5 11 Q11 5 12 11 Q13 5 19 11 Q16 15 12 19Z" fill="#ffb3fa"/>
  </svg>
);

export const IconStreaming = (props) => (
  <svg width={props.size||24} height={props.size||24} viewBox="0 0 24 24" {...props}>
    <ellipse cx="12" cy="12" rx="9" ry="5" fill="#32eaf8"/>
    <rect x="9" y="9" width="6" height="3" fill="#bc7afe"/>
    <rect x="11" y="14" width="2" height="4" fill="#a1f8fc"/>
  </svg>
);

export const IconArtGallery = (props) => (
  <svg width={props.size||24} height={props.size||24} viewBox="0 0 24 24" {...props}>
    <rect x="5" y="7" width="14" height="10" rx="3" fill="#bc7afe"/>
    <circle cx="12" cy="13" r="2.5" fill="#ffb3fa"/>
    <ellipse cx="9" cy="15" rx="1.5" ry="1" fill="#48fff2"/>
  </svg>
);

export const IconAuctions = (props) => (
  <svg width={props.size||24} height={props.size||24} viewBox="0 0 24 24" {...props}>
    <rect x="4" y="6" width="7" height="12" rx="2.5" fill="#ffb3fa"/>
    <rect x="13" y="8" width="7" height="10" rx="3" fill="#bc7afe"/>
    <circle cx="7.5" cy="12" r="2" fill="#48fff2"/>
    <circle cx="16.5" cy="13" r="2" fill="#a1f8fc"/>
  </svg>
);

export const IconConcerts = (props) => (
  <svg width={props.size||24} height={props.size||24} viewBox="0 0 24 24" {...props}>
    <ellipse cx="12" cy="18" rx="8" ry="3" fill="#bc7afe"/>
    <circle cx="12" cy="9" r="5" fill="#48fff2"/>
    <rect x="9" y="10" width="6" height="6" fill="#b7afff"/>
  </svg>
);

export const IconDonations = (props) => (
  <svg width={props.size||24} height={props.size||24} viewBox="0 0 24 24" {...props}>
    <rect x="7" y="8" width="10" height="6" rx="3" fill="#adefff"/>
    <ellipse cx="12" cy="12" rx="7" ry="4" fill="#ffb3fa"/>
    <rect x="11" y="14" width="2" height="5" fill="#bc7afe"/>
  </svg>
);

export const IconLike = (props) => (
  <svg width={props.size||24} height={props.size||24} viewBox="0 0 24 24" {...props}>
    <path d="M12,20 Q8,16 5,12 Q11,6 12,12 Q13,6 19,12 Q16,16 12,20Z" fill="#ffb3fa"/>
  </svg>
);

export const IconComment = (props) => (
  <svg width={props.size||24} height={props.size||24} viewBox="0 0 24 24" {...props}>
    <ellipse cx="12" cy="16" rx="8" ry="4" fill="#bc7afe"/>
    <rect x="7" y="10" width="10" height="5" rx="2" fill="#fff"/>
    <ellipse cx="12" cy="12" rx="7" ry="3" fill="none" stroke="#28eaf8"/>
  </svg>
);

export const IconMonetization = (props) => (
  <svg width={props.size||24} height={props.size||24} viewBox="0 0 24 24" {...props}>
    <circle cx="12" cy="12" r="10" fill="#b7afff"/>
    <rect x="7" y="8" width="10" height="8" rx="3" fill="#fff1e4"/>
    <text x="12" y="15" fontSize="6" textAnchor="middle" fill="#bc7afe">$</text>
  </svg>
);

export const IconIdNvidia = (props) => (
  <svg width={props.size||24} height={props.size||24} viewBox="0 0 24 24" {...props}>
    <rect x="3" y="7" width="18" height="10" rx="3" fill="#32eaf8"/>
    <ellipse cx="12" cy="12" rx="4" ry="3" fill="#b7afff"/>
    <text x="12" y="14" fontSize="6" textAnchor="middle" fill="#bc7afe">ID</text>
  </svg>
);

export const IconAlert = (props) => (
  <svg width={props.size||24} height={props.size||24} viewBox="0 0 24 24" {...props}>
    <polygon points="12,4 22,19 2,19" fill="#ffb3fa"/>
    <rect x="11" y="9" width="2" height="5" fill="#fff"/>
    <circle cx="12" cy="17" r="1" fill="#bc7afe"/>
  </svg>
);

export const IconError = (props) => (
  <svg width={props.size||24} height={props.size||24} viewBox="0 0 24 24" {...props}>
    <circle cx="12" cy="12" r="10" fill="#ffb3fa"/>
    <rect x="10" y="7" width="4" height="8" fill="#fff"/>
    <rect x="10" y="17" width="4" height="2" fill="#bc7afe"/>
  </svg>
);

export const IconNotify = (props) => (
  <svg width={props.size||24} height={props.size||24} viewBox="0 0 24 24" {...props}>
    <rect x="6" y="8" width="12" height="8" rx="4" fill="#32eaf8"/>
    <ellipse cx="12" cy="18" rx="7" ry="3" fill="#b7afff"/>
    <rect x="11" y="11" width="2" height="5" fill="#bc7afe"/>
  </svg>
);
