import { useState } from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const IAColaborativa = () => {
  const [activeAIs, setActiveAIs] = useState(3);

  const aiCollaborators = [
    {
      id: 1,
      name: "Isabella Prime",
      specialty: "Composición Melódica",
      status: "activa",
      contribution: 34,
    },
    {
      id: 2,
      name: "Harmony Neural",
      specialty: "Armonización Avanzada",
      status: "activa",
      contribution: 28,
    },
    {
      id: 3,
      name: "Rhythm Quantum",
      specialty: "Patrones Rítmicos",
      status: "activa",
      contribution: 22,
    },
    {
      id: 4,
      name: "Timbre Synth",
      specialty: "Diseño de Sonido",
      status: "disponible",
      contribution: 0,
    },
  ];

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h2 className="text-4xl font-bold text-gradient-crystal mb-4">
          👻 IA Colaborativa
        </h2>
        <p className="text-crystal-lowgreen text-lg">
          Múltiples IAs trabajando juntas en tu proyecto musical
        </p>
      </motion.div>

      <div className="grid md:grid-cols-2 gap-8">
        <Card className="glass-effect p-6 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-2xl font-bold text-crystal-glow">
              Equipo Activo
            </h3>
            <Badge className="bg-green-500/20 text-green-400">
              {activeAIs} IAs colaborando
            </Badge>
          </div>

          <div className="space-y-3">
            {aiCollaborators.map((ai, index) => (
              <motion.div
                key={ai.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card 
                  className={`p-4 ${
                    ai.status === "activa"
                      ? "bg-gradient-crystal/10 border-crystal-glow/30"
                      : "bg-black/40 border-crystal-glow/10"
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-3 h-3 rounded-full ${
                          ai.status === "activa"
                            ? "bg-green-400 animate-pulse"
                            : "bg-gray-500"
                        }`}
                      />
                      <h4 className="font-bold text-crystal-lowgreen">
                        {ai.name}
                      </h4>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {ai.status}
                    </Badge>
                  </div>
                  
                  <p className="text-sm text-muted-foreground mb-2">
                    {ai.specialty}
                  </p>
                  
                  {ai.contribution > 0 && (
                    <div className="mt-3">
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-crystal-lowgreen">Contribución</span>
                        <span className="text-crystal-glow">{ai.contribution}%</span>
                      </div>
                      <div className="h-1.5 bg-black/40 rounded-full overflow-hidden">
                        <motion.div
                          className="h-full bg-gradient-crystal"
                          initial={{ width: 0 }}
                          animate={{ width: `${ai.contribution}%` }}
                          transition={{ duration: 1, delay: index * 0.1 }}
                        />
                      </div>
                    </div>
                  )}
                </Card>
              </motion.div>
            ))}
          </div>

          <Button className="w-full bg-gradient-crystal">
            ➕ Agregar IA al Proyecto
          </Button>
        </Card>

        <Card className="glass-effect p-6 space-y-6">
          <h3 className="text-2xl font-bold text-crystal-glow">
            Sincronización en Tiempo Real
          </h3>

          <div className="aspect-square bg-black/60 rounded-lg border-2 border-crystal-glow/30 relative overflow-hidden flex items-center justify-center">
            <motion.div
              className="text-8xl"
              animate={{
                scale: [1, 1.2, 1],
                rotate: [0, 360],
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            >
              🔮
            </motion.div>
            
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              {[0, 1, 2].map((i) => (
                <motion.div
                  key={i}
                  className="absolute w-full h-full border-2 border-crystal-glow/20 rounded-full"
                  animate={{
                    scale: [1, 2, 1],
                    opacity: [0.5, 0, 0.5],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    delay: i * 1,
                  }}
                />
              ))}
            </div>
          </div>

          <Card className="bg-black/40 p-4 border-crystal-glow/20">
            <h4 className="text-sm font-bold text-crystal-lowgreen mb-3">
              Actividad Colaborativa:
            </h4>
            <div className="space-y-2 text-xs text-muted-foreground">
              <p>• Isabella Prime está componiendo la melodía principal</p>
              <p>• Harmony Neural está añadiendo capas armónicas</p>
              <p>• Rhythm Quantum está optimizando el groove</p>
            </div>
          </Card>

          <div className="grid grid-cols-2 gap-4 text-center">
            <div className="bg-black/40 p-4 rounded-lg">
              <div className="text-2xl font-bold text-gradient-crystal mb-1">
                847
              </div>
              <p className="text-xs text-crystal-lowgreen">Iteraciones</p>
            </div>
            <div className="bg-black/40 p-4 rounded-lg">
              <div className="text-2xl font-bold text-gradient-crystal mb-1">
                94%
              </div>
              <p className="text-xs text-crystal-lowgreen">Coherencia</p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default IAColaborativa;
