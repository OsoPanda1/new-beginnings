import { useState } from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const CompositorSinaptico = () => {
  const [activeNeurons, setActiveNeurons] = useState(47);
  const [synapticActivity, setSynapticActivity] = useState(78);

  const neuralPatterns = [
    { id: 1, name: "Patrón Alpha", frequency: "8-13 Hz", mood: "Relajación" },
    { id: 2, name: "Patrón Beta", frequency: "13-30 Hz", mood: "Concentración" },
    { id: 3, name: "Patrón Gamma", frequency: "30-100 Hz", mood: "Consciencia" },
    { id: 4, name: "Patrón Theta", frequency: "4-8 Hz", mood: "Creatividad" },
  ];

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h2 className="text-4xl font-bold text-gradient-crystal mb-4">
          🧠 Compositor Sináptico
        </h2>
        <p className="text-crystal-lowgreen text-lg">
          Música que imita patrones neuronales - La sinfonía de tu mente
        </p>
      </motion.div>

      <div className="grid md:grid-cols-2 gap-8">
        <Card className="glass-effect p-6 space-y-6">
          <h3 className="text-2xl font-bold text-crystal-glow">
            Red Neural Activa
          </h3>
          
          <div className="aspect-square bg-black/60 rounded-lg border-2 border-crystal-glow/30 relative overflow-hidden flex items-center justify-center">
            {[...Array(20)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-3 h-3 bg-crystal-glow rounded-full"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                }}
                animate={{
                  scale: [1, 1.5, 1],
                  opacity: [0.3, 1, 0.3],
                }}
                transition={{
                  duration: Math.random() * 3 + 2,
                  repeat: Infinity,
                  delay: Math.random() * 2,
                }}
              />
            ))}
            
            <div className="text-center z-10">
              <div className="text-6xl mb-4">🧠</div>
              <div className="text-crystal-lowgreen font-bold">
                {activeNeurons} neuronas activas
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-crystal-lowgreen">Actividad Sináptica</span>
                <span className="text-crystal-glow">{synapticActivity}%</span>
              </div>
              <div className="h-2 bg-black/40 rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-crystal"
                  animate={{ width: `${synapticActivity}%` }}
                  transition={{ duration: 1 }}
                />
              </div>
            </div>
          </div>
        </Card>

        <Card className="glass-effect p-6 space-y-6">
          <h3 className="text-2xl font-bold text-crystal-glow">
            Patrones Neuronales
          </h3>
          
          <div className="space-y-3">
            {neuralPatterns.map((pattern, index) => (
              <motion.div
                key={pattern.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="bg-black/40 p-4 border-crystal-glow/20 hover:border-crystal-glow/50 transition-all duration-300 cursor-pointer">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-bold text-crystal-lowgreen">
                      {pattern.name}
                    </h4>
                    <span className="text-xs text-muted-foreground">
                      {pattern.frequency}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Estado: {pattern.mood}
                  </p>
                </Card>
              </motion.div>
            ))}
          </div>

          <Button className="w-full bg-gradient-crystal">
            🎵 Generar Composición Neural
          </Button>

          <Card className="bg-black/40 p-4 border-crystal-glow/20">
            <p className="text-sm text-crystal-lowgreen mb-2">
              <strong>Isabella AI:</strong>
            </p>
            <p className="text-xs text-muted-foreground">
              "Detecto un patrón Beta predominante. Tu música reflejará 
              un estado de alta concentración y claridad mental. 
              Perfecto para trabajo creativo profundo."
            </p>
          </Card>
        </Card>
      </div>
    </div>
  );
};

export default CompositorSinaptico;
