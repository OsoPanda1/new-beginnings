import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const NexoOnirico = () => {
  const [dreamState, setDreamState] = useState("REM");
  const [visualizing, setVisualizing] = useState(false);

  const dreamStates = [
    { id: "NREM1", name: "Somnolencia", wave: "Theta", color: "blue" },
    { id: "NREM2", name: "Sueño Ligero", wave: "Spindles", color: "cyan" },
    { id: "NREM3", name: "Sueño Profundo", wave: "Delta", color: "purple" },
    { id: "REM", name: "Sueño REM", wave: "Mixed", color: "pink" },
  ];

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h2 className="text-4xl font-bold text-gradient-crystal mb-4">
          💫 Nexo Onírico
        </h2>
        <p className="text-crystal-lowgreen text-lg">
          Música generada desde tus sueños - El puente entre consciente e inconsciente
        </p>
      </motion.div>

      <div className="grid md:grid-cols-3 gap-6">
        {dreamStates.map((state, index) => (
          <motion.div
            key={state.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card
              onClick={() => setDreamState(state.id)}
              className={`glass-effect p-6 cursor-pointer transition-all duration-300 ${
                dreamState === state.id
                  ? "border-crystal-glow/50 glow-crystal"
                  : "border-crystal-glow/20 hover:border-crystal-glow/30"
              }`}
            >
              <div className="text-center space-y-3">
                <div className="text-4xl">😴</div>
                <h3 className="text-lg font-bold text-crystal-glow">
                  {state.name}
                </h3>
                <p className="text-sm text-crystal-lowgreen">
                  Ondas: {state.wave}
                </p>
                {dreamState === state.id && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="w-3 h-3 bg-crystal-glow rounded-full mx-auto"
                  />
                )}
              </div>
            </Card>
          </motion.div>
        ))}
        
        <Card className="glass-effect p-6 flex items-center justify-center border-dashed border-2 border-crystal-glow/30 hover:border-crystal-glow/50 transition-all duration-300 cursor-pointer">
          <div className="text-center space-y-2">
            <div className="text-4xl">✨</div>
            <p className="text-sm text-crystal-lowgreen font-semibold">
              Crear Estado Personalizado
            </p>
          </div>
        </Card>
      </div>

      <Card className="glass-effect p-8">
        <div className="grid md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-crystal-glow">
              Visualización Onírica
            </h3>

            <div className="aspect-square bg-black/60 rounded-lg border-2 border-crystal-glow/30 relative overflow-hidden">
              <AnimatePresence>
                {visualizing && (
                  <>
                    {[...Array(30)].map((_, i) => (
                      <motion.div
                        key={i}
                        className="absolute rounded-full bg-gradient-crystal opacity-30"
                        style={{
                          width: Math.random() * 100 + 50,
                          height: Math.random() * 100 + 50,
                          left: `${Math.random() * 100}%`,
                          top: `${Math.random() * 100}%`,
                        }}
                        initial={{ scale: 0, opacity: 0 }}
                        animate={{
                          scale: [0, 1.5, 0],
                          opacity: [0, 0.6, 0],
                          x: [0, Math.random() * 200 - 100],
                          y: [0, Math.random() * 200 - 100],
                        }}
                        exit={{ opacity: 0 }}
                        transition={{
                          duration: Math.random() * 5 + 3,
                          repeat: Infinity,
                          delay: Math.random() * 2,
                        }}
                      />
                    ))}
                  </>
                )}
              </AnimatePresence>

              <div className="absolute inset-0 flex items-center justify-center">
                <motion.div
                  className="text-8xl"
                  animate={{
                    rotate: visualizing ? 360 : 0,
                    scale: visualizing ? [1, 1.2, 1] : 1,
                  }}
                  transition={{
                    rotate: { duration: 10, repeat: Infinity, ease: "linear" },
                    scale: { duration: 2, repeat: Infinity },
                  }}
                >
                  🌙
                </motion.div>
              </div>
            </div>

            <Button
              onClick={() => setVisualizing(!visualizing)}
              className="w-full bg-gradient-crystal"
            >
              {visualizing ? "⏸️ Pausar" : "▶️ Iniciar"} Visualización
            </Button>
          </div>

          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-crystal-glow">
              Estado Actual: {dreamStates.find(s => s.id === dreamState)?.name}
            </h3>

            <Card className="bg-black/40 p-6 border-crystal-glow/20 space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-crystal-lowgreen">Frecuencia</span>
                <span className="text-crystal-glow font-mono">
                  {dreamState === "NREM1" && "4-7 Hz"}
                  {dreamState === "NREM2" && "12-14 Hz"}
                  {dreamState === "NREM3" && "0.5-4 Hz"}
                  {dreamState === "REM" && "Mixed"}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-crystal-lowgreen">Consciencia</span>
                <span className="text-crystal-glow">
                  {dreamState === "REM" ? "Alta" : "Baja"}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-crystal-lowgreen">Creatividad</span>
                <span className="text-crystal-glow">
                  {dreamState === "REM" ? "Máxima" : "Media"}
                </span>
              </div>
            </Card>

            <div className="space-y-3">
              <Button variant="outline" className="w-full">
                🎵 Generar Música Onírica
              </Button>
              <Button variant="outline" className="w-full">
                📊 Analizar Patrones de Sueño
              </Button>
              <Button variant="outline" className="w-full">
                💾 Guardar Sesión
              </Button>
            </div>

            <Card className="bg-black/40 p-4 border-crystal-glow/20">
              <p className="text-sm text-crystal-lowgreen mb-2">
                <strong>Isabella AI:</strong>
              </p>
              <p className="text-xs text-muted-foreground">
                "Detecto que estás explorando el estado {dreamStates.find(s => s.id === dreamState)?.name}. 
                Este estado es ideal para {dreamState === "REM" ? "creatividad máxima y resolución de problemas" : "relajación profunda y regeneración"}. 
                ¿Deseas que ajuste la música para potenciar esta experiencia?"
              </p>
            </Card>
          </div>
        </div>
      </Card>

      <Card className="glass-effect p-6">
        <h3 className="text-xl font-bold text-crystal-glow mb-4">
          ¿Cómo funciona el Nexo Onírico?
        </h3>
        <div className="grid md:grid-cols-2 gap-6 text-sm">
          <div className="space-y-3">
            <p className="text-muted-foreground">
              El Nexo Onírico utiliza patrones de ondas cerebrales para crear 
              música que sincroniza con tus diferentes estados de sueño. 
              Cada fase del sueño tiene su propia firma neuronal única.
            </p>
            <p className="text-crystal-lowgreen">
              <strong>Tecnología:</strong> Procesamiento de señales EEG + IA Generativa
            </p>
          </div>
          <div className="space-y-3">
            <p className="text-muted-foreground">
              La música generada puede ayudar a inducir estados específicos, 
              mejorar la calidad del sueño, potenciar sueños lúcidos o 
              facilitar la creatividad onírica.
            </p>
            <p className="text-crystal-lowgreen">
              <strong>Aplicaciones:</strong> Meditación, Sueño Profundo, Creatividad
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default NexoOnirico;
