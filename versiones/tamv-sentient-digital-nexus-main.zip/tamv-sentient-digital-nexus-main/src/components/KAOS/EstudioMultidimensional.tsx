import { useState } from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const EstudioMultidimensional = () => {
  const [activeDimension, setActiveDimension] = useState("3D");

  const dimensions = [
    { id: "3D", name: "Espacio 3D", icon: "📐", color: "cyan" },
    { id: "4D", name: "Tiempo 4D", icon: "⏰", color: "purple" },
    { id: "5D", name: "Emocional 5D", icon: "💓", color: "pink" },
    { id: "6D", name: "Quantum 6D", icon: "⚛️", color: "green" },
  ];

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h2 className="text-4xl font-bold text-gradient-crystal mb-4">
          🎨 Estudio Multidimensional
        </h2>
        <p className="text-crystal-lowgreen text-lg">
          Crea arte que trasciende las dimensiones tradicionales
        </p>
      </motion.div>

      <div className="flex justify-center gap-4 flex-wrap">
        {dimensions.map((dim) => (
          <Button
            key={dim.id}
            onClick={() => setActiveDimension(dim.id)}
            variant={activeDimension === dim.id ? "default" : "outline"}
            className={`${
              activeDimension === dim.id
                ? "bg-gradient-crystal text-white"
                : "border-crystal-glow/30"
            } transition-all duration-300`}
          >
            <span className="mr-2">{dim.icon}</span>
            {dim.name}
          </Button>
        ))}
      </div>

      <Card className="glass-effect p-8">
        <div className="grid md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-crystal-glow">
              Canvas {activeDimension}
            </h3>
            
            <div className="aspect-square bg-black/60 rounded-lg border-2 border-crystal-glow/30 flex items-center justify-center relative overflow-hidden">
              <motion.div
                key={activeDimension}
                initial={{ scale: 0, rotate: 0 }}
                animate={{ scale: 1, rotate: 360 }}
                transition={{ duration: 2 }}
                className="text-8xl"
              >
                {dimensions.find((d) => d.id === activeDimension)?.icon}
              </motion.div>
              
              <div className="absolute top-4 right-4">
                <Badge className="bg-gradient-crystal">
                  {activeDimension} Activo
                </Badge>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-crystal-glow">
              Herramientas {activeDimension}
            </h3>
            
            <div className="space-y-3">
              {activeDimension === "3D" && (
                <>
                  <Button variant="outline" className="w-full justify-start">
                    🎭 Modelado 3D Avanzado
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    💡 Iluminación Volumétrica
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    🎨 Texturas Procedurales
                  </Button>
                </>
              )}
              
              {activeDimension === "4D" && (
                <>
                  <Button variant="outline" className="w-full justify-start">
                    ⏱️ Línea Temporal Interactiva
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    🔄 Loops Temporales
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    📹 Renderizado 4D
                  </Button>
                </>
              )}

              {activeDimension === "5D" && (
                <>
                  <Button variant="outline" className="w-full justify-start">
                    💓 Mapeo Emocional
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    🎭 Paleta de Sentimientos
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    🌊 Ondas de Resonancia
                  </Button>
                </>
              )}

              {activeDimension === "6D" && (
                <>
                  <Button variant="outline" className="w-full justify-start">
                    ⚛️ Superposición Cuántica
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    🌌 Entrelazamiento Visual
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    ✨ Probabilidad Artística
                  </Button>
                </>
              )}
            </div>

            <Card className="bg-black/40 p-4 border-crystal-glow/20">
              <p className="text-sm text-crystal-lowgreen mb-2">
                <strong>Isabella AI Asistente:</strong>
              </p>
              <p className="text-xs text-muted-foreground">
                "Tu obra en {activeDimension} está evolucionando bellamente. 
                Sugiero explorar la combinación con otras dimensiones para 
                crear una experiencia verdaderamente transcendental."
              </p>
            </Card>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default EstudioMultidimensional;
