import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";

const ArbolSaber = () => {
  const branches = [
    { id: 1, name: "Física Cuántica", icon: "⚛️", connections: 3 },
    { id: 2, name: "Filosofía", icon: "🧠", connections: 5 },
    { id: 3, name: "Arte Digital", icon: "🎨", connections: 4 },
    { id: 4, name: "Música", icon: "🎵", connections: 6 },
    { id: 5, name: "Programación", icon: "💻", connections: 7 },
    { id: 6, name: "Neurociencia", icon: "🔬", connections: 4 },
  ];

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h2 className="text-4xl font-bold text-gradient-crystal mb-4">
          🌌 Árbol del Saber Universal
        </h2>
        <p className="text-crystal-lowgreen text-lg">
          Red de conocimiento interconectado - Yggdrasil Digital
        </p>
      </motion.div>

      <div className="grid md:grid-cols-3 gap-6">
        {branches.map((branch, index) => (
          <motion.div
            key={branch.id}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="glass-effect p-6 hover:glow-crystal transition-all duration-300">
              <div className="text-center space-y-4">
                <div className="text-6xl">{branch.icon}</div>
                <h3 className="text-xl font-bold text-crystal-glow">
                  {branch.name}
                </h3>
                <p className="text-sm text-crystal-lowgreen">
                  {branch.connections} conexiones activas
                </p>
                <div className="h-2 bg-black/40 rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-crystal"
                    initial={{ width: 0 }}
                    animate={{ width: `${branch.connections * 14}%` }}
                    transition={{ delay: index * 0.1 + 0.5, duration: 1 }}
                  />
                </div>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>

      <Card className="glass-effect p-8">
        <h3 className="text-2xl font-bold text-crystal-glow mb-6">Raíces del Árbol</h3>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <p className="text-crystal-lowgreen font-semibold">📚 Bibliotecas Integradas</p>
            <ul className="space-y-1 text-sm text-muted-foreground">
              <li>• 2.1M documentos académicos</li>
              <li>• 847K recursos audiovisuales</li>
              <li>• 4.3M conexiones semánticas</li>
            </ul>
          </div>
          <div className="space-y-2">
            <p className="text-crystal-lowgreen font-semibold">🌐 Colaboradores Activos</p>
            <ul className="space-y-1 text-sm text-muted-foreground">
              <li>• 12,457 investigadores</li>
              <li>• 3,891 artistas</li>
              <li>• 28,764 estudiantes</li>
            </ul>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default ArbolSaber;
