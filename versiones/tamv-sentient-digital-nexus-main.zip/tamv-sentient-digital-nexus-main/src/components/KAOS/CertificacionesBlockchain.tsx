import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const CertificacionesBlockchain = () => {
  const certifications = [
    {
      id: 1,
      name: "Maestría en IA Ética",
      institution: "TAMV University",
      issueDate: "2025-09-15",
      blockchain: "Polygon",
      txHash: "0x7f3a...9b4c",
      verified: true,
    },
    {
      id: 2,
      name: "Certificado Quantum Computing",
      institution: "Instituto Cuántico MX",
      issueDate: "2025-08-22",
      blockchain: "Ethereum",
      txHash: "0x9c2d...1a8f",
      verified: true,
    },
    {
      id: 3,
      name: "Diplomado Arte Generativo",
      institution: "Escuela Digital TAMV",
      issueDate: "2025-07-10",
      blockchain: "Polygon",
      txHash: "0x4b1e...3f7a",
      verified: true,
    },
  ];

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h2 className="text-4xl font-bold text-gradient-crystal mb-4">
          🎓 Certificaciones en Blockchain
        </h2>
        <p className="text-crystal-lowgreen text-lg">
          Credenciales académicas inmutables y verificables globalmente
        </p>
      </motion.div>

      <div className="space-y-4">
        {certifications.map((cert, index) => (
          <motion.div
            key={cert.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.15 }}
          >
            <Card className="glass-effect p-6 hover:glow-crystal transition-all duration-300">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-crystal-glow mb-2">
                    {cert.name}
                  </h3>
                  <p className="text-crystal-lowgreen mb-1">
                    {cert.institution}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Emitido: {cert.issueDate}
                  </p>
                </div>
                {cert.verified && (
                  <Badge className="bg-green-500/20 text-green-400">
                    ✓ Verificado
                  </Badge>
                )}
              </div>

              <div className="grid md:grid-cols-2 gap-4 p-4 bg-black/40 rounded-lg">
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Blockchain</p>
                  <p className="text-sm font-mono text-crystal-lowgreen">
                    {cert.blockchain}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Transaction Hash</p>
                  <p className="text-sm font-mono text-crystal-glow truncate">
                    {cert.txHash}
                  </p>
                </div>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>

      <Card className="glass-effect p-8">
        <h3 className="text-2xl font-bold text-crystal-glow mb-6">
          Ventajas de Certificaciones Blockchain
        </h3>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <span className="text-2xl">🔒</span>
              <div>
                <p className="font-bold text-crystal-lowgreen">Inmutabilidad</p>
                <p className="text-sm text-muted-foreground">
                  Registros permanentes que no pueden ser alterados
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <span className="text-2xl">🌍</span>
              <div>
                <p className="font-bold text-crystal-lowgreen">Alcance Global</p>
                <p className="text-sm text-muted-foreground">
                  Verificables desde cualquier parte del mundo
                </p>
              </div>
            </div>
          </div>
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <span className="text-2xl">⚡</span>
              <div>
                <p className="font-bold text-crystal-lowgreen">Verificación Instantánea</p>
                <p className="text-sm text-muted-foreground">
                  Validación en segundos sin intermediarios
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <span className="text-2xl">💎</span>
              <div>
                <p className="font-bold text-crystal-lowgreen">Propiedad Real</p>
                <p className="text-sm text-muted-foreground">
                  Tú controlas tus credenciales, no instituciones
                </p>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default CertificacionesBlockchain;
