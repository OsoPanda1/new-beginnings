// components/KAOS/ConciertosHolograficos.tsx
import { useState } from "react";

const ConciertosHolograficos = () => {
  const [selectedView, setSelectedView] = useState("primera-fila");
  const [energyLevel, setEnergyLevel] = useState(87);
  const [crowdIntensity, setCrowdIntensity] = useState("ÉPICA");

  const views = [
    { id: "primera-fila", name: "◉ Primera fila virtual", icon: "◉" },
    { id: "vista-aerea", name: "○ Vista aérea", icon: "○" },
    { id: "backstage", name: "○ En el escenario", icon: "○" },
    { id: "microscopica", name: "○ Dimensión microscópica", icon: "○" }
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <div className="border-2 border-crystal-glow/30 rounded-2xl bg-black/40 backdrop-blur-lg overflow-hidden">
        {/* Header */}
        <div className="border-b border-crystal-glow/20 p-6 text-center">
          <h2 className="text-3xl font-bold text-crystal-glow mb-2">
            🎭 CONCIERTO HOLOGRÁFICO EN VIVO
          </h2>
          <p className="text-crystal-lowgreen text-lg">
            "Isabella Villaseñor Presenta"
          </p>
        </div>

        <div className="p-6">
          {/* Información del Artista */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <p className="text-crystal-lowgreen mb-2">
                <span className="font-semibold">Artista:</span> @SonicDreamer
              </p>
              <p className="text-crystal-lowgreen">
                <span className="font-semibold">Audiencia global:</span> 847.3K 🌍
              </p>
            </div>
            <div className="text-center">
              <div className="border border-crystal-glow/30 rounded-lg p-4 bg-black/30">
                <p className="text-crystal-glow font-semibold mb-2">
                  [ESCENARIO CUÁNTICO 360°]
                </p>
                <div className="text-crystal-lowgreen text-sm font-mono">
                  <pre className="whitespace-pre-wrap">
                    {`┌─────────────────────────┐
│                         │
│    🎤                   │
│   ╱│╲                  │
│  👤═●═👤               │
│   ╲│╱    HOLOGRAMAS    │
│    │     FLOTANTES     │
│                         │
└─────────────────────────┘`}
                  </pre>
                </div>
              </div>
            </div>
          </div>

          {/* Selección de Vista */}
          <div className="mb-6">
            <p className="text-crystal-glow font-semibold mb-3">Tu posición:</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {views.map((view) => (
                <button
                  key={view.id}
                  onClick={() => setSelectedView(view.id)}
                  className={`p-3 rounded-lg text-center transition-all ${
                    selectedView === view.id
                      ? "bg-crystal-glow/20 border border-crystal-glow text-crystal-glow"
                      : "bg-black/30 border border-crystal-glow/20 text-crystal-lowgreen hover:border-crystal-glow/40"
                  }`}
                >
                  <div className="text-lg">{view.icon}</div>
                  <div className="text-xs mt-1">{view.name.split(' ')[0]} {view.name.split(' ')[1]}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Interacciones Colectivas */}
          <div className="mb-6">
            <p className="text-crystal-glow font-semibold mb-3">Interacciones colectivas:</p>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-crystal-lowgreen mb-1">
                  <span>💫 Energía enviada:</span>
                  <span>{energyLevel}%</span>
                </div>
                <div className="w-full bg-crystal-glow/20 rounded-full h-3">
                  <div 
                    className="bg-gradient-to-r from-crystal-lowgreen to-crystal-glow h-3 rounded-full transition-all duration-500"
                    style={{ width: `${energyLevel}%` }}
                  ></div>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-crystal-lowgreen">🌊 Ola de aplausos:</span>
                <button className="bg-crystal-glow/20 border border-crystal-glow/40 text-crystal-glow px-4 py-2 rounded-lg hover:bg-crystal-glow/30 transition-all">
                  [Iniciar]
                </button>
              </div>

              <div className="text-crystal-lowgreen">
                ✨ Peticiones: 234 votos "Éxtasis"
              </div>

              <div className="flex items-center justify-between">
                <span className="text-crystal-lowgreen">🔥 Intensidad crowd:</span>
                <span className="text-crystal-glow font-bold">{crowdIntensity}</span>
              </div>
            </div>
          </div>

          {/* Sensorial Sync */}
          <div className="mb-6">
            <p className="text-crystal-glow font-semibold mb-3">Sensorial sync:</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-crystal-lowgreen">
              <div>├─ Audio: 8D espacial</div>
              <div>├─ Visual: 120 FPS holográfico</div>
              <div>├─ Háptica: Pulso bajo sincronizado</div>
              <div>├─ Olfativa: Ozono eléctrico</div>
              <div>└─ Temperatura: Cálida (+3°C)</div>
            </div>
          </div>

          {/* NFT del Momento */}
          <div className="mb-6 text-center">
            <p className="text-crystal-glow font-semibold mb-2">💎 NFT del momento:</p>
            <p className="text-crystal-lowgreen mb-2">"Minuto 23:47" disponible</p>
            <p className="text-crystal-lowgreen mb-4">Captura este momento único</p>
            <button className="bg-gradient-to-r from-crystal-lowgreen to-crystal-glow text-black font-bold px-6 py-3 rounded-lg hover:opacity-90 transition-all">
              [⚡ ACUÑAR AHORA - ◈25]
            </button>
          </div>

          {/* Acciones Finales */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <button className="bg-crystal-glow/20 border border-crystal-glow/40 text-crystal-glow py-3 rounded-lg hover:bg-crystal-glow/30 transition-all">
              [🎁 ENVIAR TIP]
            </button>
            <button className="bg-crystal-glow/20 border border-crystal-glow/40 text-crystal-glow py-3 rounded-lg hover:bg-crystal-glow/30 transition-all">
              [💬 CHAT LIVE]
            </button>
            <button className="bg-crystal-glow/20 border border-crystal-glow/40 text-crystal-glow py-3 rounded-lg hover:bg-crystal-glow/30 transition-all">
              [📸 CAPTURAR]
            </button>
            <button className="bg-crystal-glow/20 border border-crystal-glow/40 text-crystal-glow py-3 rounded-lg hover:bg-crystal-glow/30 transition-all">
              [👥 INVITAR]
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConciertosHolograficos;
