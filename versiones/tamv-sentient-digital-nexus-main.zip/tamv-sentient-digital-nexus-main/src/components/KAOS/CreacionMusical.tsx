import { useState } from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";

const CreacionMusical = () => {
  const [tempo, setTempo] = useState([120]);
  const [emotion, setEmotion] = useState("energético");
  const [style, setStyle] = useState("electrónica");

  const emotions = ["tranquilo", "energético", "melancólico", "épico", "onírico"];
  const styles = ["electrónica", "orquestal", "ambient", "rock", "jazz-fusion"];

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h2 className="text-4xl font-bold text-gradient-crystal mb-4">
          🎼 Creación Musical Asistida por IA
        </h2>
        <p className="text-crystal-lowgreen text-lg">
          Compón música con la ayuda de Isabella AI - De la emoción al sonido
        </p>
      </motion.div>

      <div className="grid md:grid-cols-2 gap-8">
        <Card className="glass-effect p-6 space-y-6">
          <h3 className="text-2xl font-bold text-crystal-glow">Parámetros de Composición</h3>
          
          <div className="space-y-4">
            <div>
              <label className="text-crystal-lowgreen mb-2 block">Tempo: {tempo[0]} BPM</label>
              <Slider 
                value={tempo}
                onValueChange={setTempo}
                min={60}
                max={200}
                step={1}
                className="cursor-pointer"
              />
            </div>

            <div>
              <label className="text-crystal-lowgreen mb-2 block">Emoción Base</label>
              <div className="flex flex-wrap gap-2">
                {emotions.map((emo) => (
                  <Button
                    key={emo}
                    onClick={() => setEmotion(emo)}
                    variant={emotion === emo ? "default" : "outline"}
                    className={emotion === emo ? "bg-crystal-glow/20" : ""}
                  >
                    {emo}
                  </Button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-crystal-lowgreen mb-2 block">Estilo Musical</label>
              <div className="flex flex-wrap gap-2">
                {styles.map((sty) => (
                  <Button
                    key={sty}
                    onClick={() => setStyle(sty)}
                    variant={style === sty ? "default" : "outline"}
                    className={style === sty ? "bg-crystal-lowgreen/20" : ""}
                  >
                    {sty}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </Card>

        <Card className="glass-effect p-6 space-y-6">
          <h3 className="text-2xl font-bold text-crystal-glow">Vista Previa</h3>
          
          <div className="bg-black/40 rounded-lg p-8 text-center space-y-4">
            <div className="text-6xl animate-pulse">🎵</div>
            <p className="text-crystal-lowgreen">
              Composición: {emotion} {style}
            </p>
            <p className="text-sm text-muted-foreground">
              Tempo: {tempo[0]} BPM
            </p>
            <Button className="w-full bg-gradient-crystal">
              ▶️ Generar y Reproducir
            </Button>
          </div>

          <div className="space-y-2">
            <h4 className="font-bold text-crystal-lowgreen">Herramientas Avanzadas</h4>
            <Button variant="outline" className="w-full">🎹 Piano Roll</Button>
            <Button variant="outline" className="w-full">🥁 Secuenciador de Batería</Button>
            <Button variant="outline" className="w-full">🎸 Sintetizador Modular</Button>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default CreacionMusical;
