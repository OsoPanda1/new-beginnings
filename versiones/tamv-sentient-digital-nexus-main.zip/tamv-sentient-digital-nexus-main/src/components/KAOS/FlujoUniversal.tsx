import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";

const FlujoUniversal = () => {
  const flowStages = [
    {
      id: 1,
      name: "Inspiración",
      icon: "💡",
      description: "La chispa creativa inicial",
      energy: 85,
    },
    {
      id: 2,
      name: "Exploración",
      icon: "🔍",
      description: "Investigación de posibilidades",
      energy: 92,
    },
    {
      id: 3,
      name: "Creación",
      icon: "✨",
      description: "Materialización de la idea",
      energy: 98,
    },
    {
      id: 4,
      name: "Refinamiento",
      icon: "💎",
      description: "Pulido y perfeccionamiento",
      energy: 94,
    },
    {
      id: 5,
      name: "Compartir",
      icon: "🌍",
      description: "Conexión con la comunidad",
      energy: 88,
    },
  ];

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h2 className="text-4xl font-bold text-gradient-crystal mb-4">
          🌊 Flujo Universal de Creación
        </h2>
        <p className="text-crystal-lowgreen text-lg">
          El viaje completo desde la inspiración hasta la manifestación
        </p>
      </motion.div>

      <div className="relative">
        {/* Línea de flujo conectora */}
        <div className="absolute top-1/2 left-0 right-0 h-1 bg-gradient-crystal opacity-30 -translate-y-1/2 hidden md:block" />
        
        <div className="grid md:grid-cols-5 gap-6 relative z-10">
          {flowStages.map((stage, index) => (
            <motion.div
              key={stage.id}
              initial={{ opacity: 0, scale: 0.8, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ delay: index * 0.2 }}
            >
              <Card className="glass-effect p-6 text-center space-y-4 hover:glow-crystal transition-all duration-300 group">
                <motion.div
                  className="text-6xl mx-auto"
                  whileHover={{ scale: 1.2, rotate: 360 }}
                  transition={{ duration: 0.5 }}
                >
                  {stage.icon}
                </motion.div>
                
                <div className="space-y-2">
                  <h3 className="text-xl font-bold text-crystal-glow">
                    {stage.name}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {stage.description}
                  </p>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="text-crystal-lowgreen">Energía</span>
                    <span className="text-crystal-glow">{stage.energy}%</span>
                  </div>
                  <div className="h-2 bg-black/40 rounded-full overflow-hidden">
                    <motion.div
                      className="h-full bg-gradient-crystal"
                      initial={{ width: 0 }}
                      animate={{ width: `${stage.energy}%` }}
                      transition={{ duration: 1, delay: index * 0.2 + 0.5 }}
                    />
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      <Card className="glass-effect p-8">
        <h3 className="text-2xl font-bold text-crystal-glow mb-6 text-center">
          Filosofía del Flujo
        </h3>
        
        <div className="grid md:grid-cols-2 gap-8">
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <span className="text-2xl">🧘</span>
              <div>
                <p className="font-bold text-crystal-lowgreen">Estado de Flow</p>
                <p className="text-sm text-muted-foreground">
                  Cuando pierdes la noción del tiempo y la creatividad fluye sin esfuerzo
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <span className="text-2xl">♾️</span>
              <div>
                <p className="font-bold text-crystal-lowgreen">Ciclo Continuo</p>
                <p className="text-sm text-muted-foreground">
                  Cada obra terminada es el comienzo de la siguiente inspiración
                </p>
              </div>
            </div>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <span className="text-2xl">🌟</span>
              <div>
                <p className="font-bold text-crystal-lowgreen">Consciencia Creativa</p>
                <p className="text-sm text-muted-foreground">
                  Isabella AI acompaña cada etapa respetando tu proceso único
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <span className="text-2xl">💫</span>
              <div>
                <p className="font-bold text-crystal-lowgreen">Sincronización Universal</p>
                <p className="text-sm text-muted-foreground">
                  Tu flujo se conecta con el de miles de creadores en TAMV
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 p-6 bg-black/40 rounded-lg border border-crystal-glow/20 text-center">
          <p className="text-crystal-lowgreen italic">
            "El flujo no se fuerza, se permite. TAMV crea el espacio para que emerja naturalmente."
          </p>
          <p className="text-xs text-muted-foreground mt-2">— Filosofía KAOS Audio</p>
        </div>
      </Card>
    </div>
  );
};

export default FlujoUniversal;
