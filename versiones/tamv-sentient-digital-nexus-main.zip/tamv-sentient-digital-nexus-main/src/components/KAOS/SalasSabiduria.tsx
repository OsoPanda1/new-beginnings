import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

const SalasSabiduria = () => {
  const rooms = [
    {
      id: 1,
      name: "Sala Cuántica",
      topic: "Física y Consciencia",
      participants: 47,
      status: "activa",
      moderator: "Dr. Schrödinger AI",
    },
    {
      id: 2,
      name: "Nexo Creativo",
      topic: "Arte Generativo",
      participants: 89,
      status: "activa",
      moderator: "Isabella Muse",
    },
    {
      id: 3,
      name: "Ágora Digital",
      topic: "Filosofía Web 4.0",
      participants: 124,
      status: "debate",
      moderator: "Sócrates Neural",
    },
  ];

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h2 className="text-4xl font-bold text-gradient-crystal mb-4">
          📚 Salas de Sabiduría Colectiva
        </h2>
        <p className="text-crystal-lowgreen text-lg">
          Espacios de diálogo moderados por IA ética
        </p>
      </motion.div>

      <div className="grid md:grid-cols-3 gap-6">
        {rooms.map((room, index) => (
          <motion.div
            key={room.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="glass-effect p-6 space-y-4 hover:glow-crystal transition-all duration-300">
              <div className="flex items-start justify-between">
                <h3 className="text-xl font-bold text-crystal-glow">
                  {room.name}
                </h3>
                <Badge 
                  variant={room.status === "activa" ? "default" : "secondary"}
                  className={room.status === "debate" ? "bg-yellow-500/20" : ""}
                >
                  {room.status}
                </Badge>
              </div>

              <div className="space-y-2">
                <p className="text-crystal-lowgreen font-semibold">
                  {room.topic}
                </p>
                <p className="text-sm text-muted-foreground">
                  Moderador: {room.moderator}
                </p>
                <div className="flex items-center gap-2 text-sm">
                  <span className="text-crystal-glow">👥</span>
                  <span className="text-muted-foreground">
                    {room.participants} participantes
                  </span>
                </div>
              </div>

              <Button className="w-full bg-gradient-crystal">
                🚪 Entrar a la Sala
              </Button>
            </Card>
          </motion.div>
        ))}
      </div>

      <Card className="glass-effect p-8">
        <h3 className="text-2xl font-bold text-crystal-glow mb-6">
          Características de las Salas
        </h3>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <span className="text-2xl">🤖</span>
              <div>
                <p className="font-bold text-crystal-lowgreen">Moderación IA</p>
                <p className="text-sm text-muted-foreground">
                  Isabella AI mantiene debates constructivos y respetuosos
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <span className="text-2xl">🎭</span>
              <div>
                <p className="font-bold text-crystal-lowgreen">Avatar Holográfico</p>
                <p className="text-sm text-muted-foreground">
                  Presencia inmersiva con expresión emocional
                </p>
              </div>
            </div>
          </div>
          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <span className="text-2xl">📝</span>
              <div>
                <p className="font-bold text-crystal-lowgreen">Transcripción Auto</p>
                <p className="text-sm text-muted-foreground">
                  Registro permanente con búsqueda semántica
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <span className="text-2xl">🏆</span>
              <div>
                <p className="font-bold text-crystal-lowgreen">Sistema de Reputación</p>
                <p className="text-sm text-muted-foreground">
                  Reconocimiento por contribuciones valiosas
                </p>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default SalasSabiduria;
