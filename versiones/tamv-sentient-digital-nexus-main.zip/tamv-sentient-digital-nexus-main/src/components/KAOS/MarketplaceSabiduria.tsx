import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const MarketplaceSabiduria = () => {
  const offerings = [
    {
      id: 1,
      title: "Curso: Física Cuántica para Artistas",
      creator: "Dr. María Quantum",
      price: "250 TAMV",
      rating: 4.9,
      students: 1247,
    },
    {
      id: 2,
      title: "Masterclass: Composición Generativa",
      creator: "Alex Synthesis",
      price: "180 TAMV",
      rating: 4.8,
      students: 892,
    },
    {
      id: 3,
      title: "Workshop: Arte Neural 3D",
      creator: "Isabella Collective",
      price: "320 TAMV",
      rating: 5.0,
      students: 634,
    },
  ];

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h2 className="text-4xl font-bold text-gradient-crystal mb-4">
          🌉 Marketplace de Sabiduría
        </h2>
        <p className="text-crystal-lowgreen text-lg">
          Intercambio peer-to-peer de conocimiento verificado
        </p>
      </motion.div>

      <div className="grid md:grid-cols-3 gap-6">
        {offerings.map((offer, index) => (
          <motion.div
            key={offer.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.15 }}
          >
            <Card className="glass-effect p-6 space-y-4 hover:glow-crystal transition-all duration-300 h-full flex flex-col">
              <div className="flex-1 space-y-3">
                <h3 className="text-lg font-bold text-crystal-glow">
                  {offer.title}
                </h3>
                <p className="text-sm text-crystal-lowgreen">
                  Por {offer.creator}
                </p>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-yellow-400">⭐ {offer.rating}</span>
                  <span className="text-muted-foreground">
                    {offer.students.toLocaleString()} estudiantes
                  </span>
                </div>
              </div>
              <div className="space-y-3">
                <div className="text-2xl font-bold text-gradient-crystal">
                  {offer.price}
                </div>
                <Button className="w-full bg-gradient-crystal">
                  Inscribirse Ahora
                </Button>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>

      <Card className="glass-effect p-8">
        <div className="grid md:grid-cols-3 gap-6 text-center">
          <div>
            <div className="text-4xl font-bold text-gradient-crystal mb-2">
              8,947
            </div>
            <p className="text-crystal-lowgreen">Cursos Disponibles</p>
          </div>
          <div>
            <div className="text-4xl font-bold text-gradient-crystal mb-2">
              124K
            </div>
            <p className="text-crystal-lowgreen">Transacciones Éticas</p>
          </div>
          <div>
            <div className="text-4xl font-bold text-gradient-crystal mb-2">
              98.7%
            </div>
            <p className="text-crystal-lowgreen">Satisfacción</p>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default MarketplaceSabiduria;
