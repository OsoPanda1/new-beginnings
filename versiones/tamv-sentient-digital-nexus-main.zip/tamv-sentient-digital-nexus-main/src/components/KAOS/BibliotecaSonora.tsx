// components/KAOS/BibliotecaSonora.tsx
import { useState } from "react";

const BibliotecaSonora = () => {
  const [searchType, setSearchType] = useState("emocion");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedColor, setSelectedColor] = useState("#8B5CF6");

  const searchTypes = [
    { id: "emocion", name: "🎭 Emoción", placeholder: "Música que siente como despertar de un sueño" },
    { id: "color", name: "🌈 Color sinestésico", placeholder: "Selecciona un color" },
    { id: "frecuencia", name: "🧬 Frecuencia terapéutica", placeholder: "528 Hz - Reparación ADN" },
    { id: "cultura", name: "🌍 Cultura/Origen", placeholder: "Mapa interactivo 3D" },
    { id: "energia", name: "⚡ Energía", placeholder: "Alta intensidad" },
    { id: "momento", name: "🌙 Momento del día", placeholder: "Deslizar para seleccionar" },
    { id: "intencion", name: "🔮 Intención", placeholder: "Meditación/Trabajo/Fiesta" }
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <div className="border-2 border-crystal-glow/30 rounded-2xl bg-black/40 backdrop-blur-lg overflow-hidden">
        {/* Header */}
        <div className="border-b border-crystal-glow/20 p-6 text-center">
          <h2 className="text-3xl font-bold text-crystal-glow mb-2">
            📚 BIBLIOTECA AKÁSHICA DEL SONIDO
          </h2>
        </div>

        <div className="p-6">
          {/* Estadísticas */}
          <div className="grid grid-cols-2 gap-4 mb-6 text-center">
            <div className="bg-black/30 rounded-lg p-4 border border-crystal-glow/20">
              <p className="text-crystal-glow text-2xl font-bold">∞</p>
              <p className="text-crystal-lowgreen text-sm">Archivos disponibles</p>
            </div>
            <div className="bg-black/30 rounded-lg p-4 border border-crystal-glow/20">
              <p className="text-crystal-glow text-2xl font-bold">7</p>
              <p className="text-crystal-lowgreen text-sm">Dimensiones de búsqueda</p>
            </div>
          </div>

          {/* Búsqueda */}
          <div className="mb-6">
            <p className="text-crystal-glow font-semibold mb-3">Busca por:</p>
            <div className="border border-crystal-glow/30 rounded-xl bg-black/30 p-4">
              {/* Selector de Tipo de Búsqueda */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-4">
                {searchTypes.map((type) => (
                  <button
                    key={type.id}
                    onClick={() => setSearchType(type.id)}
                    className={`p-2 rounded-lg text-center transition-all ${
                      searchType === type.id
                        ? "bg-crystal-glow/20 border border-crystal-glow text-crystal-glow"
                        : "bg-black/20 border border-crystal-glow/10 text-crystal-lowgreen hover:border-crystal-glow/30"
                    }`}
                  >
                    <div className="text-sm">{type.name.split(' ')[0]}</div>
                  </button>
                ))}
              </div>

              {/* Campo de Búsqueda según Tipo */}
              <div className="space-y-3">
                {searchType === "emocion" && (
                  <div>
                    <label className="text-crystal-lowgreen block mb-2">🎭 Emoción</label>
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Música que siente como despertar de un sueño"
                      className="w-full bg-black/40 border border-crystal-glow/30 rounded-lg px-4 py-3 text-crystal-glow placeholder-crystal-lowgreen/50 focus:border-crystal-glow focus:outline-none"
                    />
                  </div>
                )}

                {searchType === "color" && (
                  <div>
                    <label className="text-crystal-lowgreen block mb-2">🌈 Color sinestésico</label>
                    <div className="flex items-center space-x-4">
                      <input
                        type="color"
                        value={selectedColor}
                        onChange={(e) => setSelectedColor(e.target.value)}
                        className="w-16 h-16 rounded-lg cursor-pointer"
                      />
                      <span className="text-crystal-glow">[Selector de color visual]</span>
                    </div>
                  </div>
                )}

                {searchType === "frecuencia" && (
                  <div>
                    <label className="text-crystal-lowgreen block mb-2">🧬 Frecuencia terapéutica</label>
                    <select className="w-full bg-black/40 border border-crystal-glow/30 rounded-lg px-4 py-3 text-crystal-glow focus:border-crystal-glow focus:outline-none">
                      <option>528 Hz - Reparación ADN</option>
                      <option>432 Hz - Sanación Natural</option>
                      <option>639 Hz - Conexiones Interpersonales</option>
                      <option>741 Hz - Expresión y Soluciones</option>
                      <option>852 Hz - Despertar Intuitivo</option>
                    </select>
                  </div>
                )}

                {/* Más tipos de búsqueda... */}
              </div>
            </div>
          </div>

          {/* Sugerencia de IA */}
          <div className="bg-gradient-to-r from-crystal-glow/10 to-crystal-lowgreen/10 border border-crystal-glow/30 rounded-xl p-4 mb-6">
            <p className="text-crystal-glow font-semibold mb-2">IA Musical Isabella:</p>
            <p className="text-crystal-lowgreen mb-4">
              "Basado en tu estado actual (Concentrado + Creativo) sugiero: 'Flujo Cuántico Vol.3'"
            </p>
            <button className="bg-crystal-glow/20 border border-crystal-glow/40 text-crystal-glow px-6 py-3 rounded-lg hover:bg-crystal-glow/30 transition-all w-full">
              [▶️ REPRODUCIR SUGERENCIA]
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BibliotecaSonora;
