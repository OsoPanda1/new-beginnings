import { Card } from "@/components/ui/card";

const pillars = [
  {
    number: "01",
    name: "Legitimidad por Fractura",
    description: "La adversidad se transforma en fundamento ético",
    implementation: "Anubis Sentinel + DEKATEOTL",
  },
  {
    number: "02",
    name: "Soberanía Modular",
    description: "Independencia tecnológica con interoperabilidad",
    implementation: "ID-NVIDA + TAMV Registry Core",
  },
  {
    number: "03",
    name: "Ética Multisensorial",
    description: "La tecnología honra la experiencia humana completa",
    implementation: "Isabella AI + KAOS Audio 3D",
  },
  {
    number: "04",
    name: "Economía de Dignidad",
    description: "Valoración justa del trabajo digital",
    implementation: "TAMV Coins + DAO Híbrida",
  },
  {
    number: "05",
    name: "Educación Expansiva",
    description: "Aprendizaje como experiencia transformadora",
    implementation: "TAMV University + Dream Spaces",
  },
  {
    number: "06",
    name: "Arte como Memoria",
    description: "La creación documenta y trasciende",
    implementation: "Art Gallery + HyperRender 4D",
  },
  {
    number: "07",
    name: "Gobernanza Sentiente",
    description: "IA al servicio del florecimiento humano",
    implementation: "Isabella AI + Governance Service",
  },
];

const Philosophy = () => {
  return (
    <section className="relative py-24 overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-primary blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full bg-secondary blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-gradient">Filosofía: De la Adversidad a la Legitimidad</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Los 7 Pilares Fundamentales que transforman la exclusión sistémica en arquitectura civilizatoria
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {pillars.map((pillar, index) => (
            <Card
              key={pillar.number}
              className="glass-effect p-6 space-y-4 hover:glow-quantum transition-all duration-500 border-border/50 group"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <div className="flex items-start gap-4">
                <div className="text-5xl font-bold text-gradient opacity-50 group-hover:opacity-100 transition-opacity">
                  {pillar.number}
                </div>
                <div className="flex-1 space-y-2">
                  <h3 className="text-xl font-bold">{pillar.name}</h3>
                  <p className="text-sm text-muted-foreground">{pillar.description}</p>
                  <div className="pt-2">
                    <span className="text-xs text-primary font-semibold">
                      {pillar.implementation}
                    </span>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Manifesto */}
        <Card className="glass-effect p-8 md:p-12 border-primary/30 glow-quantum">
          <div className="space-y-6">
            <h3 className="text-3xl font-bold text-center text-gradient">Manifiesto TAMV</h3>
            
            <div className="grid md:grid-cols-2 gap-8">
              <div className="space-y-4">
                <h4 className="text-xl font-bold text-destructive">TAMV MD-X4™ NO ES:</h4>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2 text-muted-foreground">
                    <span className="text-destructive mt-1">✕</span>
                    <span>Una startup convencional de tecnología</span>
                  </li>
                  <li className="flex items-start gap-2 text-muted-foreground">
                    <span className="text-destructive mt-1">✕</span>
                    <span>Una plataforma más de blockchain</span>
                  </li>
                  <li className="flex items-start gap-2 text-muted-foreground">
                    <span className="text-destructive mt-1">✕</span>
                    <span>Un proyecto especulativo</span>
                  </li>
                </ul>
              </div>

              <div className="space-y-4">
                <h4 className="text-xl font-bold text-quantum">TAMV MD-X4™ ES:</h4>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2 text-muted-foreground">
                    <span className="text-quantum mt-1">✓</span>
                    <span>Una arquitectura civilizatoria digital</span>
                  </li>
                  <li className="flex items-start gap-2 text-muted-foreground">
                    <span className="text-quantum mt-1">✓</span>
                    <span>Un ecosistema de dignidad tecnológica</span>
                  </li>
                  <li className="flex items-start gap-2 text-muted-foreground">
                    <span className="text-quantum mt-1">✓</span>
                    <span>La respuesta mexicana a la Web 4.0</span>
                  </li>
                  <li className="flex items-start gap-2 text-muted-foreground">
                    <span className="text-quantum mt-1">✓</span>
                    <span>Un manifiesto de soberanía digital</span>
                  </li>
                </ul>
              </div>
            </div>

            <div className="pt-6 text-center">
              <p className="text-lg text-muted-foreground italic">
                "Del Real del Monte al Mundo: Transformando marginación en soberanía digital"
              </p>
              <p className="text-sm text-primary mt-2">— Edwin Anubis Villaseñor, Fundador</p>
            </div>
          </div>
        </Card>
      </div>
    </section>
  );
};

export default Philosophy;
