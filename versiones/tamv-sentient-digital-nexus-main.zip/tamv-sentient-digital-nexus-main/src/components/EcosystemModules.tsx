import { Card } from "@/components/ui/card";
import { Shield, Brain, Coins, GraduationCap, Palette, Scale, Cpu } from "lucide-react";

const modules = [
  {
    icon: Brain,
    name: "Isabella AI",
    tagline: "Cerebro Ético del Ecosistema",
    description: "Motor de IA multimodal con comprensión emocional, validación ética y aprendizaje experiencial permanente.",
    color: "primary",
  },
  {
    icon: Scale,
    name: "DEKATEOTL",
    tagline: "Gobernanza Filosófica",
    description: "Sistema de toma de decisiones éticas a través de 4 capas: individual, comunitaria, institucional y transcendental.",
    color: "secondary",
  },
  {
    icon: Shield,
    name: "Anubis Sentinel",
    tagline: "Protección Multisensorial",
    description: "Sistema proactivo de seguridad que monitorea identidad digital, integridad de contenido, seguridad económica y bienestar emocional.",
    color: "accent",
  },
  {
    icon: Coins,
    name: "TAMV Coins",
    tagline: "Economía de Dignidad",
    description: "Token nativo con modelo económico híbrido: utilidad, gobernanza y valoración justa del trabajo digital.",
    color: "quantum",
  },
  {
    icon: GraduationCap,
    name: "TAMV University",
    tagline: "Educación Expansiva",
    description: "Campus virtual inmersivo 4D con credenciales verificables en blockchain y acceso global democratizado.",
    color: "primary",
  },
  {
    icon: Palette,
    name: "Art Gallery",
    tagline: "Arte como Memoria",
    description: "Plataforma para preservación cultural digital, NFTs con protección de derechos y economía sustentable para artistas.",
    color: "accent",
  },
  {
    icon: Cpu,
    name: "HyperRender 4D",
    tagline: "Visualización Cuántica",
    description: "Motor de renderizado 3D/4D con extensión cuántica para estandarización de entornos virtuales del ecosistema.",
    color: "secondary",
  },
];

const EcosystemModules = () => {
  return (
    <section className="relative py-24 overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-gradient">Módulos del Ecosistema</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Una arquitectura integral que trasciende la tecnología para convertirse en civilización digital
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {modules.map((module, index) => {
            const Icon = module.icon;
            return (
              <Card
                key={module.name}
                className="glass-effect p-8 space-y-4 hover:glow-quantum transition-all duration-500 group border-border/50"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="flex items-start justify-between">
                  <div 
                    className="w-14 h-14 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300"
                    style={{ 
                      backgroundColor: `hsl(var(--${module.color}) / 0.2)` 
                    }}
                  >
                    <Icon 
                      className="w-7 h-7" 
                      style={{ color: `hsl(var(--${module.color}))` }}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="text-2xl font-bold">{module.name}</h3>
                  <p className="text-sm font-semibold text-primary">{module.tagline}</p>
                </div>

                <p className="text-muted-foreground leading-relaxed">
                  {module.description}
                </p>

                <div className="pt-4">
                  <div className="h-1 w-full bg-border rounded-full overflow-hidden">
                    <div 
                      className="h-full gradient-quantum opacity-50 group-hover:opacity-100 transition-opacity duration-300"
                      style={{ width: '100%' }}
                    />
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default EcosystemModules;
