// MiniPreviewModal.tsx
import * as React from "react";
import { motion } from "framer-motion";

export interface MiniPreviewModalProps {
  title?: React.ReactNode;
  children: React.ReactNode;
  onClose?: () => void;
}

export const MiniPreviewModal: React.FC<MiniPreviewModalProps> = ({
  title,
  children,
  onClose,
}) => (
  <motion.div
    className="fixed left-1/2 top-1/2 z-[1000] max-w-xs mx-auto bg-gradient-to-tr from-cyan-900 via-crystal-glow/40 to-bg-quantum/50 backdrop-blur-2xl rounded-xl shadow-xl p-6"
    initial={{ opacity: 0, scale: 0.96 }}
    animate={{ opacity: 1, scale: 1 }}
    exit={{ opacity: 0, scale: 0.9 }}
    transition={{ duration: 0.25 }}
    style={{ transform: "translate(-50%, -50%)" }}
  >
    {title && (
      <div className="font-bold text-cyan-100 mb-3 text-lg">{title}</div>
    )}
    <div>{children}</div>
    {onClose && (
      <button
        className="mt-3 bg-cyan-800 rounded py-1 px-4 text-cyan-50 hover:bg-cyan-600"
        onClick={onClose}
      >
        Cerrar
      </button>
    )}
  </motion.div>
);
