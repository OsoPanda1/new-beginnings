import { Card } from "@/components/ui/card";
import { CheckCircle2, Circle, Clock } from "lucide-react";

const phases = [
  {
    phase: "Fase 1: MVP Crítico",
    duration: "30 Días",
    progress: 15,
    status: "in-progress",
    deliverables: [
      "API Gateway funcional con 3 endpoints",
      "Servicio de identidad básico (registro/login)",
      "Capa sentiente mínima operativa",
      "Base de datos PostgreSQL esencial",
      "Dashboard de administración básico",
    ],
  },
  {
    phase: "Fase 2: Prototipo Funcional",
    duration: "60 Días Adicionales",
    progress: 0,
    status: "pending",
    deliverables: [
      "Isabella AI con comprensión emocional",
      "Dashboard en tiempo real",
      "APIs consumibles para terceros",
      "Sistema de activismo de IA",
      "Integración blockchain básica",
    ],
  },
  {
    phase: "Fase 3: Lanzamiento Comercial",
    duration: "90 Días Adicionales",
    progress: 0,
    status: "pending",
    deliverables: [
      "3 shards geográficos completos",
      "Criptografía post-cuántica híbrida",
      "API pública con rate limits",
      "Certificación ISO 27001 en proceso",
      "Primeros clientes enterprise",
    ],
  },
  {
    phase: "Fase 4: Escala Global",
    duration: "6 Meses Adicionales",
    progress: 0,
    status: "pending",
    deliverables: [
      "White-label para instituciones",
      "30 zkRollups operativos",
      "Integración Apple/Google Wallet",
      "Compliance GDPR/CCPA certificado",
      "2M+ usuarios activos",
    ],
  },
];

const Roadmap = () => {
  return (
    <section className="relative py-24">
      <div className="container mx-auto px-4">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-gradient">Plan de Implementación</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Roadmap detallado hacia la soberanía digital global
          </p>
        </div>

        <div className="max-w-4xl mx-auto space-y-6">
          {phases.map((phase, index) => (
            <Card
              key={phase.phase}
              className={`glass-effect p-6 md:p-8 border-border/50 ${
                phase.status === 'in-progress' ? 'glow-quantum border-primary/50' : ''
              }`}
            >
              <div className="space-y-4">
                {/* Header */}
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-4 flex-1">
                    <div className="mt-1">
                      {phase.status === 'completed' && <CheckCircle2 className="w-6 h-6 text-quantum" />}
                      {phase.status === 'in-progress' && <Clock className="w-6 h-6 text-primary animate-pulse" />}
                      {phase.status === 'pending' && <Circle className="w-6 h-6 text-muted-foreground" />}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl md:text-2xl font-bold">{phase.phase}</h3>
                      <p className="text-sm text-muted-foreground mt-1">{phase.duration}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-primary">{phase.progress}%</div>
                    <div className="text-xs text-muted-foreground">Completado</div>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full gradient-quantum transition-all duration-1000"
                    style={{ width: `${phase.progress}%` }}
                  />
                </div>

                {/* Deliverables */}
                <div className="space-y-2 pt-2">
                  <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">
                    Entregables
                  </h4>
                  <ul className="space-y-2">
                    {phase.deliverables.map((deliverable) => (
                      <li
                        key={deliverable}
                        className="flex items-start gap-2 text-sm text-muted-foreground"
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 flex-shrink-0" />
                        <span>{deliverable}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Growth Strategy */}
        <div className="mt-16 glass-effect rounded-2xl p-8 border-border/50">
          <h3 className="text-2xl font-bold mb-6 text-center">Estrategia de Crecimiento</h3>
          <div className="grid md:grid-cols-4 gap-6">
            {[
              {
                phase: "2025-2026",
                title: "Cimiento Nacional",
                users: "1M+",
                territory: "México",
              },
              {
                phase: "2027-2028",
                title: "Expansión Latinoamericana",
                users: "50M+",
                territory: "5+ países",
              },
              {
                phase: "2029-2030",
                title: "Incursión Global",
                users: "500M+",
                territory: "3+ continentes",
              },
              {
                phase: "2031+",
                title: "Liderazgo Civilizatorio",
                users: "1B+",
                territory: "Estándares Web 4.0",
              },
            ].map((milestone) => (
              <Card
                key={milestone.phase}
                className="bg-card/30 p-6 space-y-3 border-border/30 hover:border-primary/50 transition-colors"
              >
                <div className="text-sm font-bold text-primary">{milestone.phase}</div>
                <h4 className="text-lg font-bold">{milestone.title}</h4>
                <div className="space-y-1">
                  <div className="text-2xl font-bold text-gradient">{milestone.users}</div>
                  <div className="text-xs text-muted-foreground">{milestone.territory}</div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Roadmap;
