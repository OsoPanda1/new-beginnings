import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Shield, CheckCircle2, FileCheck, Globe, Award } from "lucide-react";

const certifications = [
  {
    category: "Normativas Internacionales",
    icon: Globe,
    items: [
      {
        name: "GDPR (Europa)",
        status: "Cumplimiento Completo",
        level: "compliant",
        details: "Reglamento General de Protección de Datos"
      },
      {
        name: "CCPA/CPRA (California)",
        status: "Implementado",
        level: "compliant",
        details: "California Privacy Rights Act"
      },
      {
        name: "LGPD (Brasil)",
        status: "Compatible",
        level: "compliant",
        details: "Lei Geral de Proteção de Dados"
      },
      {
        name: "LFPDPPP (México)",
        status: "Nativo",
        level: "compliant",
        details: "Ley Federal de Protección de Datos Personales"
      }
    ]
  },
  {
    category: "Certificaciones de Seguridad",
    icon: Shield,
    items: [
      {
        name: "ISO/IEC 27001:2022",
        status: "En Proceso",
        level: "progress",
        details: "Gestión de Seguridad de la Información"
      },
      {
        name: "ISO/IEC 27701:2019",
        status: "Planificado",
        level: "planned",
        details: "Sistema de Gestión de Privacidad"
      },
      {
        name: "SOC 2 Type II",
        status: "En Proceso",
        level: "progress",
        details: "Controles Organizacionales y de Seguridad"
      },
      {
        name: "eIDAS Nivel Alto",
        status: "Planificado",
        level: "planned",
        details: "Identificación Electrónica (UE)"
      }
    ]
  },
  {
    category: "Estándares Técnicos",
    icon: FileCheck,
    items: [
      {
        name: "W3C DID Standard",
        status: "Implementado",
        level: "compliant",
        details: "Decentralized Identifiers"
      },
      {
        name: "W3C Verifiable Credentials",
        status: "Implementado",
        level: "compliant",
        details: "Credenciales Verificables"
      },
      {
        name: "NIST Post-Quantum Crypto",
        status: "En Implementación",
        level: "progress",
        details: "Algoritmos Post-Cuánticos"
      },
      {
        name: "IEEE 2410-2021",
        status: "Compatible",
        level: "compliant",
        details: "Biometric Privacy"
      }
    ]
  },
  {
    category: "Certificaciones Éticas",
    icon: Award,
    items: [
      {
        name: "IEEE 7000-2021",
        status: "En Implementación",
        level: "progress",
        details: "Ethical Systems Engineering"
      },
      {
        name: "EU AI Act Compliance",
        status: "Preparación",
        level: "planned",
        details: "Reglamento de IA de la UE"
      },
      {
        name: "UNESCO AI Ethics",
        status: "Alineado",
        level: "compliant",
        details: "Recomendaciones sobre Ética de IA"
      },
      {
        name: "WEF Responsible AI",
        status: "Validado",
        level: "compliant",
        details: "World Economic Forum Guidelines"
      }
    ]
  }
];

const ethicalPrinciples = [
  {
    principle: "Consentimiento Informado Granular",
    implementation: "Control por el usuario de cada punto de datos compartido"
  },
  {
    principle: "Derecho al Olvido Implementable",
    implementation: "Eliminación completa de datos con verificación blockchain"
  },
  {
    principle: "Transparencia Algorítmica",
    implementation: "Explicabilidad con SHAP/LIME para decisiones de IA"
  },
  {
    principle: "No Discriminación por Diseño",
    implementation: "Auditorías de sesgo automatizadas y continuas"
  },
  {
    principle: "Privacidad desde el Diseño",
    implementation: "Privacy-by-Design y Privacy-by-Default"
  },
  {
    principle: "Portabilidad de Datos",
    implementation: "Exportación en formatos estándar interoperables"
  }
];

const getLevelColor = (level: string) => {
  switch (level) {
    case "compliant":
      return "text-green-500";
    case "progress":
      return "text-yellow-500";
    case "planned":
      return "text-blue-500";
    default:
      return "text-muted-foreground";
  }
};

const getLevelBadge = (level: string) => {
  switch (level) {
    case "compliant":
      return "bg-green-500/20 text-green-500 border-green-500/50";
    case "progress":
      return "bg-yellow-500/20 text-yellow-500 border-yellow-500/50";
    case "planned":
      return "bg-blue-500/20 text-blue-500 border-blue-500/50";
    default:
      return "bg-muted text-muted-foreground";
  }
};

const ComplianceCertifications = () => {
  return (
    <section className="relative py-24 overflow-hidden" id="compliance">
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-1/3 left-1/3 w-96 h-96 rounded-full bg-green-500 blur-3xl animate-pulse" />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center space-y-4 mb-16">
          <Badge variant="outline" className="text-green-500 border-green-500/50">
            Compliance & Ethics Framework
          </Badge>
          <h2 className="text-gradient">Certificaciones y Cumplimiento Global</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Marco integral de cumplimiento normativo y certificaciones internacionales 
            para garantizar privacidad, seguridad y ética en todas las operaciones
          </p>
        </div>

        {/* Certifications Grid */}
        <div className="grid md:grid-cols-2 gap-8 mb-16">
          {certifications.map((category, index) => {
            const Icon = category.icon;
            return (
              <Card 
                key={category.category}
                className="glass-effect p-6 space-y-6 border-border/50 hover:glow-quantum transition-all duration-500"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <h3 className="text-xl font-bold">{category.category}</h3>
                </div>

                <div className="space-y-3">
                  {category.items.map((item) => (
                    <div 
                      key={item.name}
                      className="bg-card/30 rounded-lg p-4 border border-border/30 hover:border-primary/30 transition-colors duration-300"
                    >
                      <div className="flex items-start justify-between mb-2">
                        <h4 className="font-bold text-foreground">{item.name}</h4>
                        <Badge variant="outline" className={getLevelBadge(item.level)}>
                          {item.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{item.details}</p>
                    </div>
                  ))}
                </div>
              </Card>
            );
          })}
        </div>

        {/* Ethical Principles */}
        <Card className="glass-effect p-8 border-primary/30 glow-quantum">
          <div className="space-y-8">
            <div className="text-center">
              <h3 className="text-3xl font-bold mb-4 text-gradient">Principios Éticos Fundamentales</h3>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Compromisos éticos integrados en cada capa de la arquitectura TAMV
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              {ethicalPrinciples.map((item, index) => (
                <div 
                  key={index}
                  className="bg-card/40 rounded-lg p-6 border border-border/30 hover:border-quantum/50 transition-colors duration-300"
                >
                  <div className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-quantum mt-1 flex-shrink-0" />
                    <div className="space-y-2">
                      <h4 className="font-bold text-lg">{item.principle}</h4>
                      <p className="text-sm text-muted-foreground">{item.implementation}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-8 p-6 bg-quantum/10 rounded-lg border border-quantum/30">
              <p className="text-center text-sm text-muted-foreground">
                <strong className="text-quantum">Certificación WEF:</strong> Arquitectura validada por 
                el World Economic Forum como infraestructura modular para interacción humano-máquina ética, 
                abordando preocupaciones críticas de sesgo, privacidad e inequidad en sistemas de IA.
              </p>
            </div>
          </div>
        </Card>
      </div>
    </section>
  );
};

export default ComplianceCertifications;
