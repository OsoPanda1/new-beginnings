import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ExternalLink, BookOpen, FileText, Video } from "lucide-react";
import ecosystemVisual from "@/assets/ecosystem-visual.jpg";

const BlogIntegration = () => {
  return (
    <section className="relative py-24 overflow-hidden">
      {/* Background Visual */}
      <div 
        className="absolute inset-0 opacity-10 bg-cover bg-center"
        style={{ backgroundImage: `url(${ecosystemVisual})` }}
      />

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-gradient">Centro de Conocimiento</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Documentación completa, blog oficial y recursos para desarrolladores
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {/* Blog Oficial */}
          <Card className="glass-effect p-8 space-y-6 hover:glow-quantum transition-all duration-300 border-border/50">
            <div className="flex items-start gap-4">
              <div className="w-14 h-14 rounded-2xl bg-primary/20 flex items-center justify-center">
                <BookOpen className="w-7 h-7 text-primary" />
              </div>
              <div className="flex-1">
                <h3 className="text-2xl font-bold mb-2">Blog del Proyecto</h3>
                <p className="text-sm text-muted-foreground">
                  Actualizaciones oficiales, artículos técnicos y visión del ecosistema
                </p>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <div className="w-2 h-2 rounded-full bg-quantum animate-pulse" />
                <span>Actualizaciones en tiempo real</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <div className="w-2 h-2 rounded-full bg-secondary" />
                <span>Análisis técnico profundo</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <div className="w-2 h-2 rounded-full bg-accent" />
                <span>Visión y filosofía del proyecto</span>
              </div>
            </div>

            <Button 
              variant="default" 
              className="w-full"
              onClick={() => window.open('https://tamvonlinenetwork.blogspot.com', '_blank')}
            >
              <ExternalLink className="w-5 h-5" />
              Visitar Blog Oficial
            </Button>
          </Card>

          {/* Documentación Técnica */}
          <Card className="glass-effect p-8 space-y-6 hover:glow-quantum transition-all duration-300 border-border/50">
            <div className="flex items-start gap-4">
              <div className="w-14 h-14 rounded-2xl bg-secondary/20 flex items-center justify-center">
                <FileText className="w-7 h-7 text-secondary" />
              </div>
              <div className="flex-1">
                <h3 className="text-2xl font-bold mb-2">Documentación</h3>
                <p className="text-sm text-muted-foreground">
                  Guías completas para desarrolladores e integradores
                </p>
              </div>
            </div>

            <div className="space-y-3">
              <a href="#" className="block p-3 rounded-lg bg-card/30 hover:bg-card/50 transition-colors">
                <div className="font-semibold text-sm">API Reference</div>
                <div className="text-xs text-muted-foreground">Documentación completa de APIs</div>
              </a>
              <a href="#" className="block p-3 rounded-lg bg-card/30 hover:bg-card/50 transition-colors">
                <div className="font-semibold text-sm">SDK & Libraries</div>
                <div className="text-xs text-muted-foreground">Herramientas para desarrolladores</div>
              </a>
              <a href="#" className="block p-3 rounded-lg bg-card/30 hover:bg-card/50 transition-colors">
                <div className="font-semibold text-sm">Architecture Guides</div>
                <div className="text-xs text-muted-foreground">Especificaciones técnicas detalladas</div>
              </a>
            </div>

            <Button variant="secondary" className="w-full">
              Explorar Documentación
            </Button>
          </Card>

          {/* Video Resources */}
          <Card className="md:col-span-2 glass-effect p-8 space-y-6 border-border/50">
            <div className="flex items-start gap-4">
              <div className="w-14 h-14 rounded-2xl bg-accent/20 flex items-center justify-center">
                <Video className="w-7 h-7 text-accent" />
              </div>
              <div className="flex-1">
                <h3 className="text-2xl font-bold mb-2">Recursos Multimedia</h3>
                <p className="text-sm text-muted-foreground">
                  Videos explicativos, demos técnicas y presentaciones del ecosistema
                </p>
              </div>
            </div>

            <div className="grid md:grid-cols-3 gap-4">
              <div className="bg-card/30 rounded-lg p-4 hover:bg-card/50 transition-colors cursor-pointer">
                <div className="aspect-video bg-muted/20 rounded-lg mb-3 flex items-center justify-center">
                  <Video className="w-8 h-8 text-muted-foreground" />
                </div>
                <div className="font-semibold text-sm">Introducción a TAMV</div>
                <div className="text-xs text-muted-foreground">5:30 min</div>
              </div>

              <div className="bg-card/30 rounded-lg p-4 hover:bg-card/50 transition-colors cursor-pointer">
                <div className="aspect-video bg-muted/20 rounded-lg mb-3 flex items-center justify-center">
                  <Video className="w-8 h-8 text-muted-foreground" />
                </div>
                <div className="font-semibold text-sm">Isabella AI Demo</div>
                <div className="text-xs text-muted-foreground">8:15 min</div>
              </div>

              <div className="bg-card/30 rounded-lg p-4 hover:bg-card/50 transition-colors cursor-pointer">
                <div className="aspect-video bg-muted/20 rounded-lg mb-3 flex items-center justify-center">
                  <Video className="w-8 h-8 text-muted-foreground" />
                </div>
                <div className="font-semibold text-sm">Arquitectura Técnica</div>
                <div className="text-xs text-muted-foreground">12:45 min</div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default BlogIntegration;
