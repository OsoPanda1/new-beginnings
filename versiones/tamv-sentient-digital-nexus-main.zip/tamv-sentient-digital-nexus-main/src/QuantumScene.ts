import * as THREE from "three";
import { useEffect } from "react";

export default function QuantumScene() {
  useEffect(() => {
    const canvas = document.getElementById("tamv-bg-quantum") as HTMLCanvasElement;
    const renderer = new THREE.WebGLRenderer({ canvas, alpha: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(60, innerWidth/innerHeight, 1, 1000);
    camera.position.z = 400;

    const geometry = new THREE.BufferGeometry();
    const vertices = Array.from({length: 1200},()=>[
      THREE.MathUtils.randFloatSpread(800),
      THREE.MathUtils.randFloatSpread(800),
      THREE.MathUtils.randFloatSpread(800)
    ]).flat();
    geometry.setAttribute("position", new THREE.Float32BufferAttribute(vertices,3));
    const material = new THREE.PointsMaterial({color:0x00ffff, size:2, transparent:true, opacity:0.6});
    const points = new THREE.Points(geometry, material);
    scene.add(points);

    function animate(){
      requestAnimationFrame(animate);
      points.rotation.x += 0.0008;
      points.rotation.y += 0.0012;
      renderer.render(scene,camera);
    }
    animate();

    window.addEventListener("resize",()=>{
      renderer.setSize(innerWidth,innerHeight);
      camera.aspect = innerWidth/innerHeight;
      camera.updateProjectionMatrix();
    });
  },[]);
  return null;
}
