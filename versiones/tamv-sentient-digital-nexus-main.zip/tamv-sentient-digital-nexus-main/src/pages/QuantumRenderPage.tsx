import { Cpu, Layers, Sparkles, Zap, Box, Eye } from "lucide-react";
import PageTransition from "@/components/PageTransition";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useState, useEffect } from "react";

const quantumMetrics = [
  { label: "Coherencia Cuántica", value: 0, target: 95.3, unit: "%" },
  { label: "Entrelazamiento", value: 0, target: 92.7, unit: "%" },
  { label: "Optimización", value: 0, target: 98.1, unit: "%" },
  { label: "Calidad Visual", value: 0, target: 99.5, unit: "%" },
];

const renderingFeatures = [
  {
    icon: Layers,
    title: "7 Capas de Realidad",
    description: "Renderizado multidimensional con soporte 3D/4D/5D completo",
    color: "primary",
  },
  {
    icon: Sparkles,
    title: "Ray-Tracing Cuántico",
    description: "Iluminación global con trazado de rayos en superposición cuántica",
    color: "quantum",
  },
  {
    icon: Box,
    title: "Geometría Neural",
    description: "Generación procedural de formas mediante redes neuronales",
    color: "secondary",
  },
  {
    icon: Eye,
    title: "Percepción Adaptativa",
    description: "Ajuste automático según capacidad visual y preferencias del usuario",
    color: "accent",
  },
];

const dreamSpacesTypes = [
  {
    name: "Cathedral Space",
    description: "Espacios arquitectónicos majestuosos con reverberación holográfica",
    complexity: "Alta",
    immersion: "98%",
  },
  {
    name: "Quantum Garden",
    description: "Jardines imposibles con física cuántica visible y manipulable",
    complexity: "Extrema",
    immersion: "99%",
  },
  {
    name: "Neural Observatory",
    description: "Visualización de redes neuronales en tiempo real 4D",
    complexity: "Moderada",
    immersion: "96%",
  },
  {
    name: "Temporal Chamber",
    description: "Espacios donde el tiempo fluye de manera no-lineal",
    complexity: "Extrema",
    immersion: "97%",
  },
];

const QuantumRenderPage = () => {
  const [metrics, setMetrics] = useState(quantumMetrics);
  const [isOptimizing, setIsOptimizing] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setMetrics(prev =>
        prev.map(metric => ({
          ...metric,
          value: Math.min(metric.target, metric.value + Math.random() * 3),
        }))
      );
    }, 100);

    return () => clearInterval(interval);
  }, []);

  const handleOptimize = () => {
    setIsOptimizing(true);
    setTimeout(() => {
      setMetrics(prev =>
        prev.map(metric => ({
          ...metric,
          value: metric.target,
        }))
      );
      setIsOptimizing(false);
    }, 2000);
  };

  return (
    <PageTransition>
      <div className="min-h-screen py-20">
        {/* Hero Section */}
        <section className="container mx-auto px-4 mb-20">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center space-y-6"
          >
            <div className="inline-flex items-center gap-3 glass-effect px-6 py-3 rounded-full">
              <Cpu className="w-6 h-6 text-quantum" />
              <span className="text-gradient font-bold text-lg">Quantum HyperRender™</span>
            </div>
            
            <h1 className="text-gradient max-w-4xl mx-auto">
              Motor de Renderizado Cuántico 4D
            </h1>
            
            <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto">
              Visualización hiperrealista con ray-tracing cuántico y Dream Spaces 
              adaptativos conscientes del estado emocional
            </p>

            {/* Quantum Visualization */}
            <div className="relative w-64 h-64 mx-auto mt-12">
              {[...Array(3)].map((_, i) => (
                <motion.div
                  key={i}
                  className="absolute inset-0 border-2 border-quantum/30 rounded-lg"
                  style={{
                    transform: `rotateY(${i * 15}deg) rotateX(${i * 10}deg)`,
                  }}
                  animate={{
                    rotateZ: 360,
                  }}
                  transition={{
                    duration: 20 + i * 5,
                    repeat: Infinity,
                    ease: "linear",
                  }}
                />
              ))}
              <div className="absolute inset-0 flex items-center justify-center">
                <motion.div
                  className="w-32 h-32 rounded-full gradient-quantum opacity-50 blur-xl"
                  animate={{
                    scale: [1, 1.5, 1],
                    opacity: [0.5, 0.8, 0.5],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                />
              </div>
            </div>
          </motion.div>
        </section>

        {/* Quantum Metrics */}
        <section className="container mx-auto px-4 mb-20">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Estado del Sistema Cuántico
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {metrics.map((metric, index) => (
              <motion.div
                key={metric.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="glass-effect p-6 hover:glow-quantum transition-all duration-300">
                  <div className="text-sm text-muted-foreground mb-2">
                    {metric.label}
                  </div>
                  <div className="text-4xl font-bold text-quantum mb-4">
                    {metric.value.toFixed(1)}{metric.unit}
                  </div>
                  <div className="h-2 bg-background rounded-full overflow-hidden">
                    <motion.div
                      className="h-full bg-quantum"
                      initial={{ width: 0 }}
                      animate={{ width: `${(metric.value / metric.target) * 100}%` }}
                      transition={{ duration: 0.5 }}
                    />
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
          <div className="text-center">
            <button
              onClick={handleOptimize}
              disabled={isOptimizing}
              className="glass-effect px-8 py-3 rounded-full font-bold border-2 border-quantum text-quantum hover:bg-quantum/10 transition-all disabled:opacity-50"
            >
              {isOptimizing ? "Optimizando..." : "Ejecutar Optimización Cuántica"}
            </button>
          </div>
        </section>

        {/* Rendering Features */}
        <section className="container mx-auto px-4 mb-20">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Características de Renderizado
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {renderingFeatures.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="glass-effect p-6 h-full hover:glow-quantum transition-all duration-300 group">
                    <div 
                      className="w-12 h-12 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform mb-4"
                      style={{ backgroundColor: `hsl(var(--${feature.color}) / 0.2)` }}
                    >
                      <Icon 
                        className="w-6 h-6"
                        style={{ color: `hsl(var(--${feature.color}))` }}
                      />
                    </div>
                    <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                    <p className="text-muted-foreground text-sm">
                      {feature.description}
                    </p>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </section>

        {/* Dream Spaces */}
        <section className="container mx-auto px-4 mb-20">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Dream Spaces Disponibles
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            {dreamSpacesTypes.map((space, index) => (
              <motion.div
                key={space.name}
                initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.15 }}
              >
                <Card className="glass-effect p-6 border-quantum/30 hover:border-quantum transition-all duration-300">
                  <h3 className="text-2xl font-bold mb-3 text-quantum">
                    {space.name}
                  </h3>
                  <p className="text-muted-foreground mb-4">
                    {space.description}
                  </p>
                  <div className="flex gap-3">
                    <Badge variant="outline" className="border-quantum text-quantum">
                      {space.complexity} Complejidad
                    </Badge>
                    <Badge variant="outline" className="border-primary text-primary">
                      {space.immersion} Inmersión
                    </Badge>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Technical Pipeline */}
        <section className="container mx-auto px-4 mb-20">
          <Card className="glass-effect p-8 md:p-12 border-quantum/30 glow-quantum">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-8">
              Pipeline de Renderizado Cuántico
            </h2>
            <div className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-quantum">Fase Cuántica</h3>
                  <ul className="space-y-2 text-muted-foreground">
                    <li>• Superposición de estados visuales</li>
                    <li>• Entrelazamiento de texturas</li>
                    <li>• Ray-tracing en qubits</li>
                    <li>• Optimización cuántica de iluminación</li>
                    <li>• Medición selectiva de pixeles</li>
                  </ul>
                </div>
                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-quantum">Fase Neural</h3>
                  <ul className="space-y-2 text-muted-foreground">
                    <li>• Generación procedural IA</li>
                    <li>• Upscaling neural 8K→16K</li>
                    <li>• Anti-aliasing temporal ML</li>
                    <li>• Denoising adaptativo</li>
                    <li>• Color grading emocional</li>
                  </ul>
                </div>
              </div>

              <div className="pt-6 border-t border-border/30">
                <h3 className="text-xl font-bold mb-4 text-center">Flujo de Procesamiento</h3>
                <div className="flex flex-col md:flex-row items-center justify-center gap-4">
                  {["Geometría", "Iluminación", "Texturizado", "Quantum RT", "Post-FX", "Neural Enhance", "Output"].map((step, i) => (
                    <div key={step} className="flex items-center gap-4">
                      <div className="glass-effect px-4 py-2 rounded-lg text-sm font-semibold border border-quantum/30">
                        {step}
                      </div>
                      {i < 6 && <div className="hidden md:block text-quantum">→</div>}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </Card>
        </section>

        {/* Promise */}
        <section className="container mx-auto px-4">
          <Card className="glass-effect p-8 md:p-12 text-center border-quantum/30">
            <Sparkles className="w-16 h-16 text-quantum mx-auto mb-6" />
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gradient">
              La Visión HyperRender
            </h2>
            <div className="max-w-3xl mx-auto space-y-4 text-lg text-muted-foreground">
              <p>
                Quantum HyperRender™ no genera gráficos, crea realidades. 
                Cada fotón virtual es calculado con precisión cuántica, cada sombra 
                renderizada considerando infinitas trayectorias de luz en superposición.
              </p>
              <p>
                Los Dream Spaces no son escenarios estáticos—son universos vivos 
                que responden a tu estado emocional, evolucionan con tus preferencias 
                y trascienden las limitaciones de la física clásica.
              </p>
              <p className="text-xl font-bold text-quantum pt-4">
                "Donde la realidad termina, HyperRender comienza."
              </p>
            </div>
          </Card>
        </section>
      </div>
    </PageTransition>
  );
};

export default QuantumRenderPage;