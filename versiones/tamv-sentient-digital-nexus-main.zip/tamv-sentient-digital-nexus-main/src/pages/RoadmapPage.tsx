import Roadmap from "@/components/Roadmap";
import PageTransition from "@/components/PageTransition";

const RoadmapPage = () => {
  return (
    <PageTransition>
      <div className="min-h-screen">
        <Roadmap />
      </div>
    </PageTransition>
  );
};

export default RoadmapPage;
