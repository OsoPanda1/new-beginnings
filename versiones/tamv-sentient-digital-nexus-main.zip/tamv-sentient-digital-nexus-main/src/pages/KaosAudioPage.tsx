import { Headphones, Waves, Zap, Volume2, Radio, Sliders } from "lucide-react";
import PageTransition from "@/components/PageTransition";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const audioFeatures = [
  {
    icon: Waves,
    title: "Espacialización 3D/4D",
    description: "Audio holográfico con posicionamiento sub-centímetro en 360°",
    specs: "Precisión: 0.8° ± 0.2°",
  },
  {
    icon: Volume2,
    title: "HRTF Personalizado",
    description: "Función de transferencia adaptada a tu anatomía craneal única",
    specs: "Match: 94.7%",
  },
  {
    icon: Zap,
    title: "Feedback Háptico",
    description: "Sincronización audio-táctil con latencia <1.5ms",
    specs: "Resolución: 256 puntos",
  },
  {
    icon: Radio,
    title: "Presintonías IA",
    description: "Perfiles adaptativos que evolucionan con tus preferencias",
    specs: "Aprendizaje continuo",
  },
];

const presets = [
  {
    category: "Espacios Arquitectónicos",
    items: [
      { name: "Cathedral Reverence", reverb: "8.5s", type: "Holográfico" },
      { name: "Concert Hall Vienna", width: "180°", type: "Reflexiones tempranas" },
      { name: "Intimate Jazz Club", proximity: "Alta", type: "Cálido" },
      { name: "Outdoor Amphitheater", delay: "Natural", type: "Atmosférico" },
    ],
  },
  {
    category: "Géneros Musicales",
    items: [
      { name: "Electronic Hyperspace", movement: "360° continuo", type: "Modulación" },
      { name: "Classical Orchestration", positioning: "Realista", type: "Dinámico" },
      { name: "Hip-Hop Urban", bass: "Intensificado", type: "Háptico" },
      { name: "Ambient Transcendence", layers: "Flotantes", type: "Respiratorio" },
    ],
  },
];

const technicalSpecs = [
  { label: "Frecuencia de Muestreo", value: "384 kHz" },
  { label: "Profundidad de Bits", value: "32-bit float" },
  { label: "Rango Dinámico", value: "140 dB" },
  { label: "THD+N", value: "<0.0003%" },
  { label: "Latencia Sistema", value: "1.2 ms" },
  { label: "Canales Simultáneos", value: "128+ objetos" },
];

const KaosAudioPage = () => {
  return (
    <PageTransition>
      <div className="min-h-screen py-20">
        {/* Hero Section */}
        <section className="container mx-auto px-4 mb-20">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center space-y-6"
          >
            <div className="inline-flex items-center gap-3 glass-effect px-6 py-3 rounded-full">
              <Headphones className="w-6 h-6 text-accent" />
              <span className="text-gradient font-bold text-lg">KAOS Audio System 3D/4D™</span>
            </div>
            
            <h1 className="text-gradient max-w-4xl mx-auto">
              Redefinición Multisensorial del Audio
            </h1>
            
            <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto">
              Motor de espacialización cuántica con feedback háptico sincronizado 
              y presintonías inteligentes adaptativas
            </p>

            {/* Audio Visualization */}
            <div className="relative w-full max-w-2xl h-64 mx-auto mt-12 glass-effect rounded-2xl overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-accent/20 via-primary/20 to-quantum/20" />
              <div className="absolute inset-0 flex items-center justify-center">
                <motion.div
                  className="flex items-end justify-center gap-2 h-32"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 1 }}
                >
                  {[...Array(32)].map((_, i) => (
                    <motion.div
                      key={i}
                      className="w-2 bg-gradient-to-t from-accent to-quantum rounded-full"
                      animate={{
                        height: [
                          `${Math.random() * 100}%`,
                          `${Math.random() * 100}%`,
                          `${Math.random() * 100}%`,
                        ],
                      }}
                      transition={{
                        duration: 1 + Math.random(),
                        repeat: Infinity,
                        ease: "easeInOut",
                      }}
                    />
                  ))}
                </motion.div>
              </div>
              <div className="absolute bottom-4 left-4 right-4 flex justify-between text-xs text-muted-foreground">
                <span>20Hz</span>
                <span>1kHz</span>
                <span>20kHz</span>
              </div>
            </div>
          </motion.div>
        </section>

        {/* Features Grid */}
        <section className="container mx-auto px-4 mb-20">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Características Revolucionarias
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {audioFeatures.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="glass-effect p-6 h-full hover:glow-accent transition-all duration-300 group">
                    <div className="w-12 h-12 rounded-xl bg-accent/20 flex items-center justify-center group-hover:scale-110 transition-transform mb-4">
                      <Icon className="w-6 h-6 text-accent" />
                    </div>
                    <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                    <p className="text-muted-foreground text-sm mb-3">
                      {feature.description}
                    </p>
                    <Badge variant="outline" className="border-accent text-accent">
                      {feature.specs}
                    </Badge>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </section>

        {/* Presets Categories */}
        <section className="container mx-auto px-4 mb-20">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Presintonías Inteligentes
          </h2>
          <div className="grid md:grid-cols-2 gap-8">
            {presets.map((category, index) => (
              <motion.div
                key={category.category}
                initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.2 }}
              >
                <Card className="glass-effect p-6 border-accent/30">
                  <h3 className="text-2xl font-bold mb-6 text-accent">
                    {category.category}
                  </h3>
                  <div className="space-y-4">
                    {category.items.map((preset) => (
                      <div
                        key={preset.name}
                        className="p-4 rounded-lg bg-background/50 border border-border hover:border-accent/50 transition-colors"
                      >
                        <div className="flex items-start justify-between">
                          <div>
                            <h4 className="font-bold mb-1">{preset.name}</h4>
                            <div className="text-sm text-muted-foreground space-y-1">
                              {Object.entries(preset)
                                .filter(([key]) => key !== "name")
                                .map(([key, value]) => (
                                  <div key={key}>
                                    <span className="text-accent">{key}:</span> {String(value)}
                                  </div>
                                ))}
                            </div>
                          </div>
                          <Sliders className="w-5 h-5 text-accent" />
                        </div>
                      </div>
                    ))}
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Technical Specifications */}
        <section className="container mx-auto px-4 mb-20">
          <Card className="glass-effect p-8 md:p-12 border-accent/30">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-8">
              Especificaciones Técnicas
            </h2>
            <div className="grid md:grid-cols-3 gap-6">
              {technicalSpecs.map((spec, index) => (
                <motion.div
                  key={spec.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="text-center p-4 rounded-lg bg-background/30"
                >
                  <div className="text-3xl font-bold text-accent mb-2">
                    {spec.value}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {spec.label}
                  </div>
                </motion.div>
              ))}
            </div>
          </Card>
        </section>

        {/* Redefinition Engine */}
        <section className="container mx-auto px-4 mb-20">
          <Card className="glass-effect p-8 md:p-12 border-accent/30 glow-accent">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-8">
              Motor de Redefinición de Audio
            </h2>
            <div className="space-y-6">
              <p className="text-center text-lg text-muted-foreground max-w-3xl mx-auto">
                Análisis profundo y resíntesis espacial que transforma cualquier fuente 
                en experiencias multisensoriales inmersivas
              </p>
              
              <div className="grid md:grid-cols-2 gap-6 mt-8">
                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-quantum">Análisis Estructural</h3>
                  <ul className="space-y-2 text-muted-foreground">
                    <li>• Separación de fuentes IA ultra-precisa</li>
                    <li>• Extracción de ambientes acústicos</li>
                    <li>• Detección de transientes &lt; 0.1ms</li>
                    <li>• Análisis armónico espectral completo</li>
                  </ul>
                </div>
                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-quantum">Resíntesis Espacial</h3>
                  <ul className="space-y-2 text-muted-foreground">
                    <li>• Reposicionamiento 3D sin artefactos</li>
                    <li>• Modificación temporal transparente</li>
                    <li>• Enriquecimiento armónico adaptativo</li>
                    <li>• Renderización háptica sincronizada</li>
                  </ul>
                </div>
              </div>
            </div>
          </Card>
        </section>

        {/* Experience Promise */}
        <section className="container mx-auto px-4">
          <Card className="glass-effect p-8 md:p-12 text-center border-accent/30">
            <Headphones className="w-16 h-16 text-accent mx-auto mb-6" />
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gradient">
              La Promesa KAOS
            </h2>
            <div className="max-w-3xl mx-auto space-y-4 text-lg text-muted-foreground">
              <p>
                KAOS Audio System™ no reproduce sonido, lo recrea. Cada frecuencia, 
                cada matiz, cada detalle espacial es analizado, optimizado y renderizado 
                para tocar no solo tus oídos, sino tu ser completo.
              </p>
              <p>
                Con inteligencia artificial que aprende de ti y tecnología háptica 
                que convierte el audio en sensación física, KAOS transforma la escucha 
                en una experiencia multidimensional inolvidable.
              </p>
              <p className="text-xl font-bold text-accent pt-4">
                "Donde otros reproducen, KAOS recrea."
              </p>
            </div>
          </Card>
        </section>
      </div>
    </PageTransition>
  );
};

export default KaosAudioPage;