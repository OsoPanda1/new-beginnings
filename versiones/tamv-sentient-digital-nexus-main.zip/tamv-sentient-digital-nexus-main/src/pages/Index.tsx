import MetaverseHub from "./MetaverseHub";

const Index = () => {
  return <MetaverseHub />;
};

export default Index;
