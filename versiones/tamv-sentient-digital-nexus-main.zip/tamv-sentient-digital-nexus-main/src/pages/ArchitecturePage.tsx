import TechnicalArchitecture from "@/components/TechnicalArchitecture";
import TechStack from "@/components/TechStack";
import PageTransition from "@/components/PageTransition";

const ArchitecturePage = () => {
  return (
    <PageTransition>
      <div className="min-h-screen">
        <TechnicalArchitecture />
        <TechStack />
      </div>
    </PageTransition>
  );
};

export default ArchitecturePage;
