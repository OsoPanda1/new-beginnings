import Philosophy from "@/components/Philosophy";
import PageTransition from "@/components/PageTransition";

const PhilosophyPage = () => {
  return (
    <PageTransition>
      <div className="min-h-screen">
        <Philosophy />
      </div>
    </PageTransition>
  );
};

export default PhilosophyPage;
