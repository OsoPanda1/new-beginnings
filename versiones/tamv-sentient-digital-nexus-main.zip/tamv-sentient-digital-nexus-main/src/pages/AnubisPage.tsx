import { Shield, Eye, Lock, Zap, AlertTriangle, CheckCircle, Activity, Cpu } from "lucide-react";
import PageTransition from "@/components/PageTransition";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const securityLayers = [
  {
    id: "1",
    name: "Radar Ojo de Ra",
    description: "Monitoreo solar de consenso cuántico multidimensional",
    status: "active",
    threat_level: 0,
    icon: Eye,
  },
  {
    id: "2",
    name: "Radar Ojo de Quetzalcóatl",
    description: "Resonancia terrestre con sincronización cuántica entrelazada",
    status: "active",
    threat_level: 0,
    icon: Eye,
  },
  {
    id: "3",
    name: "Quantum Vault",
    description: "Inmutabilidad cuántica con blockchain post-cuántica",
    status: "active",
    threat_level: 0,
    icon: Lock,
  },
  {
    id: "4",
    name: "Predicción Temporal",
    description: "Detección predictiva de amenazas con análisis temporal",
    status: "active",
    threat_level: 0,
    icon: Activity,
  },
];

const securityMetrics = [
  { label: "Coherencia Cuántica", value: 99.95, color: "primary" },
  { label: "Predicción Amenazas", value: 99.99, color: "quantum" },
  { label: "Inmutabilidad", value: 100, color: "secondary" },
  { label: "Tiempo Respuesta", value: 98.7, color: "accent" },
];

const protectionModules = [
  {
    category: "Protección Perimetral",
    items: [
      "Firewall cuántico de 12 capas",
      "DDoS mitigation con IA predictiva",
      "Geo-blocking multidimensional",
      "Rate limiting adaptativo",
    ],
  },
  {
    category: "Criptografía Avanzada",
    items: [
      "Cifrado post-cuántico Kyber/Dilithium",
      "Zero-knowledge proofs nativos",
      "Homomorphic encryption disponible",
      "Quantum key distribution (QKD)",
    ],
  },
  {
    category: "Detección de Intrusión",
    items: [
      "ML models para anomalías de comportamiento",
      "Honeypots distribuidos inteligentes",
      "Threat intelligence en tiempo real",
      "Forensics automatizado",
    ],
  },
  {
    category: "Resiliencia y Recuperación",
    items: [
      "Backup inmutable multidimensional",
      "Disaster recovery automático <5min",
      "Redundancia geográfica N+3",
      "Time-travel recovery cuántico",
    ],
  },
];

const AnubisPage = () => {
  return (
    <PageTransition>
      <div className="min-h-screen py-20">
        {/* Hero Section */}
        <section className="container mx-auto px-4 mb-20">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center space-y-6"
          >
            <div className="inline-flex items-center gap-3 glass-effect px-6 py-3 rounded-full">
              <Shield className="w-6 h-6 text-secondary" />
              <span className="text-gradient font-bold text-lg">Anubis Sentinel System™</span>
            </div>
            
            <h1 className="text-gradient max-w-4xl mx-auto">
              Defensa Multidimensional Postcuántica
            </h1>
            
            <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto">
              12 capas de protección inmutable con detección predictiva temporal 
              y respaldo cuántico blockchain
            </p>

            {/* Security Status Orb */}
            <div className="relative w-48 h-48 mx-auto mt-12">
              <motion.div
                className="absolute inset-0 rounded-full gradient-secondary opacity-30 blur-3xl"
                animate={{
                  scale: [1, 1.2, 1],
                  opacity: [0.3, 0.5, 0.3],
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
              />
              <motion.div
                className="absolute inset-8 rounded-full border-4 border-secondary/50"
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              />
              <motion.div
                className="absolute inset-12 rounded-full border-4 border-accent/50"
                animate={{ rotate: -360 }}
                transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <Shield className="w-16 h-16 text-secondary" />
              </div>
            </div>
          </motion.div>
        </section>

        {/* Security Metrics */}
        <section className="container mx-auto px-4 mb-20">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Métricas de Seguridad en Tiempo Real
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {securityMetrics.map((metric, index) => (
              <motion.div
                key={metric.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="glass-effect p-6 text-center hover:glow-quantum transition-all duration-300">
                  <div className="text-5xl font-bold text-gradient mb-2">
                    {metric.value}%
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {metric.label}
                  </div>
                  <div className="mt-4 h-2 bg-background rounded-full overflow-hidden">
                    <motion.div
                      className="h-full"
                      style={{ backgroundColor: `hsl(var(--${metric.color}))` }}
                      initial={{ width: 0 }}
                      animate={{ width: `${metric.value}%` }}
                      transition={{ duration: 1, delay: index * 0.1 }}
                    />
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Security Layers */}
        <section className="container mx-auto px-4 mb-20">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Capas de Protección Activas
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            {securityLayers.map((layer, index) => {
              const Icon = layer.icon;
              return (
                <motion.div
                  key={layer.id}
                  initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.15 }}
                >
                  <Card className="glass-effect p-6 border-secondary/30 hover:border-secondary transition-all duration-300">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-xl bg-secondary/20 flex items-center justify-center">
                          <Icon className="w-6 h-6 text-secondary" />
                        </div>
                        <div>
                          <h3 className="text-xl font-bold">{layer.name}</h3>
                          <Badge variant="outline" className="mt-1 border-secondary text-secondary">
                            {layer.status.toUpperCase()}
                          </Badge>
                        </div>
                      </div>
                      <CheckCircle className="w-6 h-6 text-secondary" />
                    </div>
                    <p className="text-muted-foreground text-sm mb-4">
                      {layer.description}
                    </p>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-muted-foreground">Nivel de Amenaza</span>
                      <span className="text-secondary font-bold">{layer.threat_level}%</span>
                    </div>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </section>

        {/* Protection Modules */}
        <section className="container mx-auto px-4 mb-20">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Módulos de Protección Avanzada
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            {protectionModules.map((module, index) => (
              <motion.div
                key={module.category}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.15 }}
              >
                <Card className="glass-effect p-6 h-full border-border/50">
                  <h3 className="text-xl font-bold mb-4 text-secondary">
                    {module.category}
                  </h3>
                  <ul className="space-y-3">
                    {module.items.map((item) => (
                      <li key={item} className="flex items-start gap-2 text-muted-foreground">
                        <Zap className="w-4 h-4 text-quantum mt-1 flex-shrink-0" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </Card>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Technical Architecture */}
        <section className="container mx-auto px-4 mb-20">
          <Card className="glass-effect p-8 md:p-12 border-secondary/30 glow-secondary">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-8">
              Arquitectura de Defensa Cuántica
            </h2>
            <div className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-quantum">Capa Cuántica</h3>
                  <ul className="space-y-2 text-muted-foreground">
                    <li>• Quantum Key Distribution (QKD)</li>
                    <li>• Entrelazamiento cuántico para detección</li>
                    <li>• Superposición de estados de seguridad</li>
                    <li>• Medición cuántica no-clásica</li>
                    <li>• Teleportación cuántica segura</li>
                  </ul>
                </div>
                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-quantum">Capa Clásica Reforzada</h3>
                  <ul className="space-y-2 text-muted-foreground">
                    <li>• AES-256-GCM encryption</li>
                    <li>• RSA-4096 key exchange</li>
                    <li>• SHA-3 hashing</li>
                    <li>• HMAC-SHA-512 authentication</li>
                    <li>• Perfect forward secrecy (PFS)</li>
                  </ul>
                </div>
              </div>

              <div className="pt-6 border-t border-border/30">
                <h3 className="text-xl font-bold mb-4 text-center">Pipeline de Protección</h3>
                <div className="flex flex-col md:flex-row items-center justify-center gap-4">
                  {["Detección", "Análisis", "Predicción", "Contención", "Neutralización", "Recuperación", "Aprendizaje"].map((step, i) => (
                    <div key={step} className="flex items-center gap-4">
                      <div className="glass-effect px-4 py-2 rounded-lg text-sm font-semibold border border-secondary/30">
                        {step}
                      </div>
                      {i < 6 && <div className="hidden md:block text-secondary">→</div>}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </Card>
        </section>

        {/* Promise */}
        <section className="container mx-auto px-4">
          <Card className="glass-effect p-8 md:p-12 text-center border-secondary/30">
            <AlertTriangle className="w-16 h-16 text-secondary mx-auto mb-6" />
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gradient">
              Promesa Anubis
            </h2>
            <div className="max-w-3xl mx-auto space-y-4 text-lg text-muted-foreground">
              <p>
                Anubis Sentinel™ es el guardián inquebrantable del ecosistema TAMV. 
                Cada dato, cada transacción, cada interacción está protegida por tecnología 
                que supera los estándares actuales de seguridad.
              </p>
              <p>
                Con predicción temporal de amenazas y respaldo cuántico blockchain, 
                garantizamos que tu dignidad digital permanezca inviolable ante cualquier ataque, 
                presente o futuro.
              </p>
              <p className="text-xl font-bold text-secondary pt-4">
                "Tu seguridad es nuestra razón de existir."
              </p>
            </div>
          </Card>
        </section>
      </div>
    </PageTransition>
  );
};

export default AnubisPage;