import BlogIntegration from "@/components/BlogIntegration";
import PageTransition from "@/components/PageTransition";

const BlogPage = () => {
  return (
    <PageTransition>
      <div className="min-h-screen">
        <BlogIntegration />
      </div>
    </PageTransition>
  );
};

export default BlogPage;
