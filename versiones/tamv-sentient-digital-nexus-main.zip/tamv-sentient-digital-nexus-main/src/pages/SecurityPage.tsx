import SecurityInfrastructure from "@/components/SecurityInfrastructure";
import ComplianceCertifications from "@/components/ComplianceCertifications";
import PageTransition from "@/components/PageTransition";

const SecurityPage = () => {
  return (
    <PageTransition>
      <div className="min-h-screen">
        <SecurityInfrastructure />
        <ComplianceCertifications />
      </div>
    </PageTransition>
  );
};

export default SecurityPage;
