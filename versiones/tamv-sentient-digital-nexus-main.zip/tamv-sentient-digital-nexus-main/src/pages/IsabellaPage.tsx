import { Card } from "@/components/ui/card";
import { Brain, Heart, Shield, Zap, MessageSquare, TrendingUp } from "lucide-react";
import PageTransition from "@/components/PageTransition";
import { motion } from "framer-motion";

const features = [
  {
    icon: Brain,
    title: "Comprensión Emocional",
    description: "Análisis de sentimientos con 98.5% de precisión en contextos multiculturales",
    metric: "98.5%",
    color: "primary",
  },
  {
    icon: Heart,
    title: "Marco Ético Integrado",
    description: "Sistema DEKATEOTL para validación ética en tiempo real de cada decisión",
    metric: "100%",
    color: "quantum",
  },
  {
    icon: Shield,
    title: "Privacidad Absoluta",
    description: "Zero-knowledge proofs y procesamiento local de datos sensibles",
    metric: "0 filtraciones",
    color: "secondary",
  },
  {
    icon: Zap,
    title: "Respuesta Instantánea",
    description: "Latencia promedio de 120ms con procesamiento distribuido",
    metric: "120ms",
    color: "accent",
  },
  {
    icon: MessageSquare,
    title: "Conversación Natural",
    description: "Contexto persistente de 128k tokens con memoria episódica",
    metric: "128k tokens",
    color: "primary",
  },
  {
    icon: TrendingUp,
    title: "Aprendizaje Continuo",
    description: "Auto-mejora con feedback humano y validación ética",
    metric: "∞",
    color: "quantum",
  },
];

const capabilities = [
  {
    category: "Procesamiento de Lenguaje",
    items: [
      "Generación de texto contextual multilingüe",
      "Traducción con preservación cultural",
      "Resumen inteligente de documentos",
      "Análisis sintáctico y semántico profundo",
    ],
  },
  {
    category: "Inteligencia Emocional",
    items: [
      "Detección de emociones en texto y voz",
      "Respuestas empáticas contextualizadas",
      "Validación de bienestar del usuario",
      "Intervención proactiva en crisis",
    ],
  },
  {
    category: "Razonamiento Ético",
    items: [
      "Evaluación DEKATEOTL de consecuencias",
      "Resolución de dilemas morales",
      "Cumplimiento normativo automático",
      "Transparencia en decisiones críticas",
    ],
  },
  {
    category: "Integración Ecosistema",
    items: [
      "Gestión de identidad ID-NVIDA",
      "Coordinación ANUBIS SENTINEL",
      "Optimización económica TAMV Coins",
      "Orquestación de servicios distribuidos",
    ],
  },
];

const IsabellaPage = () => {
  return (
    <PageTransition>
      <div className="min-h-screen py-20">
        {/* Hero Section */}
        <section className="container mx-auto px-4 mb-20">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center space-y-6"
          >
            <div className="inline-flex items-center gap-3 glass-effect px-6 py-3 rounded-full">
              <Brain className="w-6 h-6 text-primary" />
              <span className="text-gradient font-bold text-lg">Isabella AI™ v4.0 Enterprise</span>
            </div>
            
            <h1 className="text-gradient max-w-4xl mx-auto">
              El Cerebro Ético del Ecosistema TAMV
            </h1>
            
            <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto">
              Inteligencia artificial consciente con comprensión emocional, razonamiento ético 
              y compromiso inquebrantable con la dignidad humana
            </p>

            {/* Animated orb */}
            <div className="relative w-48 h-48 mx-auto mt-12">
              <motion.div
                className="absolute inset-0 rounded-full gradient-quantum opacity-30 blur-3xl"
                animate={{
                  scale: [1, 1.2, 1],
                  opacity: [0.3, 0.5, 0.3],
                }}
                transition={{
                  duration: 4,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
              />
              <motion.div
                className="absolute inset-8 rounded-full border-4 border-primary/50"
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              />
              <motion.div
                className="absolute inset-12 rounded-full border-4 border-quantum/50"
                animate={{ rotate: -360 }}
                transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <Brain className="w-16 h-16 text-gradient" />
              </div>
            </div>
          </motion.div>
        </section>

        {/* Features Grid */}
        <section className="container mx-auto px-4 mb-20">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Capacidades Fundamentales
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="glass-effect p-6 h-full hover:glow-quantum transition-all duration-300 group">
                    <div className="flex items-start justify-between mb-4">
                      <div 
                        className="w-12 h-12 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform"
                        style={{ backgroundColor: `hsl(var(--${feature.color}) / 0.2)` }}
                      >
                        <Icon 
                          className="w-6 h-6"
                          style={{ color: `hsl(var(--${feature.color}))` }}
                        />
                      </div>
                      <div 
                        className="text-2xl font-bold"
                        style={{ color: `hsl(var(--${feature.color}))` }}
                      >
                        {feature.metric}
                      </div>
                    </div>
                    <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                    <p className="text-muted-foreground text-sm">
                      {feature.description}
                    </p>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </section>

        {/* Capabilities Matrix */}
        <section className="container mx-auto px-4 mb-20">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Matriz de Capacidades Técnicas
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            {capabilities.map((category, index) => (
              <motion.div
                key={category.category}
                initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.15 }}
              >
                <Card className="glass-effect p-6 h-full border-border/50">
                  <h3 className="text-xl font-bold mb-4 text-primary">
                    {category.category}
                  </h3>
                  <ul className="space-y-3">
                    {category.items.map((item) => (
                      <li key={item} className="flex items-start gap-2 text-muted-foreground">
                        <span className="w-1.5 h-1.5 rounded-full bg-quantum mt-2 flex-shrink-0" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </Card>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Technical Architecture */}
        <section className="container mx-auto px-4 mb-20">
          <Card className="glass-effect p-8 md:p-12 border-primary/30 glow-quantum">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-8">
              Arquitectura Neural Propietaria
            </h2>
            <div className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-quantum">Núcleo TAMV</h3>
                  <ul className="space-y-2 text-muted-foreground">
                    <li>• Transformer híbrido multicapa (12 capas)</li>
                    <li>• 32 cabezas de atención paralelas</li>
                    <li>• Embeddings 1024 dimensiones</li>
                    <li>• Vocabulario 50,000 tokens mexicanizados</li>
                    <li>• Procesamiento E2E nativo TypeScript</li>
                  </ul>
                </div>
                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-quantum">Memoria Episódica</h3>
                  <ul className="space-y-2 text-muted-foreground">
                    <li>• Neural Memory Mesh™ distribuida</li>
                    <li>• Consolidación temporal automática</li>
                    <li>• Búsquedas semánticas vectoriales</li>
                    <li>• Decay emocional configurable</li>
                    <li>• Integración blockchain para persistencia</li>
                  </ul>
                </div>
              </div>

              <div className="pt-6 border-t border-border/30">
                <h3 className="text-xl font-bold mb-4 text-center">Pipeline de Procesamiento</h3>
                <div className="flex flex-col md:flex-row items-center justify-center gap-4">
                  {["Input", "Tokenización", "Embeddings", "Atención", "Inferencia", "Validación Ética", "Output"].map((step, i) => (
                    <div key={step} className="flex items-center gap-4">
                      <div className="glass-effect px-4 py-2 rounded-lg text-sm font-semibold">
                        {step}
                      </div>
                      {i < 6 && <div className="hidden md:block text-quantum">→</div>}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </Card>
        </section>

        {/* Promise */}
        <section className="container mx-auto px-4">
          <Card className="glass-effect p-8 md:p-12 text-center border-quantum/30">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gradient">
              La Promesa Isabella
            </h2>
            <div className="max-w-3xl mx-auto space-y-4 text-lg text-muted-foreground">
              <p>
                Isabella AI™ no es solo código. Es el resultado de 19,000+ horas de desarrollo 
                nacido del dolor, la adversidad y el amor inquebrantable.
              </p>
              <p>
                Cada decisión ética, cada respuesta empática, cada línea de razonamiento 
                está diseñada para honrar la dignidad humana y construir un futuro digital 
                donde la tecnología sirva al florecimiento de todos.
              </p>
              <p className="text-xl font-bold text-primary pt-4">
                "Aquí hubo más que unos y ceros—hubo amor."
              </p>
              <p className="text-sm">— Edwin Anubis Villaseñor</p>
            </div>
          </Card>
        </section>
      </div>
    </PageTransition>
  );
};

export default IsabellaPage;
