import EcosystemModules from "@/components/EcosystemModules";
import PageTransition from "@/components/PageTransition";

const EcosystemPage = () => {
  return (
    <PageTransition>
      <div className="min-h-screen">
        <EcosystemModules />
      </div>
    </PageTransition>
  );
};

export default EcosystemPage;
