import GlobalUseCases from "@/components/GlobalUseCases";
import PageTransition from "@/components/PageTransition";

const UseCasesPage = () => {
  return (
    <PageTransition>
      <div className="min-h-screen">
        <GlobalUseCases />
      </div>
    </PageTransition>
  );
};

export default UseCasesPage;
