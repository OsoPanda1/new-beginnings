import { Suspense, useRef, useState, useEffect } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, Environment, Float, Text3D, useTexture, Sphere, Box, Torus, MeshDistortMaterial } from '@react-three/drei';
import * as THREE from 'three';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';

// Portal Component
const Portal = ({ position, color, label, route, onHover }: any) => {
  const meshRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);
  const navigate = useNavigate();

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y += 0.01;
      meshRef.current.rotation.x = Math.sin(state.clock.elapsedTime) * 0.1;
      if (hovered) {
        meshRef.current.scale.lerp(new THREE.Vector3(1.3, 1.3, 1.3), 0.1);
      } else {
        meshRef.current.scale.lerp(new THREE.Vector3(1, 1, 1), 0.1);
      }
    }
  });

  return (
    <Float speed={2} rotationIntensity={0.5} floatIntensity={0.5}>
      <group position={position}>
        <Torus
          ref={meshRef}
          args={[1, 0.4, 16, 100]}
          onPointerOver={() => {
            setHovered(true);
            onHover(label);
            document.body.style.cursor = 'pointer';
          }}
          onPointerOut={() => {
            setHovered(false);
            onHover(null);
            document.body.style.cursor = 'default';
          }}
          onClick={() => navigate(route)}
        >
          <MeshDistortMaterial
            color={color}
            attach="material"
            distort={0.3}
            speed={2}
            roughness={0}
            metalness={0.8}
          />
        </Torus>
        <pointLight position={[0, 0, 0]} intensity={2} color={color} distance={5} />
        <Text3D
          font="/fonts/optimer_regular.typeface.json"
          size={0.3}
          height={0.1}
          position={[-1, -2, 0]}
          rotation={[0, 0, 0]}
        >
          {label}
          <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.5} />
        </Text3D>
      </group>
    </Float>
  );
};

// Central Orb - Isabella AI
const IsabellaOrb = () => {
  const meshRef = useRef<THREE.Mesh>(null);
  
  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y = state.clock.elapsedTime * 0.5;
      meshRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.3) * 0.2;
    }
  });

  return (
    <Float speed={1} rotationIntensity={1} floatIntensity={2}>
      <Sphere ref={meshRef} args={[1.5, 64, 64]} position={[0, 0, 0]}>
        <MeshDistortMaterial
          color="#10B981"
          attach="material"
          distort={0.4}
          speed={2}
          roughness={0.1}
          metalness={0.9}
          emissive="#10B981"
          emissiveIntensity={0.5}
        />
      </Sphere>
      <pointLight position={[0, 0, 0]} intensity={3} color="#10B981" distance={10} />
    </Float>
  );
};

// Particle Field Background
const ParticleField = () => {
  const pointsRef = useRef<THREE.Points>(null);
  const particleCount = 5000;

  const positions = new Float32Array(particleCount * 3);
  for (let i = 0; i < particleCount; i++) {
    positions[i * 3] = (Math.random() - 0.5) * 100;
    positions[i * 3 + 1] = (Math.random() - 0.5) * 100;
    positions[i * 3 + 2] = (Math.random() - 0.5) * 100;
  }

  useFrame((state) => {
    if (pointsRef.current) {
      pointsRef.current.rotation.y = state.clock.elapsedTime * 0.05;
    }
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={particleCount}
          array={positions}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.05}
        color="#8B5CF6"
        transparent
        opacity={0.6}
        sizeAttenuation
      />
    </points>
  );
};

// 3D Scene
const MetaverseScene = ({ onPortalHover }: { onPortalHover: (label: string | null) => void }) => {
  return (
    <>
      <color attach="background" args={['#0A0118']} />
      <fog attach="fog" args={['#0A0118', 10, 50]} />
      
      <ambientLight intensity={0.2} />
      <pointLight position={[10, 10, 10]} intensity={1} />
      
      <ParticleField />
      <IsabellaOrb />
      
      {/* Portals en círculo */}
      <Portal position={[5, 0, 0]} color="#3B82F6" label="ISABELLA AI" route="/isabella" onHover={onPortalHover} />
      <Portal position={[-5, 0, 0]} color="#EF4444" label="ANUBIS" route="/anubis" onHover={onPortalHover} />
      <Portal position={[0, 0, 5]} color="#10B981" label="KAOS AUDIO" route="/kaos-audio" onHover={onPortalHover} />
      <Portal position={[0, 0, -5]} color="#F59E0B" label="QUANTUM" route="/quantum-render" onHover={onPortalHover} />
      <Portal position={[3.5, 3, 3.5]} color="#8B5CF6" label="ARCHITECTURE" route="/architecture" onHover={onPortalHover} />
      <Portal position={[-3.5, 3, 3.5]} color="#EC4899" label="SECURITY" route="/security" onHover={onPortalHover} />
      
      <Environment preset="night" />
      <OrbitControls 
        enableZoom={true}
        enablePan={true}
        minDistance={5}
        maxDistance={30}
        autoRotate
        autoRotateSpeed={0.5}
      />
    </>
  );
};

const MetaverseHub = () => {
  const [hoveredPortal, setHoveredPortal] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 1000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="relative w-full h-screen overflow-hidden bg-black">
      {/* Loading Screen */}
      {loading && (
        <motion.div
          initial={{ opacity: 1 }}
          animate={{ opacity: 0 }}
          transition={{ duration: 1, delay: 0.5 }}
          className="absolute inset-0 z-50 flex items-center justify-center bg-black"
        >
          <motion.div
            animate={{ scale: [1, 1.2, 1], rotate: [0, 180, 360] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="w-20 h-20 border-4 border-cyan-400 border-t-transparent rounded-full"
          />
        </motion.div>
      )}

      {/* 3D Canvas */}
      <Canvas shadows>
        <Suspense fallback={null}>
          <MetaverseScene onPortalHover={setHoveredPortal} />
        </Suspense>
      </Canvas>

      {/* UI Overlay */}
      <motion.div
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.2, duration: 0.8 }}
        className="absolute top-8 left-1/2 transform -translate-x-1/2 z-10 text-center"
      >
        <h1 className="text-6xl font-bold mb-4 bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
          TAMV METAVERSE
        </h1>
        <p className="text-xl text-slate-400">Navega el ecosistema dimensional • Haz clic en los portales</p>
      </motion.div>

      {/* Portal Info */}
      {hoveredPortal && (
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.8 }}
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10 bg-black/80 backdrop-blur-lg px-8 py-4 rounded-2xl border border-cyan-400/30"
        >
          <p className="text-2xl font-bold text-cyan-400">{hoveredPortal}</p>
          <p className="text-sm text-slate-400">Click para acceder</p>
        </motion.div>
      )}

      {/* Controls Info */}
      <motion.div
        initial={{ opacity: 0, x: -50 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 1.5, duration: 0.8 }}
        className="absolute bottom-8 left-8 z-10 bg-black/60 backdrop-blur-md px-6 py-4 rounded-xl border border-purple-500/30"
      >
        <p className="text-sm text-slate-300 mb-2">🖱️ Click + Arrastrar: Rotar</p>
        <p className="text-sm text-slate-300 mb-2">🖱️ Scroll: Zoom</p>
        <p className="text-sm text-slate-300">👆 Click en Portales: Navegar</p>
      </motion.div>
    </div>
  );
};

export default MetaverseHub;
