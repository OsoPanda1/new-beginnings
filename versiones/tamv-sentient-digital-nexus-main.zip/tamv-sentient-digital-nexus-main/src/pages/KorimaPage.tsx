import KorimaCodex from "@/components/KorimaCodex";
import PageTransition from "@/components/PageTransition";

const KorimaPage = () => {
  return (
    <PageTransition>
      <div className="min-h-screen">
        <KorimaCodex />
      </div>
    </PageTransition>
  );
};

export default KorimaPage;
