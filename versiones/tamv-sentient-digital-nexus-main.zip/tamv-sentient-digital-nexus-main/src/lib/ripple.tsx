// ripple.tsx
import * as React from "react";

export function useRipple() {
  const ref = React.useRef<HTMLDivElement>(null);

  function createRipple(event: React.MouseEvent) {
    const button = ref.current;
    if (!button) return;
    const circle = document.createElement("span");
    const diameter = Math.max(button.clientWidth, button.clientHeight);
    const radius = diameter / 2;
    circle.style.width = circle.style.height = `${diameter}px`;
    circle.style.left = `${event.clientX - button.getBoundingClientRect().left - radius}px`;
    circle.style.top = `${event.clientY - button.getBoundingClientRect().top - radius}px`;
    circle.className = "tamv-ripple";
    button.appendChild(circle);
    setTimeout(() => circle.remove(), 700);
  }

  return { ref, createRipple };
}

/* CSS (en global/tamv.css o tailwind)
.tamv-ripple {
  position: absolute;
  border-radius: 100%;
  background: rgba(40,230,250,0.18);
  pointer-events: none;
  animation: tamv-ripple-animate 0.6s linear;
  z-index: 2;
}
@keyframes tamv-ripple-animate {
  0% { transform: scale(0); opacity: 0.5; }
  100% { transform: scale(2.5); opacity: 0; }
}
*/
