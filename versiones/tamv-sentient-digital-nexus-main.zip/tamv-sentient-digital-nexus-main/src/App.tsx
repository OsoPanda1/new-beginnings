import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AnimatePresence } from "framer-motion";
import Index from "./pages/Index";
import Home from "./pages/Home";
import KorimaPage from "./pages/KorimaPage";
import PhilosophyPage from "./pages/PhilosophyPage";
import EcosystemPage from "./pages/EcosystemPage";
import ArchitecturePage from "./pages/ArchitecturePage";
import SecurityPage from "./pages/SecurityPage";
import UseCasesPage from "./pages/UseCasesPage";
import IsabellaPage from "./pages/IsabellaPage";
import AnubisPage from "./pages/AnubisPage";
import KaosAudioPage from "./pages/KaosAudioPage";
import QuantumRenderPage from "./pages/QuantumRenderPage";
import RoadmapPage from "./pages/RoadmapPage";
import BlogPage from "./pages/BlogPage";
import NotFound from "./pages/NotFound";
import Navigation from "./components/Navigation";
import Footer from "./components/Footer";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AnimatePresence mode="wait">
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/home" element={<Index />} />
            <Route path="/korima" element={<><Navigation /><KorimaPage /><Footer /></>} />
            <Route path="/philosophy" element={<><Navigation /><PhilosophyPage /><Footer /></>} />
            <Route path="/ecosystem" element={<><Navigation /><EcosystemPage /><Footer /></>} />
            <Route path="/architecture" element={<><Navigation /><ArchitecturePage /><Footer /></>} />
            <Route path="/security" element={<><Navigation /><SecurityPage /><Footer /></>} />
            <Route path="/use-cases" element={<><Navigation /><UseCasesPage /><Footer /></>} />
            <Route path="/isabella" element={<><Navigation /><IsabellaPage /><Footer /></>} />
            <Route path="/anubis" element={<><Navigation /><AnubisPage /><Footer /></>} />
            <Route path="/kaos-audio" element={<><Navigation /><KaosAudioPage /><Footer /></>} />
            <Route path="/quantum-render" element={<><Navigation /><QuantumRenderPage /><Footer /></>} />
            <Route path="/roadmap" element={<><Navigation /><RoadmapPage /><Footer /></>} />
            <Route path="/blog" element={<><Navigation /><BlogPage /><Footer /></>} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </AnimatePresence>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
