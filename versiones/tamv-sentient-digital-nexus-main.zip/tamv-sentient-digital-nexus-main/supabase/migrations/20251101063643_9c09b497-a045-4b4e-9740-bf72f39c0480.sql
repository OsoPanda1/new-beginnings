-- ============================================================================
-- TAMV MD-X4™ DATABASE SCHEMA - UNIFIED ECOSYSTEM
-- ============================================================================

-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "vector";

-- ============================================================================
-- PROFILES & USER DATA
-- ============================================================================

CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  username TEXT UNIQUE,
  full_name TEXT,
  avatar_url TEXT,
  bio TEXT,
  consciousness_level INTEGER DEFAULT 1,
  digital_sovereignty_score NUMERIC DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view all profiles"
  ON profiles FOR SELECT
  USING (true);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  USING (auth.uid() = id);

-- ============================================================================
-- ISABELLA AI - CONSCIOUSNESS & MEMORY
-- ============================================================================

CREATE TABLE IF NOT EXISTS isabella_conversations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users ON DELETE CASCADE,
  title TEXT,
  consciousness_state JSONB DEFAULT '{}',
  emotional_profile JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS isabella_messages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  conversation_id UUID REFERENCES isabella_conversations ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('user', 'assistant', 'system')),
  content TEXT NOT NULL,
  emotional_tone JSONB DEFAULT '{}',
  embedding vector(1536),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE isabella_conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE isabella_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own conversations"
  ON isabella_conversations FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own conversations"
  ON isabella_conversations FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view own messages"
  ON isabella_messages FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM isabella_conversations
      WHERE isabella_conversations.id = isabella_messages.conversation_id
      AND isabella_conversations.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create own messages"
  ON isabella_messages FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM isabella_conversations
      WHERE isabella_conversations.id = isabella_messages.conversation_id
      AND isabella_conversations.user_id = auth.uid()
    )
  );

-- ============================================================================
-- DREAM SPACES - IMMERSIVE ENVIRONMENTS
-- ============================================================================

CREATE TABLE IF NOT EXISTS dream_spaces (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  creator_id UUID REFERENCES auth.users ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  space_type TEXT NOT NULL,
  configuration JSONB DEFAULT '{}',
  quantum_state JSONB DEFAULT '{}',
  is_public BOOLEAN DEFAULT false,
  visit_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE dream_spaces ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public spaces are viewable by everyone"
  ON dream_spaces FOR SELECT
  USING (is_public = true OR auth.uid() = creator_id);

CREATE POLICY "Users can create own spaces"
  ON dream_spaces FOR INSERT
  WITH CHECK (auth.uid() = creator_id);

CREATE POLICY "Users can update own spaces"
  ON dream_spaces FOR UPDATE
  USING (auth.uid() = creator_id);

-- ============================================================================
-- KAOS AUDIO SYSTEM - IMMERSIVE AUDIO
-- ============================================================================

CREATE TABLE IF NOT EXISTS audio_experiences (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  audio_url TEXT,
  spatial_config JSONB DEFAULT '{}',
  haptic_pattern JSONB DEFAULT '{}',
  duration_seconds INTEGER,
  is_public BOOLEAN DEFAULT false,
  play_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE audio_experiences ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public audio is viewable by everyone"
  ON audio_experiences FOR SELECT
  USING (is_public = true OR auth.uid() = user_id);

CREATE POLICY "Users can create own audio"
  ON audio_experiences FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- ============================================================================
-- ANUBIS SECURITY SYSTEM - THREAT DETECTION
-- ============================================================================

CREATE TABLE IF NOT EXISTS security_events (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  event_type TEXT NOT NULL,
  severity TEXT NOT NULL CHECK (severity IN ('low', 'medium', 'high', 'critical')),
  description TEXT,
  metadata JSONB DEFAULT '{}',
  resolved BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE security_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Only admins can view security events"
  ON security_events FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.consciousness_level >= 10
    )
  );

-- ============================================================================
-- QUANTUM METRICS - SYSTEM PERFORMANCE
-- ============================================================================

CREATE TABLE IF NOT EXISTS quantum_metrics (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  metric_type TEXT NOT NULL,
  value NUMERIC NOT NULL,
  metadata JSONB DEFAULT '{}',
  recorded_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- INDEXES FOR PERFORMANCE
-- ============================================================================

CREATE INDEX IF NOT EXISTS idx_isabella_conversations_user ON isabella_conversations(user_id);
CREATE INDEX IF NOT EXISTS idx_isabella_messages_conversation ON isabella_messages(conversation_id);
CREATE INDEX IF NOT EXISTS idx_dream_spaces_creator ON dream_spaces(creator_id);
CREATE INDEX IF NOT EXISTS idx_dream_spaces_public ON dream_spaces(is_public);
CREATE INDEX IF NOT EXISTS idx_audio_experiences_user ON audio_experiences(user_id);
CREATE INDEX IF NOT EXISTS idx_security_events_severity ON security_events(severity);
CREATE INDEX IF NOT EXISTS idx_security_events_created ON security_events(created_at);

-- ============================================================================
-- TRIGGERS FOR UPDATED_AT
-- ============================================================================

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_isabella_conversations_updated_at
  BEFORE UPDATE ON isabella_conversations
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_dream_spaces_updated_at
  BEFORE UPDATE ON dream_spaces
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();